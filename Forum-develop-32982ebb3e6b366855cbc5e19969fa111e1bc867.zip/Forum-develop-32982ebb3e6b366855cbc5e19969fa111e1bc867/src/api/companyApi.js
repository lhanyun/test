import request from '@/utils/request'

// 获取公司列表
export function queryCompanyList(data) {
  return request({
    url: '/dbo/tenant/query/w/v1',
    method: 'post',
    data: data
  })
}

// 获取公司角色
export function queryAllRoles(data) {
  return request({
    url: '/dbo/initRole/queryAllRoles/w/v1',
    method: 'post',
    data: data
  })
}

// 获取公司下所有的角色列表
export function getRoleListByTenantIdName(data) {
  /*
   * data: {
   *   appType: 产品类型 必填
   *   tenantIdName: 公司名或id 必填
   * }*/
  return request({
    url: '/dbo/initRole/getRoleListByTenantIdName/w/v1',
    method: 'post',
    data: data
  })
}

// 获取产品类型下某公司的某角色权限树（全部菜单）
export function getRoleRightsOfAllMenu(data) {
  /*
   * data: {
   *   roleId: 角色id
   *   tenantId: 公司id 必填
   * }*/
  return request({
    url: '/dbo/initRole/getRoleRightsOfAllMenu/w/v1',
    method: 'post',
    data: data
  })
}

// 保存产品类型下某公司的某角色权限树（全部菜单）
export function saveRoleRightsTreeOfAllMenu(data) {
  /*
   * data: {
   *   roleRightsList
   * }*/
  return request({
    url: '/dbo/initRole/saveRoleRightsTreeOfAllMenu/w/v1',
    method: 'post',
    data: data
  })
}

// 获取公司用户组
export function queryAllGroups(data) {
  return request({
    url: '/dbo/initGroup/queryAllGroups/w/v1',
    method: 'post',
    data: data
  })
}

// 编辑创建公司
export function createOrUpdate(data) {
  return request({
    url: '/dbo/tenant/createOrUpdate/w/v1',
    method: 'post',
    data: data
  })
}

// 根据id获取公司详情
export function getCompanyDetail(data) {
  return request({
    url: '/dbo/tenant/getById/w/v1',
    method: 'post',
    data: data
  })
}

// 删除公司
// export function deleteCompany(data) {
//   return request({
//     url: '/dbo/tenant/deleteTenant/w/v1',
//     method: 'post',
//     data: data
//   })
// }

// 删除公司
export function deleteCompany(data) {
  return request({
    url: '/dbo/tenant/deleteTenantAndRelationTableById/w/v1',
    method: 'post',
    data: data
  })
}

// 冻结公司
export function frozenCompany(data) {
  return request({
    url: '/dbo/tenant/freezeTenant/w/v1',
    method: 'post',
    data: data
  })
}

// 转正公司
export function companyToFormal(data) {
  return request({
    url: '/dbo/tenant/becomeOfficial/w/v1',
    method: 'post',
    data: data
  })
}

// 获取全部行业
export function companyTrade(data) {
  return request({
    url: '/emequipment/industry/getIndustryList/w/v1',
    method: 'post',
    data: data
  })
}

// 获取全部行业(带权限过滤)
export function getIndustryList(data) {
  return request({
    url: '/dbo/industry/getIndustryList/w/v1',
    method: 'post',
    data: data
  })
}

// 获取全部设备类型
export function companyDeviceType(data) {
  return request({
    url: '/emequipment/industry/getEquipmentTypeList/w/v1',
    method: 'post',
    data: data
  })
}

// 中联直销客户认证
export function companyRecord(data) {
  return request({
    url: '/dbo/tenantAuthenticationRecord/queryList/w/v1',
    method: 'post',
    data: data
  })
}

// 设置白名单
export function companySetWhite(data) {
  return request({
    url: '/dbo/tenant/updateTenantIsWhiteList/w/v1',
    method: 'post',
    data: data
  })
}

// 公司人员组织
export function getOrgTree(data) {
  return request({
    url: '/dbo/org/getOrgTree/w/v1',
    method: 'post',
    data: data
  })
}

// 公司人员搜索
export function queryTenantUserOrgList(data) {
  return request({
    url: '/dbo/userOrg/queryTenantUserOrgList/w/v1',
    method: 'post',
    data: data
  })
}

// 公司删除
export function deleteCompanyTable(data) {
  return request({
    url: '/dbo/tenant/deleteTenantAndRelationTableById/w/v1',
    method: 'post',
    data: data
  })
}

// 公司管理 - 中联直销客户信息查询
export function getClientAuth(data) {
  return request({
    url: 'dbo/tenantAuthentication/queryTenantAuthenticationDetails/w/v1',
    method: 'post',
    data: data
  })
}

// 公司管理 - 中联直销客户信息编辑保存
export function updateOrSave(data) {
  return request({
    url: 'dbo/tenantAuthentication/updateOrCreateTenantAuthentication/w/v1',
    method: 'post',
    data: data
  })
}

// 中联直销 批量删除
export function deleteTenantAuthenticationRecord(data) {
  return request({
    url:
      '/dbo/tenantAuthenticationRecord/deleteTenantAuthenticationRecord/w/v1',
    method: 'post',
    data: data
  })
}

// 上传附件
export function uploadFile(payload) {
  return request({
    url: '/podbo/file/uploadFile/w/v1',
    method: 'post',
    data: payload,
    isFile: true
  })
}

// 获取应用列表
export function getApplicationList(data) {
  return request({
    url: '/dbo/tenantProduct/query/w/v1',
    method: 'post',
    data: data
  })
}

// 修改应用到期时间
export function editApplicationTime(data) {
  return request({
    url: '/dbo/tenantProduct/update/w/v1',
    method: 'post',
    data: data
  })
}

// 删除应用
export function deletApplication(data) {
  return request({
    url: '/dbo//tenantProduct/delete/w/v1',
    method: 'post',
    data: data
  })
}

// 编辑附件
export function editFile(payload) {
  return request({
    url: '/dbo/file/editFile/w/v1',
    method: 'post',
    data: payload
  })
}

// 收费功能
export function queryTenantChargeList(payload) {
  return request({
    url: '/dbo/tenantCharge/queryTenantChargeList/w/v1',
    method: 'post',
    data: payload
  })
}
