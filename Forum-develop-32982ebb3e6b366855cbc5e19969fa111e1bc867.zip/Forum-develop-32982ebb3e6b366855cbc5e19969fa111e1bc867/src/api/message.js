import request from '@/utils/request'

// 消息列表
export function messageInfo(payload) {
  return request({
    url: '/pocontent/messageInfo/query/w/v1',
    method: 'post',
    data: payload
  })
}

// 消息详情
export function queryDetail(payload) {
  return request({
    url: '/pocontent/messageInfo/queryDetail/w/v1',
    method: 'post',
    data: payload
  })
}

// 批量已读
export function readMessageInfo(payload) {
  return request({
    url: '/pocontent/messageInfo/readMessageInfo/w/v1',
    method: 'post',
    data: payload
  })
}

// 待办消息数量
export function queryUnreadTask(payload) {
  return request({
    url: '/pocontent/messageInfo/queryUnreadTask/w/v1',
    method: 'post',
    data: payload
  })
}

// 待办消息数量
export function queryUnreadMessage(payload) {
  return request({
    url: '/pocontent/messageInfo/queryUnreadMessage/w/v1',
    method: 'post',
    data: payload
  })
}

// 获取消息提醒设置
export function getDetail(data) {
  return request({
    url: '/poadmin/userMessageSetting/getDetail/w/v1',
    method: 'post',
    data
  })
}

// app消息提醒设置
export function createMessageSetting(data) {
  return request({
    url: '/poadmin/userMessageSetting/create/w/v1',
    method: 'post',
    data
  })
}
