/*
 * @Author: 肖巧伦
 * @Date: 2019-11-04 14:24:24
 * @LastEditTime: 2019-11-14 09:39:17
 * @LastEditors: Please set LastEditors
 * @Description: 信息论坛
 * @FilePath: \BBS-pc\src\api\forum.js
 */
import request from '@/utils/request'

/** 2019-11-04
 * @Author: 肖巧伦
 * @Desc: 论坛帖子列表
 */
export function bbsTopic(data) {
  return request({
    url: 'emportal/bbsTopic/query/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-07
 * @Author: 肖巧伦
 * @Desc: 获取所有设备类型
 */
export function getAllEquipmentType(data) {
  return request({
    url: '/emequipment/equipmentType/getAllEquipmentType/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-07
 * @Author: 肖巧伦
 * @Desc: 销售网点列表
 */
export function serviceNetwork(data) {
  return request({
    url: '/emportal/serviceNetwork/query/w/v1',
    method: 'post',
    data
  })
}

/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 行业列表
 */
export function getIndustryList(data) {
  return request({
    url: '/emportal/industry/getIndustryList/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 新增帖子或编辑
 */
export function bbsTopicSave(data) {
  return request({
    url: '/emportal/bbsTopic/save/w/v1',
    method: 'post',
    data
  })
}

/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 帖子详情
 */
export function bbsTopicDetail(data) {
  return request({
    url: '/emportal/bbsTopic/detail/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 我的回复
 */
export function onMyReply(data) {
  return request({
    url: '/emportal/bbsReply/queryMyReply/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 我的帖子列表
 */
export function onMyTopics(data) {
  return request({
    url: 'emportal/bbsTopic/queryMyTopics/w/v1',
    method: 'post',
    data
  })
}

/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 删除我的发表
 */
export function onDelete(data) {
  return request({
    url: '/emportal/bbsTopic/delete/w/v1',
    method: 'post',
    data
  })
}
/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 删除我的回复
 */
export function bbsReplyDelete(data) {
  return request({
    url: '/emportal/bbsReply/delete/w/v1',
    method: 'post',
    data
  })
}

/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 获取回复层下的回复
 */
export function queryByLevelParent(data) {
  return request({
    url: '/emportal/bbsReply/queryByLevelParent/w/v1',
    method: 'post',
    data
  })
}

/** 2019-11-08
 * @Author: 肖巧伦
 * @Desc: 新增回复或者编辑
 */
export function bbsReplySave(data) {
  return request({
    url: '/emportal/bbsReply/save/w/v1',
    method: 'post',
    data
  })
}
