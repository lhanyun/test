import request from '@/utils/request'

// 知识库列表
export function knowledgeList(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/queryAdminKnowledgeCenterList/w/v1',
    method: 'post',
    data: payload
  })
}

// 删除 - 批量
export function knowledgeDelete(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/deleteKnowledgeCenter/w/v1',
    method: 'post',
    data: payload
  })
}

//  知识库列表 - 显示/隐藏/发布
export function knowledgeStatus(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/updateStatus/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 详情
export function queryDetails(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/queryDetails/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 详情 - 标签
export function queryAdminKnowledgeTag(payload) {
  return request({
    url: '/dbo/adminKnowledgeTag/queryAdminKnowledgeTag/w/v1',
    method: 'post',
    data: payload
  })
}

//  知识库列表 - 新建 - 标签
export function queryAdminTag(payload) {
  return request({
    url: '/dbo/adminTag/queryAdminTag/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 编辑回显 -标签
export function queryKnowldgeAdminTag(payload) {
  return request({
    url: '/dbo/adminTag/queryKnowldgeAdminTag/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 新建 - 新增
export function createAdminTag(payload) {
  return request({
    url: '/dbo/adminTag/createAdminTag/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 新建 - 保存
export function createAdminKnowledgeCenter(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/createAdminKnowledgeCenter/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 编辑 - 保存
export function updateAdminKnowledgeCenter(payload) {
  return request({
    url: '/dbo/adminKnowledgeCenter/updateAdminKnowledgeCenter/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 新建 - 上传附件
export function uploadFile(payload) {
  return request({
    url: '/podbo/file/uploadFile/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库列表 - 回显图片
export function richTextUpdateImg(payload) {
  return request({
    url: '/podbo/adminKnowledgeCenter/richTextUpdateImg/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库目录 - 行业
export function queryIndustryList(payload) {
  return request({
    url: '/dbo/adminKnowledgeTag/queryIndustryDirectoryList/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库目录 - 设备
export function queryEquipmentTypeList(payload) {
  return request({
    url: '/dbo/adminKnowledgeTag/queryEquipmentTypeList/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库目录 - 分类标签
export function directoryTagTypeList(payload) {
  return request({
    url: '/dbo/adminKnowledgeTag/queryIndustryDirectoryTagTypeList/w/v1',
    method: 'post',
    data: payload
  })
}
// 知识库目录 - 删除（含批量)
export function deleteAdminTag(payload) {
  return request({
    url: '/dbo/adminTag/deleteAdminTag/w/v1',
    method: 'post',
    data: payload
  })
}

// 知识库目录 - 标签编辑
export function updateAdminTag(payload) {
  return request({
    url: '/dbo/adminTag/updateAdminTag/w/v1',
    method: 'post',
    data: payload
  })
}
