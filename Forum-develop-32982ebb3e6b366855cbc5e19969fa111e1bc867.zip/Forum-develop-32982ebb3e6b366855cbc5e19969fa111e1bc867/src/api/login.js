import request from '@/utils/request'

/** 2019-07-24
 * @Author: 肖景
 * @Desc: 账号密码登录
 */
export function login(data) {
  return request({
    url: '/poadmin/portal/accountLogin/w/v1',
    method: 'post',
    data
  })
}

/** 2019-09-09
 * @Author: 肖景
 * @Desc: 手机验证码注册
 */
export function register(data) {
  return request({
    url: '/poadmin/portal/register/w/v1',
    method: 'post',
    data
  })
}

/** 2019-04-24
 * @Author: 肖景
 * @Desc: 获取用户信息
 */
export function getInfo(token) {
  return request({
    url: '/user/info',
    method: 'post',
    params: {
      token
    }
  })
}

/** 2019-07-24
 * @Author: 肖景
 * @Desc: 用户退出
 */
export function logout() {
  return request({
    url: '/poadmin/user/logout/w/v1',
    method: 'get'
  })
}

/** 2019-07-26
 * @Author: 刘宇琳
 * @Desc: 忘记密码
 */
export function forgetPassword(data) {
  return request({
    url: '/poadmin/user/forgetPassword/w/v1',
    method: 'post',
    data
  })
}

/** 2019-07-07
 * @Author: 刘宇琳
 * @Desc: 获取公钥
 */
export async function getCertificateInfo() {
  return await request({
    url: '/authcenter/publicKey',
    method: 'get'
  })
}

/** 2019-07-07
 * @Author: 刘宇琳
 * @Desc: 获取短信验证码
 */
export function getMsgCode(data) {
  return request({
    url: '/authcenter/verificationCode',
    method: 'get',
    data
  })
}

/** 2019-09-09
 * @Author: 刘宇琳
 * @Desc: 短信校验
 */
export function verificationCodeCheck(data) {
  return request({
    url: '/authcenter/verificationCodeCheck',
    method: 'post',
    data
  })
}

export function smsLogin(data) {
  return request({
    url: '/poadmin/portal/smsLogin/w/v1',
    method: 'post',
    data
  })
}

/** 2019-07-23
 * @Author: 刘宇琳
 * @Desc: 数据字典
 */
export function getAllDictionaryKeyValue(data) {
  return request({
    url: 'poadmin/dictionary/getDictionaryMapByClassify/w/v1',
    method: 'post',
    data
  })
}

/** 2019-07-30
 * @Author: 刘宇琳
 * @Desc: 获取个人信息
 */
export function getUserInfo(data) {
  return request({
    url: '/poadmin/user/indexUserInfo/w/v1',
    method: 'post',
    data
  })
}

/** 2019-09-10
 * @Author: 肖景
 * @Desc: 获取默认产品信息
 */
export function getProductInfo(data) {
  return request({
    url: '/poadmin/product/getProductInfo/w/v1',
    method: 'post',
    data
  })
}

/** 2019-09-11
 * @Author: 肖景
 * @Desc: 获取用户的所有公司列表
 */
export function queryUserTenant() {
  return request({
    url: '/poadmin/userTenant/queryUserTenant/w/v1',
    method: 'post'
  })
}

/** 2019-09-11
 * @Author: 肖景
 * @Desc: 切换默认公司
 */
export function changeDefaultTenant(data) {
  return request({
    url: '/poadmin/userTenant/changeDefaultTenant/w/v1',
    method: 'post',
    data
  })
}

/** 2019-09-16
 * @Author: 肖景
 * @Desc: 创建公司
 */
export function createTenant(data) {
  return request({
    url: '/poadmin/tenant/createTenant/w/v1',
    method: 'post',
    data
  })
}

/** 2019-09-16
 * @Author: 肖景
 * @Desc: 创建公司
 */
export function getUserMenuTreeByAppType(appType) {
  return request({
    url: '/poadmin/role/getUserMenuTreeByAppType/w/v1',
    method: 'post',
    data: {
      appType
    }
  })
}

// 选择公司
export function chooseCorp(param) {
  return request({
    url: '/poadmin/role/chooseCorp/w/v1',
    method: 'post',
    data: param
  })
}

/** 2019-07-25
 * @Author: 肖景
 * @Desc: 正在使用的产品(默认产品)
 */
export function queryTenantProductList(data) {
  return request({
    url: '/emportal/product/queryTenantProductList/w/v1',
    method: 'post',
    data
  })
}
