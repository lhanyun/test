export default [
  {
    path: '/404',
    component: () => import('@/views/errorPage/404')
  },
  {
    path: '/401',
    component: () => import('@/views/errorPage/401')
  }
]
