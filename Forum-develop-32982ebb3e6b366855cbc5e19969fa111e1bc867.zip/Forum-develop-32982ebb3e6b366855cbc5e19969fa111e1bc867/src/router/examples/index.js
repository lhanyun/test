/* Layout */
import BaseLayout from '@/layouts/BaseLayout'
import MainLayout from '@/layouts/MainLayout'
import SimpleLayout from '@/layouts/SimpleLayout'
export default [
  {
    path: '/',
    redirect: '/forum'
  },
  {
    path: '/forum',
    name: 'forum',
    component: () => import('@/views/machinery-BBS/index.vue'),
    redirect: 'machinery-information',
    children: [
      {
        path: '/machinery-information',
        name: 'machinery-information',
        component: () =>
          import('@/views/machinery-BBS/machinery-information/index.vue'),
        meta: {
          title: '农机信息'
        }
      },
      {
        path: '/post-message',
        name: 'post-message',
        component: () => import('@/views/machinery-BBS/post-message/index.vue'),
        meta: {
          title: '发帖/编辑'
        }
      },
      {
        path: '/post-details',
        name: 'post-details',
        component: () =>
          import('@/views/machinery-BBS/machinery-information/post-details/index.vue'),
        meta: {
          title: '帖子详情'
        }
      },
      {
        path: '/post-reply',
        name: 'post-reply',
        component: () => import('@/views/machinery-BBS/post-reply/index.vue'),
        meta: {
          title: '发表回复'
        }
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/examples/Login/index.vue'),
    meta: {
      title: '登陆页面',
      icon: 'big-logo'
    }
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/views/examples/Home/index.vue'),
    meta: {
      title: '首页',
      icon: 'big-logo'
    }
  },
  {
    path: '/baseLayout',
    component: BaseLayout,
    children: [
      {
        path: '/baseLayout',
        name: 'BaseLayout',
        component: () => import('@/views/examples/Home/index.vue'),
        meta: {
          title: '主页布局',
          icon: 'begin'
        }
      }
    ]
  },
  {
    path: '/simple',
    component: SimpleLayout,
    children: [
      {
        path: '/simpleLayout',
        name: 'SimpleLayout',
        component: () => import('@/views/examples/Detail/index.vue'),
        meta: {
          title: '简单二级页面布局',
          icon: 'big-logo'
        }
      }
    ]
  },
  {
    path: '/index',
    component: MainLayout,
    name: '主要页面布局',
    meta: {
      title: '主要页面布局',
      icon: 'coord'
    },
    redirect: 'MainLayout',
    children: [
      {
        path: '/mainLayout',
        name: 'MainLayout',
        component: () => import('@/views/examples/Detail/index.vue'),
        meta: {
          title: 'MainLayout'
        }
      },
      {
        path: '/message',
        name: 'message',
        component: () => import('@/views/examples/Message/index.vue'),
        meta: {
          title: '消息中心'
        }
      },
      {
        path: '/redirect/:path*',
        hidden: true,
        component: () => import('@/views/redirect/index')
      }
    ]
  }
]
