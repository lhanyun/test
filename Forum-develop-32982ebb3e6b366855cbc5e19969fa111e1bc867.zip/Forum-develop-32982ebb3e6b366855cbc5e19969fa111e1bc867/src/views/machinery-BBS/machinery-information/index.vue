<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-01 09:17:54
 * @LastEditTime: 2019-12-04 16:16:16
 * @Description: 农机信息文章列表
 -->
<template>
  <ul class="machinery-information">
    <!-- 左侧文章内容 -->
    <ul class="machinery-information__left">
      <!-- 发帖按钮 -->
      <zv-button
        class="machinery-information__left-btn"
        @click.native="sendClick"
        plain
        icon="bianji"
      >
        {{ $t('fornum.postd') }}
        <!-- $t 发帖 -->
      </zv-button>
      <zv-tabs v-model="activeName" :tab-pane="tabPane">
        <!-- 信息论坛 -->
        <div class="machinery-information__tabs" slot="forum">
          <post
            v-bind:bbsTopicList="bbsTopicList"
            v-bind:loading="loading"
            v-bind:disabled="disabled"
            v-bind:count="count"
            @func="load"
          ></post>
        </div>
        <!-- 销售网点 -->
        <div class="machinery-information__tabs" slot="store">
          <online
            v-bind:serviceNetwork="serviceNetwork"
            v-bind:disabled2="disabled2"
            v-bind:loading2="loading2"
            v-bind:count2="count2"
            @func2="load2"
          ></online>
        </div>
      </zv-tabs>
    </ul>
    <!-- 右侧筛选 -->
    <div class="machinery-information__right">
      <h4>
        {{ $t('fornum.screen') }}
        <!-- $t 筛选标签 -->
      </h4>
      <!-- 排序筛选 内容 -->
      <div v-if="activeName === 'forum'" class="machinery-information__first">
        <p>
          {{ $t('fornum.equipment') }}
          <!-- $t 设备 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in equipmentTypes"
            :key="i"
            @click="equipmentClick(item, i)"
            :class="
              equipmentIndex === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item.equipmentTypeName }}
          </button>
        </div>
        <!-- 类型筛选 内容 -->
        <p>
          {{ $t('fornum.type') }}
          <!-- $t 类型 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in topicTypeList"
            :key="i"
            @click="topicClick(item, i)"
            :class="
              topicIndex === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item }}
          </button>
        </div>
        <!-- 排序筛选 内容 -->
        <p>
          {{ $t('fornum.sort') }}
          <!-- $t 排序 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in sortingType"
            :key="i"
            @click="btnsClick(item.id, i)"
            :class="
              indexes === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item.name }}
          </button>
        </div>
      </div>
      <!-- 销售网点筛选 -->
      <div class="machinery-information__first" v-if="activeName === 'store'">
        <!-- 行业筛选 内容 -->
        <p>
          {{ $t('fornum.industry') }}
          <!-- $t 行业 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in industryDtoList"
            :key="i"
            @click="industryClick(item, i)"
            :class="
              industryIndex === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item.name }}
          </button>
        </div>
        <!-- 省 内容 -->
        <p>
          {{ $t('fornum.province') }}
          <!-- $t 省份 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in provinceData"
            :key="i"
            @click="provinceClick(item, i)"
            :class="
              provinceIndex === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item.label }}
          </button>
        </div>
        <!-- 省 内容 -->
        <p>
          {{ $t('fornum.city') }}
          <!-- $t 城市 -->
        </p>
        <!-- 筛选按钮 -->
        <div class="machinery-information__right-btns">
          <button
            v-for="(item, i) in cityData"
            :key="i"
            @click="cityClick(item, i)"
            :class="
              cityIndex === i
                ? 'machinery-information__btn-green'
                : 'machinery-information__btn'
            "
            plain
          >
            {{ item.label }}
          </button>
        </div>
      </div>
    </div>
  </ul>
</template>
<script>
import {
  bbsTopic,
  getAllEquipmentType,
  serviceNetwork,
  getIndustryList
} from '@/api/forum'
import { city } from '@/utils/city'
import { anascityData } from './utils'
import online from './online'
import post from './post'
const { provinceData } = anascityData(city)
export default {
  name: 'machinery-information',
  components: {
    online,
    post
  },
  // 父组件传来的参
  props: ['inputVal'],
  data() {
    return {
      // tab栏默认显示页
      activeName: 'forum',
      // tab栏内容
      tabPane: [
        {
          label: this.$t('fornum.forumMessage'), // $t 信息论坛
          name: 'forum'
        },
        {
          label: this.$t('fornum.onlineStore'), // $t 销售网点
          name: 'store'
        }
      ],
      // 分页数据
      pageNum: 1,
      pageSize: 20,
      // 论坛帖子列表
      bbsTopicList: [],
      // 帖子类型
      topicTypeList: '',
      // 设备类型
      equipmentTypes: '',
      // 排序类型
      sortingType: [
        {
          id: '1',
          name: this.$t('fornum.recoveryTime') // $t 回复时间
        },
        {
          id: '2',
          name: this.$t('fornum.PostingTime') // $t 发帖时间
        },
        {
          id: '3',
          name: this.$t('fornum.repliesNumber') // $t 回复数量
        },
        {
          id: '4',
          name: this.$t('fornum.examineNumber') // $t 查看数量
        }
      ],
      // 设备选中的按钮 索引号
      equipmentIndex: '',
      // 帖子类型选中的按钮 索引号
      topicIndex: '',
      indexes: '',
      // 设备类型
      deviceType: '',
      // 帖子类型
      topicType: '',
      // 搜索字符串
      searchValue: '',
      searchValue2: '',
      // 排序类型
      orderBy: '',
      // 销售网点列表
      serviceNetwork: [],
      // 筛选行业列表
      industryDtoList: [],
      // 行业选中的按钮 索引号
      industryIndex: '',
      //	行业编码列表
      industryCodeList: '',
      //	省
      province: '',
      //	市
      city: '',
      // 分页
      pageNum2: 1,
      pageSize2: 20,
      // 省市数据
      provinceData: provinceData,
      cityData: '',
      //省份选中的按钮 索引号
      provinceIndex: '',
      cityIndex: '',
      // 控制分页字段的显示隐藏
      loading: false,
      loading2: false,
      count: false,
      count2: false
    }
  },

  computed: {
    disabled() {
      return this.loading || this.count
    },
    disabled2() {
      return this.loading2 || this.count2
    }
  },
  watch: {
    // 监听父组件传来的输入框值
    inputVal(val) {
      // 判断处于论坛还是销售网点
      if (this.activeName === 'forum') {
        this.searchValue = val // 接收父组件的值
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
      } else {
        this.searchValue2 = val
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
      }
    },
    // 监听帖子分页的值
    pageNum() {
      if (this.pageNum !== 1) {
        this.bbsTopicAxios()
      }
    },
    // 销售网点分页的值
    pageNum2() {
      if (this.pageNum2 !== 1) {
        this.serviceNetworkAxios()
      }
    }
  },
  async mounted() {
    try {
      //  获取所有设备类型
      const data = await getAllEquipmentType()
      this.equipmentTypes = data.equipmentTypes
      // 存储筛选类型
      this.topicTypeList = this.$getDataDic('topicType')
      // 获取网点行业信息
      const str = await getIndustryList()
      this.industryDtoList = str.industryDtoList
      if (this.equipmentTypes && this.industryDtoList) {
        this.bbsTopicAxios()
        this.serviceNetworkAxios()
      }
    } catch (error) {
      throw error
    }
  },
  methods: {
    /**
     * @Description: 网点列表滑至底部触发
     * @Author: 肖巧伦
     * @Desc: 无限滚动加载
     */
    load2() {
      this.loading2 = true
      if (!this.count2) {
        setTimeout(() => {
          this.pageNum2++
          this.loading2 = false
        }, 2000)
      }
    },

    /**
     * @Description: 帖子列表滑至底部触发
     * @Author: 肖巧伦
     * @Desc: 无限滚动加载
     */
    load() {
      this.loading = true
      if (!this.count) {
        setTimeout(() => {
          this.pageNum++
          this.loading = false
        }, 2000)
      }
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取帖子列表
     */
    async bbsTopicAxios() {
      try {
        if (this.equipmentTypes) {
          const data = await bbsTopic({
            deviceType: this.deviceType,
            topicType: this.topicType,
            searchValue: this.searchValue,
            pageNum: this.pageNum,
            pageSize: this.pageSize,
            orderBy: this.orderBy
          })
          if (data.list.length === 0) {
            this.count = true
            this.loading = false
          } else {
            data.list.forEach(item => {
              // 过滤富文本标签
              item.topicContent = decodeURI(item.topicContent)
                .replace(/<[^>]+>/g, '')
                .replace(/&nbsp;/gi, '')
                .replace(/&ldquo;/gi, '')
                .replace(/&rdquo;/gi, '')
              this.bbsTopicList.push(item)

              // 循环修改设备类型
              this.equipmentTypes.forEach(int => {
                if (int.equipmentTypeCode === item.deviceType) {
                  item.deviceType = int.equipmentTypeName
                }
              })
              for (let key in this.topicTypeList) {
                if (item.topicType === key) {
                  item.topicType = this.topicTypeList[key]
                }
              }
            })
          }
        }
      } catch (error) {
        throw error
      }
    },

    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc:获取销售网点数据
     */
    async serviceNetworkAxios() {
      try {
        const data = await serviceNetwork({
          industryCodeList: this.industryCodeList,
          province: this.province,
          city: this.city,
          searchValue: this.searchValue2,
          pageNum: this.pageNum2,
          pageSize: this.pageSize2
        })
        if (data.list.length === 0) {
          this.count2 = true
          this.loading2 = false
        } else {
          data.list.forEach(item => {
            // 过滤网点所属行业
            item.industryCodes = item.industryCodes.split(',')
            item.industryCodes.forEach((int, i) => {
              this.industryDtoList.forEach(ind => {
                if (ind.code === int) {
                  item.industryCodes[i] = ind.name
                }
              })
            })
            item.industryCodes = item.industryCodes.join(' ')
            this.serviceNetwork.push(item)
          })
        }
      } catch (error) {
        throw error
      }
    },

    /**
     * @Description: 点击城市下按钮触发
     * @Author: 肖巧伦
     * @Desc: 城市排序
     */
    cityClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.cityIndex) {
        this.city = ''
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.cityIndex = ''
      } else {
        this.city = item.label
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.cityIndex = i
      }
    },
    /**
     * @Description: 点击省份下按钮触发
     * @Author: 肖巧伦
     * @Desc: 省份排序
     */
    provinceClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.provinceIndex) {
        this.province = ''
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.cityData = ''
        this.provinceIndex = ''
      } else {
        this.cityData = item.children
        this.province = item.label
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.provinceIndex = i
      }
    },
    /**
     * @Description: 点击行业下按钮触发
     * @Author: 肖巧伦
     * @Desc:筛选排序
     */
    industryClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.industryIndex) {
        this.industryCodeList = ''
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.industryIndex = ''
      } else {
        this.industryCodeList = item.code
        this.serviceNetwork = []
        this.pageNum2 = 1
        this.serviceNetworkAxios()
        this.industryIndex = i
      }
    },
    /**
     * @Description: 点击排序下按钮触发
     * @Author: 肖巧伦
     * @Desc:筛选排序
     */
    btnsClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.indexes) {
        this.orderBy = ''
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
        this.indexes = ''
      } else {
        this.orderBy = item
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
        this.indexes = i
      }
    },
    /**
     * @Description: 点击设备按钮触发
     * @Author: 肖巧伦
     * @Desc: 筛选类型
     */
    equipmentClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.equipmentIndex) {
        this.deviceType = ''
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
        this.equipmentIndex = ''
      } else {
        this.deviceType = item.equipmentTypeCode
        this.pageNum = 1
        this.bbsTopicList = []
        this.bbsTopicAxios()
        this.equipmentIndex = i
      }
    },
    /**
     * @Description: 点击类型按钮触发
     * @Author: 肖巧伦
     * @Desc: 筛选设备
     */
    topicClick(item, i) {
      // 如果该按钮处于点击状态
      if (i === this.topicIndex) {
        this.topicType = ''
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
        this.topicIndex = ''
      } else {
        for (let key in this.topicTypeList) {
          if (item === this.topicTypeList[key]) {
            // 存储帖子类型
            this.topicType = key
          }
        }
        this.bbsTopicList = []
        this.pageNum = 1
        this.bbsTopicAxios()
        this.topicIndex = i
      }
    },
    /**
     * @Description: 点击发帖按钮触发
     * @Author: 肖巧伦
     * @Desc:跳转至发贴页
     */
    sendClick() {
      this.$router.push({ name: 'post-message' })
    }
  }
}
</script>

<style lang="scss" scoped>
.machinery-information {
  li {
    list-style: none;
  }
  width: 1135px;
  margin: 10px auto;
  // 左侧文章内容盒子
  .machinery-information__left {
    display: inline-block;
    width: 800px;
    margin-right: 8px;
    background-color: $white;
    position: relative;
    // 发帖按钮
    .machinery-information__left-btn {
      z-index: 2;
      position: absolute;
      top: 5px;
      right: 15px;
    }
    // 销售网点
    .machinery-information__store {
      padding: 20px;
      border-bottom: 1px solid $background-color;
      font-size: $base-font-size;
      color: $sub-font-color;
      cursor: pointer;
      h4 {
        font-size: $btr-font-size;
        color: $sbr-font-color;
      }
      p {
        margin: 12px 0;
      }
    }
  }
  // 右侧筛选
  .machinery-information__right {
    vertical-align: top;
    display: inline-block;
    width: 320px;
    background-color: $white;
    .machinery-information__first {
      width: 320px;
      height: 85%;
      position: fixed;
      overflow: auto;
      background-color: $white;
    }
    h4,
    p {
      font-size: 14px;
      font-weight: normal;
      color: $base-font-color;
      height: 43px;
      line-height: 43px;
      border-bottom: 1px solid $background-color;
      padding: 0 15px;
    }
    p {
      border: 0;
      color: $sub-font-color;
    }
    // 筛选内容
    .machinery-information__right-btns {
      padding: 0 16px 0 8px;
      // 筛选按钮
      .machinery-information__btn-green,
      .machinery-information__btn {
        min-width: 85px;
        outline: none;
        max-width: 200px;
        margin: 0 0 8px 8px;
        background-color: $white;
        border-radius: 2px;
        border: 1px solid #e0e0e0;
        height: 30px;
        line-height: 30px;
        padding: 0 20px;
        text-align: center;
        font-size: $sub-font-size;
        color: #212121;
        cursor: pointer;
      }
      .machinery-information__btn-green {
        color: #70b913;
        border: solid 1px #70b913;
        background-color: rgba(124, 179, 66, 0.3);
      }
    }
  }
}
</style>
