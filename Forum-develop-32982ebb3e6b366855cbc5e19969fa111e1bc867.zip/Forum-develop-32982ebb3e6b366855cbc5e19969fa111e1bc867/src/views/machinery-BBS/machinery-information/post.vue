<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-30 11:49:55
 * @Description: 帖子列表
 -->
<template>
  <div>
    <!-- 无数据显示 -->
    <div
      class="machinery-information__invitation"
      v-if="bbsTopicList.length === 0"
    >
      {{ $t('fornum.noData') }}
      <!-- $t 暂时没有数据... -->
    </div>
    <!-- 帖子列表 -->
    <div class="machinery-information__list-wrapper">
      <ul v-infinite-scroll="load" infinite-scroll-disabled="disabled">
        <li
          class="machinery-information__invitation"
          v-for="(item, i) in bbsTopicList"
          :key="i"
          @click="clickList(item.id)"
        >
          <!-- 标题 -->
          <h3>[{{ item.topicType }}] {{ item.topicTitle }}</h3>
          <!-- 内容 -->
          <div class="machinery-information__post-content">
            {{ item.topicContent }}
          </div>
          <!-- 详情 -->
          <p>
            <span>
              {{ item.userName }}/{{ item.deviceType }}/{{ item.createDate }}
            </span>
            <span>
              <zv-svg-icon iconClass="chakan" />&nbsp;{{
                item.pageviewsCount
              }}&nbsp;&nbsp;&nbsp;&nbsp;
              <zv-svg-icon iconClass="duihua" />&nbsp;{{ item.replyCount }}
            </span>
          </p>
        </li>
      </ul>
      <p
        class="machinery-information__loading"
        v-if="loading && bbsTopicList.length >= 10"
      >
        {{ $t('fornum.loading') }}
        <!-- $t 加载中... -->
      </p>
      <p
        class="machinery-information__loading"
        v-if="count && bbsTopicList.length >= 10"
      >
        {{ $t('fornum.noMore') }}
        <!-- $t 没有更多了 -->
      </p>
    </div>
  </div>
</template>
<script>
export default {
  name: 'post',
  props: ['bbsTopicList', 'loading', 'disabled', 'count'],
  methods: {
    load() {
      this.$emit('func')
    },

    /**
     * @Description: 点击列表触发
     * @Author: 肖巧伦
     * @Desc: 跳转帖子详情
     */
    clickList(id) {
      this.$router.push({
        path: '/post-details',
        query: { postId: id }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
// 滚动组件
.machinery-information__list-wrapper {
  width: 800px;
  height: 85%;
  position: fixed;
  overflow: auto;
  background-color: $white;
  .machinery-information__loading {
    height: 44px;
    text-align: center;
    line-height: 44px;
    color: $date-icon-color;
    font-size: $base-font-size;
  }
}
// 信息论坛
.machinery-information__invitation {
  padding: 20px;
  border-bottom: 1px solid $background-color;
  color: $base-font-color;
  font-size: $base-font-size;
  cursor: pointer;
  // 帖子标题
  h3 {
    font-size: $btr-font-size;
    color: $sbr-font-color;
    margin: 0 0 8px 0;
  }
  // 帖子详情
  p {
    margin: 8px 0 0 0;
    color: $sub-font-color;
    font-size: $base-font-size;
    display: flex;
    -ms-flex-pack: justify;
    justify-content: space-between;
  }
  .machinery-information__post-content {
    display: -webkit-box;
    -webkit-line-clamp: 5;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
    overflow: hidden;
    // 帖子内的图片 等比例缩放
    /deep/img {
      width: auto !important;
      height: auto !important;
      max-width: 100% !important;
    }
  }
}
</style>
