<!--
 * @Author: 肖巧伦
 * @LastEditTime: 2019-12-04 16:36:31
 * @Description: 评论
 -->
<template>
  <div>
    <!-- 标题 -->
    <div class="post-details__title">
      <!--文章 标题 -->
      <h3>[{{ topicType }}] {{ topic.topicTitle }}</h3>
      <!-- 发帖人 -->
      <div class="post-details__replier">
        <span>
          <span class="post-details__name">
            <img
              :src="defaultIcon"
              class="
            post-details__img"
            />
            {{ topic.userName }} </span
          >{{ topic.tenantName }}</span
        >
        <span>{{ topic.createDate }}</span>
      </div>
      <!-- 内容 -->
      <div
        v-html="decodeURI(topic.topicContent)"
        class="post-details__post-content"
      ></div>
      <el-tag type="info" size="small">{{ equipmentTypeName }}</el-tag>
    </div>
    <!-- 数量统计 -->
    <div class="post-details__statistics">
      <span
        >{{ $t('fornum.browseNumber') }}
        <!-- $t 浏览数 -->：{{
          topic.pageviewsCount
        }}&nbsp;&nbsp;|&nbsp;&nbsp;{{ $t('fornum.commentNumber') }}
        <!-- $t 评论数 -->：{{ topic.replyCount }}</span
      >
      <span>
        <zv-button plain @click.native="$router.go(-1)">
          {{ $t('fornum.goBack') }}
          <!-- $t 返回 -->
        </zv-button>
        <zv-button
          @click.native="dialogVisible = true"
          plain
          icon="bianji"
          v-if="topic.ifReply === 'Y'"
        >
          {{ $t('fornum.comment') }}
          <!-- $t 评论 -->
        </zv-button>
        <zv-button disabled plain icon="bianji" v-else>
          {{ $t('fornum.comment') }}
          <!-- $t 评论 -->
        </zv-button>
      </span>
    </div>

    <!-- 评论弹框 -->
    <el-dialog
      :title="$t('fornum.comment')"
      :visible.sync="dialogVisible"
      width="40%"
    >
      <!-- $t 评论 -->
      <!-- 富文本 -->
      <div class="post-message__editor">
        <tinymce-editor
          ref="editor"
          v-model="ruleForm.contentText"
          @imgUrl="imgUrl"
        />
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitComments"
          >{{ $t('fornum.submit') }}
          <!-- $t 提交 -->
        </el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { bbsReplySave } from '@/api/forum'
import tinymceEditor from '@/components/zl-tinymce-editor/index'
export default {
  name: 'comments',
  components: { tinymceEditor },
  props: ['topic', 'topicType', 'equipmentTypeName'],
  data() {
    return {
      // 用户头像图标
      defaultIcon: require('@/assets/img/defaultIcon.png'),
      // 控制评论弹框的显示和隐藏
      dialogVisible: false,
      // 富文本参数
      ruleForm: {
        locale: '',
        //语言
        productNames: '',
        // 产品
        menuName: '',
        // 菜单应用
        isCommon: '',
        //应用通用
        archivesTag: [],
        // 标签数据
        content: '',
        title: '',
        helpStatus: '',
        contentText: '',
        imgId: [],
        // 回复列表
        replyList: [],
        replyList2: [],
        // 辨识回复层数id
        replyThree: '',
        // 存储层级数据
        hierarchy: ''
      }
    }
  },
  methods: {
    /**
     * * @Description: 父组件传值触发
     * *@Author: 肖巧伦
     * * @Desc: 获取富文本上传图片
     * */
    imgUrl(data) {
      this.ruleForm.imgId = data
    },
    /**
     * @Description: 提交评论触发
     * @Author: 肖巧伦
     */
    async submitComments() {
      try {
        const str = this.ruleForm.contentText
          .replace(/<[^>]+>/g, '')
          .replace(/&nbsp;/gi, '')
          .trim()
        if (str) {
          await bbsReplySave({
            topicId: this.$route.query.postId,
            replyType: '1',
            replyPersonId: this.$store.getters.userInfo.attachmentId,
            replyContent: encodeURI(this.ruleForm.contentText),
            returnedPersonName: this.topic.userName,
            returnedPersonId: this.topic.userId,
            reply_status: '2'
          })
          // 刷新当前页
          this.$emit('event1')
        } else {
          this.$message.error(this.$t('fornum.commentANull')) // $t 评论内容不能为空
        }
      } catch (error) {
        throw error
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.post-details__title {
  // 详情标题
  padding: 20px;
  h3 {
    font-size: 20px;
    color: $sbr-font-color;
  }
  .post-details__replier {
    //发帖人信息
    margin: 20px 0;
    color: $sub-font-color;
    font-size: $base-font-size;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    .post-details__name {
      //发帖人姓名
      color: $base-font-color;
    }
  }
  .el-tag {
    // 设备标签
    margin-top: 20px;
  }
}
.post-details__img {
  // 头像
  display: inline-block;
  height: 24px;
  width: 24px;
  margin: 0 3px;
  transform: translateY(-2px);
  vertical-align: middle;
}
.post-details__post-content {
  overflow: hidden;
  /deep/img {
    width: auto !important;
    height: auto !important;
    max-width: 100% !important;
  }
  /deep/ p {
    word-break: break-all;
  }
}
.post-details__statistics {
  // 数量统计
  height: 44px;
  line-height: 44px;
  border-top: 1px solid $background-color;
  border-bottom: 1px solid $background-color;
  color: $sub-font-color;
  font-size: $base-font-size;
  padding: 0 20px;
  display: flex;
  -ms-flex-pack: justify;
  justify-content: space-between;
}
</style>
