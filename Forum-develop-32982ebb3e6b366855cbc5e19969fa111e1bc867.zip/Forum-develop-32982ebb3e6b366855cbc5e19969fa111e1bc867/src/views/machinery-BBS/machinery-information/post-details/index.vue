<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-01 09:17:54
 * @LastEditTime: 2019-12-04 17:37:18
 * @Description: 帖子详情
 -->
<template>
  <div class="post-details">
    <comments
      v-bind:topic="topic"
      v-bind:topicType="topicType"
      v-bind:equipmentTypeName="equipmentTypeName"
      @event1="reload()"
    ></comments>
    <!-- 评论列表 -->
    <div class="machinery-information__list-wrapper">
      <div
        class="machinery-information__noComment"
        v-if="topic.ifReply === 'N'"
      >
        {{ $t('fornum.commentNo') }}
        <!-- $t 不支持评论 -->
      </div>
      <ul
        v-infinite-scroll="load"
        infinite-scroll-disabled="disabled"
        infinite-scroll-distance="1500px"
      >
        <li
          class="post-details__commentList"
          v-for="(item, i) in commentList"
          :key="i"
        >
          <div class="post-details__content">
            <!-- 评论人头像公司 -->
            <div class="post-details__head">
              <div>
                <img :src="defaultIcon" class="post-details__img" />
                <p>{{ item.replyPersonName }}</p>
                {{ item.tenantName }}
              </div>
            </div>
            <!-- 评论时间 -->
            <div class="post-details__time">
              <span>{{ item.replyDate }}</span>
              <span
                class="post-details__microcheiria"
                @click="replyClick(item, i)"
                >{{ $t('fornum.reply2') }}
                <!-- $t 回复 --></span
              >
            </div>
            <!-- 评论内容 -->
            <div
              v-html="decodeURI(item.replyContent)"
              class="post-details__post-content"
            ></div>
            <!-- 回复内容 -->
            <div class="post-details__response" v-if="item.intTotal !== 0">
              <div
                class="post-details__response-list"
                v-for="(int, index) in item.replyList"
                :key="index"
              >
                <!-- 回复时间 -->
                <div class="post-details__responseTime">
                  <span>{{ int.createDate }}</span>
                  <span
                    class="post-details__microcheiria"
                    @click="replyClick2(int, 2, item, i)"
                    >{{ $t('fornum.reply2') }}
                    <!-- $t 回复 --></span
                  >
                </div>
                <!-- 评论人@被评论人 -->
                <span
                  class="
                    post-details__replyinfo"
                  v-if="int.levelReplyId === int.parentReplyId"
                  >{{ int.replyPersonName }}：</span
                >
                <span class="post-details__replyinfo" v-else
                  >{{ int.replyPersonName }}@{{
                    int.returnedPersonName
                  }}：</span
                >
                {{ int.replyContent }}
              </div>
              <div
                class="post-details__total"
                @click="replyPaging(item.id, i)"
                v-if="item.replyNumber > 0"
              >
                {{ $t('fornum.common') }}
                <!-- $t 共 -->{{ item.replyNumber
                }}{{ $t('fornum.replyNumber') }}
                <!-- $t 条回复 -->
                <i class="el-icon-caret-bottom"></i>
              </div>
            </div>
            <p class="post-details__tower">
              {{ i + 1 }}{{ $t('fornum.tower') }}
              <!-- $t 楼 -->
            </p>
          </div>
        </li>
      </ul>
      <p
        class="machinery-information__loading"
        v-if="loading && commentList.length >= 10"
      >
        {{ $t('fornum.loading') }}
        <!-- $t 加载中... -->
      </p>
      <p
        class="machinery-information__loading"
        v-if="count && commentList.length >= 10"
      >
        {{ $t('fornum.noMore') }}
        <!-- $t 没有更多了 -->
      </p>
    </div>
    <!-- 回复弹框 -->
    <el-dialog
      :title="$t('fornum.reply2')"
      :visible.sync="dialogVisible2"
      width="30%"
      :before-close="handleClose"
    >
      <!-- $t 回复 -->
      <el-input
        type="textarea"
        :rows="5"
        :placeholder="$t('fornum.theInput')"
        v-model="textarea2"
        maxlength="100"
      >
        <!-- $t 请输入内容 -->
      </el-input>
      <div class="post-details__uploading">
        <span> </span>
        <span>{{ textarea2.length }}/100</span>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitComments2()"
          >{{ $t('fornum.submit') }}
          <!-- $t 提交 -->
        </el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import {
  bbsTopicDetail,
  getAllEquipmentType,
  bbsReplySave,
  queryByLevelParent
} from '@/api/forum'
import comments from './comments'
export default {
  name: 'post-details',
  components: { comments },
  inject: ['reload'], // 注入页面刷新方法
  data() {
    return {
      pageNum: 1, // 分页
      pageSize: 10,
      pageNum2: 1, // 分页
      pageSize2: 3,
      loading: false, // 控制分页字段的显示隐藏
      count: false,
      textarea: '', // 评论文本内容
      dialogVisible2: false, // 控制回复弹框的显示和隐藏
      defaultIcon: require('@/assets/img/defaultIcon.png'), // 用户头像图标
      topic: {}, // 帖子详情数据
      topicTypeList: '', // 帖子类型
      equipmentTypeName: '', // 设备类型
      topicType: '', // 帖子类型
      clear: false, // 通知图片上传组件自己清除图片列表
      echoEchoList: [],
      echoEchoListid: [],
      commentList: [], // 评论列表
      textarea2: '', // 回复框数据
      rollIf: true //控制是否分页
    }
  },
  computed: {
    disabled() {
      return this.loading || this.count
    }
  },
  methods: {
    /**
     * @Description: 回复弹框关闭触发
     * @Author: 肖巧伦
     * @Desc: 清空数据
     */
    handleClose() {
      this.dialogVisible2 = false
      this.textarea2 = ''
    },
    /**
     * @Description: 评论列表滑至底部触发
     * @Author: 肖巧伦
     * @Desc: 无限滚动加载
     */
    load() {
      this.loading = true
      if (!this.count) {
        this.loading = false
        this.bbsTopicDetailAxios()
        if (this.topic) {
          this.getAllEquipmentTypeAxios()
        }
        this.pageNum++
      }
    },
    /**
     * * @Description: 点击一层回复触发
     * *@Author: 肖巧伦
     * * @Desc: 保存回复层数据
     * */
    replyClick(item, i) {
      if (this.topic.ifReply === 'Y') {
        this.commentData = item // 存储当前父级层数据
        this.dialogVisible2 = true
        this.indexs = i // 存储当前索引号
      }
    },
    /**
     * * @Description: 点击二层回复触发
     * *@Author: 肖巧伦
     * * @Desc: 保存回复层数据
     * */
    replyClick2(item, id, date, i) {
      if (this.topic.ifReply === 'Y') {
        this.replyThree = id // 存储辨识几层回复的数据
        this.hierarchy = date // 存储层级数据
        this.commentData = item // 存储当前父级层数据
        this.dialogVisible2 = true
        this.indexs = i // 存储当前索引号
      }
    },
    /**
     * @Description: 提交回复触发
     * @Author: 肖巧伦
     */
    async submitComments2() {
      try {
        this.textarea2 = this.textarea2.trim()
        if (this.textarea2.length !== 0) {
          if (this.replyThree === 2) {
            // 如果是回复的回复
            await bbsReplySave({
              topicId: this.commentData.topicId,
              replyType: '2',
              parentReplyId: this.commentData.id,
              replyPersonId: this.$store.getters.userInfo.attachmentId,
              replyContent: this.textarea2,
              levelReplyId: this.hierarchy.id,
              returnedPersonName: this.commentData.replyPersonName,
              returnedPersonId: this.commentData.replyPersonId
            })
            this.$message.success(this.$t('fornum.replySucceed')) // $t 回复成功
            this.$forceUpdate()
            this.textarea2 = '' // 清空内容
            this.dialogVisible2 = false
            // 刷新回复数据
            this.queryByLevelParentAxios(
              this.hierarchy.id,
              this.indexs,
              this.hierarchy.pageSize
            )
          } else {
            await bbsReplySave({
              topicId: this.commentData.topicId,
              replyType: '2',
              parentReplyId: this.commentData.id,
              replyPersonId: this.$store.getters.userInfo.attachmentId,
              replyContent: this.textarea2,
              levelReplyId: this.commentData.id,
              returnedPersonName: this.commentData.replyPersonName,
              returnedPersonId: this.commentData.replyPersonId
            })
            this.$message.success(this.$t('fornum.replySucceed')) // $t 回复成功
            this.$forceUpdate()
            this.textarea2 = '' // 清空内容
            this.dialogVisible2 = false
            // 刷新回复数据
            this.queryByLevelParentAxios(
              this.commentData.id,
              this.indexs,
              this.commentData.pageSize
            )
          }
        } else {
          this.$message.error(this.$t('fornum.replyNull')) // $t 回复内容不能为空
        }
      } catch (error) {
        throw error
      }
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取所有设备类型
     */
    async getAllEquipmentTypeAxios() {
      try {
        const data = await getAllEquipmentType()
        data.equipmentTypes.forEach(item => {
          if (item.equipmentTypeCode === this.topic.deviceType) {
            this.equipmentTypeName = item.equipmentTypeName // 存储设备类型
          }
        })
        this.topicTypeList = this.$getDataDic('topicType')
        for (let key in this.topicTypeList) {
          if (this.topic.topicType === key) {
            this.topicType = this.topicTypeList[key] // 存储帖子类型
          }
        }
      } catch (error) {
        throw error
      }
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取帖子评论数据/详情
     */
    async bbsTopicDetailAxios() {
      if (this.rollIf) {
        try {
          const data = await bbsTopicDetail({
            topicId: this.$route.query.postId,
            pageNum: this.pageNum,
            pageSize: this.pageSize
          })
          this.topic = data.topic
          data.list.length < 10 ? (this.rollIf = false) : ''
          if (data.list.length === 0) {
            // 如果获取的列表为空了
            this.count = true
            this.loading = false
          } else {
            // 存储评论层数据
            data.list.forEach(item => {
              item.pageSize = 3
              this.commentList.push(item) // 存储评论层数据
            })
            if (this.commentList) {
              // 循环获取回复区数据
              this.commentList.forEach((item, i) => {
                this.queryByLevelParentAxios(item.id, i, item.pageSize)
              })
            }
          }
        } catch (error) {
          throw error
        }
      }
    },
    /**
     * @Description: 点击共xxx条回复触发
     * @Author: 肖巧伦
     * @Desc: 显示更多回复数据
     */
    replyPaging(int, i) {
      this.commentList[i].pageSize += 3
      this.queryByLevelParentAxios(int, i, this.commentList[i].pageSize)
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取回复的回复数据
     */
    async queryByLevelParentAxios(id, i, pageSize) {
      try {
        const data = await queryByLevelParent({
          levelReplyId: id,
          pageNum: 1,
          pageSize: pageSize
        })
        let arr = []
        data.list.forEach(item => {
          arr.push(item)
        })
        this.commentList[i].replyList = arr
        this.commentList[i].intTotal = data.total // 存储回复总数
        this.commentList[i].replyNumber = data.total - arr.length // 存储未展示的回复总数
        this.$forceUpdate()
      } catch (error) {
        throw error
      }
    }
  }
}
</script>
<style lang="scss" scoped>
// element ui 弹框 背景
.post-details {
  width: 820px;
  height: 90%;
  overflow: auto;
  margin: 10px auto;
  background-color: #fff;
  .post-details__post-content {
    overflow: hidden;
    /deep/img {
      width: auto !important;
      height: auto !important;
      max-width: 100% !important;
    }
    /deep/p {
      word-break: break-all;
    }
  }
  // 滚动组件
  .machinery-information__list-wrapper {
    // 不支持评论
    .machinery-information__noComment {
      height: 200px;
      line-height: 200px;
      text-align: center;
      color: $sub-font-color;
      font-size: $base-font-size;
    }
    .machinery-information__loading {
      height: 44px;
      text-align: center;
      line-height: 44px;
      color: $date-icon-color;
      font-size: $base-font-size;
    }
  }
  li {
    list-style: none;
  }
  /deep/.zl-upload-abnormal > div {
    display: flex;
    flex-wrap: wrap;
  }
  /deep/.el-upload-list {
    display: flex;
    flex-wrap: wrap;
  }
  .post-details__microcheiria {
    cursor: pointer;
  }
  .post-details__img {
    display: inline-block;
    height: 24px;
    width: 24px;
    margin: 0 3px;
    transform: translateY(-2px);
    vertical-align: middle;
  }
  .post-details__uploading,
  .post-details__time,
  .post-details__responseTime {
    // 数量统计
    height: 44px;
    line-height: 44px;
    border-top: 1px solid $background-color;
    border-bottom: 1px solid $background-color;
    color: $sub-font-color;
    font-size: $base-font-size;
    padding: 0 20px;
    display: flex;
    -ms-flex-pack: justify;
    justify-content: space-between;
  }
  .post-details__uploading {
    border: 0;
  }
  .post-details__commentList {
    // 评论列表
    border-bottom: 1px solid $background-color;
    .post-details__content {
      // 评论内容
      position: relative;
      width: 640px;
      margin-left: 160px;
      padding: 15px;
      border-left: 1px solid $background-color;
      color: $sbr-font-color;
      font-size: $base-font-size;
      .post-details__response {
        // 回复
        width: 100%;
        background-color: #fafafa;
        margin-top: 15px;
        padding: 10px;
        font-size: $base-font-size;
        color: $base-font-color;
        line-height: 19px;
        .post-details__total {
          // 回复条数
          cursor: pointer;
          width: 100%;
          text-align: center;
          height: 30px;
          line-height: 30px;
          color: $sub-font-color;
          font-size: $sub-font-size;
        }
        .post-details__response-list {
          margin-bottom: 13px;
          .post-details__responseTime {
            // 回复时间
            padding: 0;
            border: 0;
            font-size: $sub-font-size;
            height: 20px;
            line-height: 20px;
            margin-bottom: 5px;
          }
          .post-details__replyinfo {
            // 回复人@评论人
            color: #607d8b;
          }
        }
      }
      .post-details__tower {
        // 楼层数
        margin-top: 25px;
        color: $sub-font-color;
        font-size: $sub-font-size;
      }
      .post-details__time {
        // 评论时间
        padding: 0;
        border: 0;
        font-size: $sub-font-size;
      }
      .post-details__head {
        // 评论人信息
        text-align: center;
        width: 160px;
        height: 100%;
        position: absolute;
        top: 0;
        left: -160px;
        div {
          // 头像和公司信息
          width: 80px;
          text-align: center;
          color: $sub-font-color;
          font-size: $sub-font-size;
          position: absolute;
          line-height: 18px;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          p {
            color: $base-font-color;
          }
        }
      }
    }
  }
}
</style>
