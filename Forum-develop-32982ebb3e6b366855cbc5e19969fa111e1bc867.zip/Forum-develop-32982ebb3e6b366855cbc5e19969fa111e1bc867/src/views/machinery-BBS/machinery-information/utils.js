function anascityData(data) {
  const provinceData = []
  const cityData = []
  const zone = []
  for (const item in data) {
    // 匹配以0000结尾的数据为省份
    if (item.match(/0000$/)) {
      provinceData.push({
        value: item,
        label: data[item],
        children: []
      })
      // 匹配以00结尾的数据为市
    } else if (item.match(/00$/)) {
      cityData.push({
        value: item,
        label: data[item],
        children: []
      })
    } else {
      // 市里面的区域
      zone.push({
        value: item,
        label: data[item]
      })
    }
  }
  // 将某省下的所有市都放到provinceData里面children列表中
  for (const index in provinceData) {
    for (const index1 in cityData) {
      if (
        provinceData[index].value.slice(0, 2) ===
        cityData[index1].value.slice(0, 2)
      ) {
        provinceData[index].children.push(cityData[index1])
      }
    }
  }
  // 将某市下的所有区都放到cityData里面children列表中
  for (const item1 in cityData) {
    for (const item2 in zone) {
      if (zone[item2].value.slice(0, 4) === cityData[item1].value.slice(0, 4)) {
        cityData[item1].children.push(zone[item2])
      }
    }
  }
  // 最后到处对应的数据结构
  return {
    provinceData,
    cityData
  }
}

export { anascityData }
