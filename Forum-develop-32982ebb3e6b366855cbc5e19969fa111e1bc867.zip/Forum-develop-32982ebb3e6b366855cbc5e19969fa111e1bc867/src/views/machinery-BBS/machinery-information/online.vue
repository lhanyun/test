<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-30 11:49:55
 * @Description: 网点列表
 -->
<template>
  <div>
    <!-- 无数据显示 -->
    <div
      class="machinery-information__invitation"
      v-if="serviceNetwork.length === 0"
    >
      {{ $t('fornum.noData') }}
      <!-- $t 暂时没有数据... -->
    </div>
    <ul class="machinery-information__list-wrapper">
      <ul v-infinite-scroll="load2" infinite-scroll-disabled="disabled2">
        <li
          class="machinery-information__store"
          v-for="(item, i) in serviceNetwork"
          :key="i"
        >
          <h4>{{ item.name }}</h4>
          <p>{{ item.linkman }} | {{ item.linkmanPhone }}</p>
          <p>{{ item.industryCodes }}</p>
          {{ $t('fornum.address') }}
          <!-- $t 详细地址 -->
          ：{{ item.province + item.city + item.district + item.address }}
        </li>
      </ul>
      <p
        class="machinery-information__loading"
        v-if="loading2 && serviceNetwork.length >= 10"
      >
        {{ $t('fornum.loading') }}
        <!-- $t 加载中... -->
      </p>
      <p
        class="machinery-information__loading"
        v-if="count2 && serviceNetwork.length >= 10"
      >
        {{ $t('fornum.noMore') }}
        <!-- $t 没有更多了 -->
      </p>
    </ul>
  </div>
</template>
<script>
export default {
  name: 'online',
  props: ['serviceNetwork', 'disabled2', 'loading2', 'count2'],
  methods: {
    load2() {
      this.$emit('func2')
    }
  }
}
</script>
<style lang="scss" scoped>
.machinery-information__invitation {
  padding: 20px;
  border-bottom: 1px solid $background-color;
  color: $base-font-color;
  font-size: $base-font-size;
  cursor: pointer;
}
// 滚动组件
.machinery-information__list-wrapper {
  width: 800px;
  height: 85%;
  position: fixed;
  overflow: auto;
  background-color: $white;
  .machinery-information__loading {
    height: 44px;
    text-align: center;
    line-height: 44px;
    color: $date-icon-color;
    font-size: $base-font-size;
  }
}
// 销售网点
.machinery-information__store {
  padding: 20px;
  border-bottom: 1px solid $background-color;
  font-size: $base-font-size;
  color: $sub-font-color;
  cursor: pointer;
  h4 {
    font-size: $btr-font-size;
    color: $sbr-font-color;
  }
  p {
    margin: 12px 0;
  }
}
</style>
