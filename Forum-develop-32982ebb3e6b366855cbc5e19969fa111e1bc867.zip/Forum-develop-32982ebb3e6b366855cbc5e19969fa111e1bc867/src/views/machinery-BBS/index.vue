<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-01 09:17:54
 * @LastEditTime: 2019-12-05 17:35:24
 * @Description: 农机信息
 -->
<template>
  <div class="machinerybbs">
    <!-- 导航栏 -->
    <div class="machinerybbs__nav">
      <div class="machinerybbs__centre">
        <zv-svg-icon iconClass="luntan" class="machinerybbs__icon" />
        <!-- 农机信息 -->
        <h5>
          {{ $t('fornum.farmingMessage') }}
          <!-- $t 农机信息 -->
        </h5>
        <el-dropdown trigger="click" @command="handleCommand">
          <span class="machinerybbs__dropdown-link">
            {{ $t('fornum.machineryManagement') }}
            <!-- $t 农机管理 --><i
              class="el-icon-caret-bottom el-icon--right"
            ></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="machinery-information">
              {{ $t('fornum.homePage') }}
              <!-- $t 首页 -->
            </el-dropdown-item>
            <el-dropdown-item command="post-reply">
              {{ $t('fornum.my') }}
              <!-- $t 我的 -->
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <!-- 输入框 -->
        <zv-search
          v-if="show1"
          v-model="inputVal"
          :placeholder="$t('fornum.EnterSearch')"
        /><!-- $t 请输入搜索内容 -->
      </div>
    </div>
    <router-view :inputVal="inputVal" @haa="esim" />
  </div>
</template>
<script>
export default {
  name: 'machinery-BBS',
  data() {
    return {
      inputVal: '',
      // 用户头像图标
      defaultIcon: require('@/assets/img/defaultIcon.png'),
      show1: true
    }
  },
  methods: {
    esim(data) {
      this.show1 = data
    },
    /**
     * @Description: 点击下拉框选项触发
     * @Author: 肖巧伦
     * @Desc: 跳转至指定页面
     */
    handleCommand(command) {
      this.$router.push({ name: command })
    }
  }
}
</script>

<style lang="scss" scoped>
.machinerybbs {
  position: relative;
  height: 100%;
  background-color: $mainBg;
  // 字体图标
  .zv-svg-icon {
    width: $header-icon-size;
    height: $header-icon-size;
    color: #212121;
  }
  .machinerybbs__icon {
    width: 20px;
    height: 20px;
    position: relative;
    top: 3px;
    left: 0;
  }
  // 顶部导航栏
  .machinerybbs__nav {
    width: 100%;
    height: 44px;
    line-height: 44px;
    background-color: $white;
    border-bottom: 1px solid $background-color;
    // 导航栏版心
    .machinerybbs__centre {
      position: relative;
      width: 1135px;
      margin: 0 auto;
      // 输入框
      .zv-search {
        float: right;
        transform: translateY(5px);
        // 输入框内容
        /deep/.el-input__inner {
          font-size: $sub-font-size !important;
        }
      }
      // 农机信息
      h5 {
        display: inline-block;
        font-size: 15px;
        color: $base-font-color;
      }
      // 图标
      .machinerybbs__img {
        height: 24px;
        width: 24px;
        margin: 0 3px;
        transform: translateY(-1px);
        vertical-align: middle;
      }
      // 农机信息
      .machinerybbs__dropdown-link {
        cursor: pointer;
        color: #333;
        margin-left: 20px;
        padding-left: 20px;
        border-left: 1px solid #ccc;
        font-size: 14px;
        // 三角图标
        .el-icon--right {
          color: #8b8b8b;
        }
      }
    }
  }
}
</style>
