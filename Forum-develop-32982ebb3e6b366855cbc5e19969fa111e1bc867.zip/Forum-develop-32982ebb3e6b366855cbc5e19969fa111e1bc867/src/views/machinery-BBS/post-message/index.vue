<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-01 09:17:54
 * @LastEditTime: 2019-11-26 16:04:03
 * @Description: 论坛发帖
 -->
<template>
  <div class="post-message">
    <!-- 标题 -->
    <div class="post-message__title">
      <span>
        {{ $t('fornum.EditPost') }}
        <!-- $t 编辑帖子 -->
      </span>
      <span>
        <zv-button @click="$router.go(-1)">
          {{ $t('fornum.goBack') }}
          <!-- $t 返回 -->
        </zv-button>
        <zv-button type="primary" @click="submit">
          {{ $t('fornum.submit') }}
          <!-- $t 提交 -->
        </zv-button>
      </span>
    </div>
    <!-- 表单 -->
    <zv-dymanic-form
      ref="dymanicForm"
      type="block"
      v-model="value1"
      :schema="schema1"
    />
    <!-- 富文本 -->
    <div class="post-message__editor">
      <tinymce-editor
        ref="editor"
        v-model="ruleForm.contentText"
        @imgUrl="imgUrl"
        :disabled="disabled"
      />
    </div>
  </div>
</template>
<script>
import { getAllEquipmentType, bbsTopicSave, bbsTopicDetail } from '@/api/forum'
import tinymceEditor from '@/components/zl-tinymce-editor/index'
export default {
  name: 'post-message',
  components: { tinymceEditor },
  data() {
    return {
      disabled: false,
      // 表单选择数据
      value1: {},
      schema1: {
        post: {
          componentName: 'ZvSelectLabel',
          // 筛选数据
          options: [],
          placeholder: this.$t('fornum.postClassification'), // $t 帖子分类
          componentType: 'Select',
          isRequired: true,
          clearable: true,
          validator: [['checkRequired', { msg: this.$t('fornum.postNull') }]] // $t 帖子分类不能为空
        },
        equipment: {
          componentName: 'ZvSelectLabel',
          //筛选数据
          options: [],
          placeholder: this.$t('fornum.equipmentClassification'), // $t 设备分类
          componentType: 'Select',
          isRequired: true,
          clearable: true,
          validator: [
            ['checkRequired', { msg: this.$t('fornum.equipmentNull') }]
          ] // $t 设备分类不能为空
        },
        comment: {
          componentName: 'ZvSelectLabel',
          // 筛选数据
          options: [
            {
              value: 'Y',
              label: this.$t('fornum.yes') // $t 是
            },
            { value: 'N', label: this.$t('fornum.no') } // $t 否
          ],
          clearable: true,
          placeholder: this.$t('fornum.whether'), // $t 是否支持评论
          componentType: 'Select',
          isRequired: true,
          validator: [
            [
              'checkRequired',
              {
                msg: this.$t('fornum.commentNull') // $t 评论设置不能为空
              }
            ]
          ]
        },
        title: {
          componentName: 'ZvInput',
          placeholder: this.$t('fornum.postTitle'), // $t 帖子标题
          widthType: 'big',
          labelTop: true,
          required: true,
          showBorder: true,
          rules: [
            {
              validator: (rule, value, callback) => {
                if (value === '') {
                  callback(new Error(this.$t('fornum.titleNull'))) // $t 标题不能为空
                } else {
                  callback()
                }
              },
              trigger: 'blur'
            }
          ]
        }
      },
      // 帖子分类数据
      topicTypeList: [],
      // 富文本参数
      ruleForm: {
        locale: '',
        //语言
        productNames: '',
        // 产品
        menuName: '',
        // 菜单应用
        isCommon: '',
        //应用通用
        archivesTag: [],
        // 标签数据
        content: '',
        title: '',
        helpStatus: '',
        contentText: '',
        imgId: []
      }
    }
  },
  mounted() {
    this.getAllEquipmentTypeAxios()
    //存储帖子分类
    this.topicTypeList = this.$getDataDic('topicType')
    //循环渲染至页面
    for (let key in this.topicTypeList) {
      this.schema1.post.options.push({
        value: key,
        label: this.topicTypeList[key]
      })
    }
    // 如果是编辑页  带了id
    if (this.$route.query.id) {
      this.bbsTopicDetailAxios()
    }
  },
  methods: {
    /**
     * * @Description: 调用触发
     * *@Author: 肖巧伦
     * * @Desc: 获取帖子详情
     * */
    async bbsTopicDetailAxios() {
      try {
        const data = await bbsTopicDetail({
          topicId: this.$route.query.id
        })
        // 渲染至页面
        this.ruleForm.contentText = decodeURI(data.topic.topicContent)
        this.value1.title = data.topic.topicTitle
        this.value1.comment = data.topic.ifReply
        this.value1.equipment = data.topic.deviceType
        this.value1.post = data.topic.topicType
      } catch (error) {
        throw error
      }
    },
    /**
     * * @Description: 父组件传值触发
     * *@Author: 肖巧伦
     * * @Desc: 获取富文本上传图片
     * */
    imgUrl(data) {
      this.ruleForm.imgId = data
    },
    /**
     * * @Description: 调用触发
     * * @Author:肖巧伦
     * * @Desc: 获取设备数据
     * */
    async getAllEquipmentTypeAxios() {
      try {
        const data = await getAllEquipmentType()
        data.equipmentTypes.forEach(item => {
          this.schema1.equipment.options.push({
            value: item.equipmentTypeCode,
            label: item.equipmentTypeName
          })
        })
      } catch (error) {
        throw error
      }
    },
    /**
     * * @Description: 点击提交触发
     * * @Author:肖巧伦
     * * @Desc: 提交
     **/
    submit() {
      // 去除标题左右空格
      this.value1.title = this.value1.title.trim()
      // 过滤富文本标签
      const str = this.ruleForm.contentText
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/gi, '')
        .trim()
      this.$refs.dymanicForm.validate().then(async res => {
        try {
          if (res && str.length !== 0) {
            await bbsTopicSave({
              id: this.$route.query.id,
              topicType: this.value1.post,
              deviceType: this.value1.equipment,
              topicTitle: this.value1.title,
              ifReply: this.value1.comment,
              topicContent: encodeURI(this.ruleForm.contentText)
            })
            if (this.$route.query.id) {
              this.$message.success(this.$t('fornum.editSuccess')) // $t 编辑成功
              this.$router.push({ name: 'post-reply' })
            } else {
              this.$message.success(this.$t('fornum.postSuccess')) // $t 发帖成功
              this.$router.push({ name: 'forum' })
            }
          } else {
            this.$message.error(this.$t('fornum.contentNull')) // $t 内容不能为空
          }
        } catch (error) {
          throw error
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.post-message {
  width: 800px;
  background-color: #fff;
  margin: 10px auto;
  // 标题
  .post-message__title {
    height: 44px;
    line-height: 44px;
    border-bottom: 1px solid $background-color;
    font-size: $btr-font-size;
    color: $sbr-font-color;
    padding: 0 15px;
    margin-bottom: 10px;
    // 盒子两端对齐
    display: flex;
    -ms-flex-pack: justify;
    justify-content: space-between;
  }
  // 筛选框
  /deep/.zv-select-label.default {
    width: 245px;
    margin-left: 16px;
  }
  /deep/.zv-dymanic__form .zv-dymanic-form__item .el-form-item {
    min-width: 200px;
  }
  /deep/.zv-dymanic__form .zv-dymanic-form__item {
    min-width: 200px;
  }
  // 输入框
  /deep/.zv-input--border {
    width: 768px;
    margin-left: 16px;
  }
  /deep/.el-form-item__error {
    margin: 0 20px;
  }
  // 富文本
  .post-message__editor {
    padding: 16px;
  }
}
</style>
