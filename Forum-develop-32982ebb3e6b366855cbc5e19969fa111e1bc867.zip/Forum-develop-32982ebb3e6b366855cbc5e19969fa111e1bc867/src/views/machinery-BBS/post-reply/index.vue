<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-01 09:17:54
 * @Description: 发表/回复列表
 -->
<template>
  <div class="post-reply">
    <div class="post-reply__left">
      <!-- 发帖按钮 -->
      <div class="post-reply__left-btn">
        <zv-button plain icon="bianji" @click="postPush()">
          {{ $t('fornum.postd') }}
          <!-- $t 发帖 -->
        </zv-button>
      </div>
      <!-- tabs组件 -->
      <zv-tabs v-model="activeName" :tab-pane="tabPane">
        <div class="post-reply__tabs" slot="publish">
          <published></published>
        </div>
        <div class="post-reply__tabs" slot="reply">
          <!-- 滑动组件 -->
          <div class="machinery-information__list-wrapper">
            <ul v-infinite-scroll="load2" infinite-scroll-disabled="disabled2">
              <!-- 我的回复列表 -->
              <li
                class="post-reply__first"
                v-for="(item, index) in myReplyList"
                :key="index"
              >
                <div class="post-reply__first-top">
                  <!-- 回复帖子标题 -->
                  <div class="post-reply__first-title">
                    [{{ item.topicDto.topicType }}]{{
                      item.topicDto.topicTitle
                    }}
                    &nbsp;＞
                  </div>
                  <!-- 状态 -->
                  <el-tag
                    class="post-reply__first-tag"
                    :type="states(item.replyStatus).type"
                  >
                    {{ states(item.replyStatus).topicStatus }}
                  </el-tag>
                </div>
                <!-- 回复内容 -->
                <div
                  class="post-reply__first-center"
                  v-html="decodeURI(item.replyContent)"
                ></div>
                <div class="post-reply__first-botton">
                  <!-- 回复时间和删除icon -->
                  <div class="post-reply__first-left">
                    {{ item.replyDate }}
                  </div>
                  <div class="post-reply__first-right">
                    <zv-svg-icon
                      icon-class="shanchu"
                      class="post-reply__first-shanchu"
                      @click.native="_onDelete2(item.id)"
                    />
                  </div>
                </div>
              </li>
            </ul>
            <p
              class="machinery-information__loading"
              v-if="loading2 && myReplyList.length >= 10"
            >
              {{ $t('fornum.loading') }}
              <!-- $t 加载中... -->
            </p>
            <p
              class="machinery-information__loading"
              v-if="count2 && myReplyList.length >= 10"
            >
              {{ $t('fornum.noMore') }}
              <!-- $t 没有更多了 -->
            </p>
          </div>
        </div>
      </zv-tabs>
    </div>
  </div>
</template>
<script>
import { onMyReply, getAllEquipmentType, bbsReplyDelete } from '@/api/forum'
import published from './published'
export default {
  name: 'post-reply',
  components: { published },
  data() {
    return {
      //tabs组件参数
      activeName: 'publish',
      //tabs组件参数
      tabPane: [
        {
          label: this.$t('fornum.publish'), // $t 我发表的
          name: 'publish'
        },
        {
          label: this.$t('fornum.reply'), // $t 我的回复
          name: 'reply'
        }
      ],
      //我的回复数组
      myReplyList: [],
      equipmentTypes: '',
      topicTypeList: '',
      // 分页数据
      pageNum2: 1,
      pageSize2: 10,
      loading2: false,
      count2: false,
      show1: false
    }
  },
  computed: {
    disabled2() {
      return this.loading2 || this.count2
    }
  },
  async created() {
    this.$emit('haa', this.show1)
    // 获取所有设备类型
    const data = await getAllEquipmentType()
    this.equipmentTypes = data.equipmentTypes
    // 存储筛选类型
    this.topicTypeList = this.$getDataDic('topicType')
    this._onMyReply()
  },
  destroyed() {
    this.show1 = true
    this.$emit('haa', this.show1)
  },
  methods: {
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 过滤帖子状态
     */
    states(its) {
      if (its === '1') {
        return {
          type: 'info',
          topicStatus: this.$t('fornum.audit') // $t 审核中
        }
      } else if (its === '2') {
        return {
          type: 'success',
          topicStatus: this.$t('fornum.issue') // $t 已发布
        }
      } else if (its === '3') {
        return {
          type: 'danger',
          topicStatus: this.$t('fornum.rejectyin') // $t 被驳回
        }
      }
    },
    /**
     * @Description: 我的回复滑动底部触发
     * @Author: 肖巧伦
     * @Desc: 分页加载
     */
    load2() {
      this.loading2 = true
      if (!this.count2) {
        setTimeout(() => {
          this.pageNum2++
          this.loading2 = false
          this._onMyReply()
        }, 2000)
      }
    },
    /**
     * @Description: 点击发帖/编辑触发
     * @Author: 肖巧伦
     */
    postPush() {
      this.$router.push({ name: 'post-message' })
    },
    /**
     * @Description: 点击回复删除icon
     * @Author: 肖巧伦
     * @Desc: 删除我的回复
     */
    _onDelete2(id) {
      this.$confirm(
        this.$t('fornum.confirmTheDeletion'), // $t 您确认删除该贴吗？
        this.$t('fornum.confirmDel'), // $t 确认删除
        {
          confirmButtonText: this.$t('fornum.confirm'), // $t 确定
          cancelButtonText: this.$t('fornum.cancel'), // $t 取消
          type: 'warning'
        }
      )
        .then(() => {
          this.$message.success(this.$t('fornum.haveDeleted')) // $t 已删除
          bbsReplyDelete({ id }).then(() => {
            this.myReplyList = []
            this.pageNum2 = 1
            // 刷新我的回复
            this._onMyReply()
          })
        })
        .catch(() => {
          this.$message.info(this.$t('fornum.Deletecancel')) // $t 已取消删除
        })
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取我的回复
     */
    _onMyReply() {
      if (this.equipmentTypes) {
        onMyReply({
          pageNum: this.pageNum2,
          pageSize: this.pageSize2
        }).then(res => {
          if (res.list.length === 0) {
            this.count2 = true
            this.loading2 = false
          } else {
            res.list.forEach(item => {
              this.myReplyList.push(item)
              // 循环过滤帖子类型
              for (let key in this.topicTypeList) {
                if (item.topicDto.topicType === key) {
                  item.topicDto.topicType = this.topicTypeList[key]
                }
              }
            })
          }
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
li {
  list-style-type: none;
}
// 滚动组件
.machinery-information__list-wrapper {
  width: 800px;
  height: 85%;
  position: fixed;
  overflow: auto;
  background-color: $white;
  .machinery-information__loading {
    height: 44px;
    text-align: center;
    line-height: 44px;
    color: $date-icon-color;
    font-size: $base-font-size;
  }
}
.post-reply {
  margin: 10px auto;
  width: 800px;
  background-color: #fff;

  .post-reply__tabs {
    width: 100%;
  }
  .post-reply__left {
    width: 800px;
    background-color: $white;
    position: relative;
    .post-reply__left-btn {
      z-index: 1;
      position: absolute;
      top: 5px;
      right: 15px;
    }
  }
  .post-reply__first {
    margin-top: 20px;
    min-height: 40px;
    padding: 4px 24px 27px;
    box-sizing: border-box;
    border-bottom: 1px solid #e4e7ed;
    .post-reply__first-text {
      float: left;
      width: 650px;
      overflow: hidden; //溢出隐藏
      text-overflow: ellipsis; //超出部分裁剪
      white-space: nowrap; //不换行
      font-family: MicrosoftYaHei;
      font-size: 16px;
      font-weight: bold;
      color: #212121;
    }
    // 回复帖子的标题
    .post-reply__first-title {
      max-width: 650px;
      overflow: hidden; //溢出隐藏
      text-overflow: ellipsis; //超出部分裁剪
      white-space: nowrap; //不换行
      padding: 0 8px;
      font-size: 12px;
      float: left;
      height: 24px;
      line-height: 24px;
      color: #8b8b8b;
      background-color: #f5f5f5;
    }
    .post-reply__first-tag {
      float: right;
      width: 52px;
      height: 20px;
      line-height: 20px;
      text-align: center;
    }
    // 回复内容
    .post-reply__first-center {
      margin-top: 35px;
      min-height: 20px;
      font-size: 14px;
      color: #212121;
      overflow: hidden;
      // 帖子内的图片 等比例缩放
      /deep/img {
        width: auto !important;
        height: auto !important;
        max-width: 100% !important;
      }
    }
    .post-reply__first-botton {
      margin-top: 16px;
      color: #8b8b8b;
      font-size: 14px;
      .post-reply__first-left {
        float: left;
      }
      // 删除和编辑图标
      .post-reply__first-right {
        position: absolute;
        right: 15px;
        width: 60px;
        .post-reply__first-shanchu {
          float: right;
        }
      }
    }
  }
}
</style>
