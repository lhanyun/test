<!--
 * @Author: 肖巧伦
 * @Date: 2019-11-29 17:57:19
 * @Description: 我的发表
 -->
<template>
  <div>
    <!-- 滑动组件 -->
    <div class="machinery-information__list-wrapper">
      <ul v-infinite-scroll="load" infinite-scroll-disabled="disabled">
        <!-- 我的表发列表 -->
        <li
          class="post-reply__first"
          v-for="(item, index) in myTopicsList"
          :key="index"
        >
          <div class="post-reply__first-top">
            <!-- 帖子标题 -->
            <div class="post-reply__first-text" @click="clickList(item.id)">
              [{{ item.topicType }}] {{ item.topicTitle }}
            </div>
            <!-- 状态 -->
            <el-tag
              class="post-reply__first-tag"
              :type="states(item.topicStatus).type"
            >
              {{ states(item.topicStatus).topicStatus }}
            </el-tag>
          </div>
          <!-- 帖子内容 -->
          <div class="post-reply__first-center" @click="clickList(item.id)">
            {{ item.topicContent }}
          </div>
          <!-- 发表详情 -->
          <div class="post-reply__first-botton">
            <div class="post-reply__first-left">
              {{ item.deviceType }}/{{ item.createDate }}
            </div>
            <div class="post-reply__first-right">
              <zv-svg-icon
                icon-class="bianji"
                @click.native="postPush(item.id)"
              />
              <zv-svg-icon
                icon-class="shanchu"
                class="post-reply__first-shanchu"
                @click.native="_onDelete(item.id)"
              />
            </div>
          </div>
        </li>
      </ul>
      <p
        class="machinery-information__loading"
        v-if="loading && myTopicsList.length >= 10"
      >
        {{ $t('fornum.loading') }}
        <!-- $t 加载中... -->
      </p>
      <p
        class="machinery-information__loading"
        v-if="count && myTopicsList.length >= 10"
      >
        {{ $t('fornum.noMore') }}
        <!-- $t 没有更多了 -->
      </p>
    </div>
  </div>
</template>
<script>
import { onDelete, onMyTopics, getAllEquipmentType } from '@/api/forum'
export default {
  name: 'published',
  data() {
    return {
      // 分页数据
      pageNum: 1,
      pageSize: 10,
      loading: false,
      count: false,
      //我的帖子数组
      myTopicsList: [],
      equipmentTypes: '',
      topicTypeList: ''
    }
  },
  computed: {
    disabled() {
      return this.loading || this.count
    }
  },
  async created() {
    // 获取所有设备类型
    const data = await getAllEquipmentType()
    this.equipmentTypes = data.equipmentTypes
    // 存储筛选类型
    this.topicTypeList = this.$getDataDic('topicType')
    this._onMyTopics()
  },
  methods: {
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 获取我的发表
     */
    _onMyTopics() {
      // 如果有设备数据
      if (this.equipmentTypes) {
        onMyTopics({
          pageNum: this.pageNum,
          pageSize: this.pageSize
        }).then(res => {
          // 如果请求数据数组为空
          if (res.list.length === 0) {
            this.count = true
            this.loading = false
          } else {
            res.list.forEach(item => {
              // 过滤富文本标签
              item.topicContent = decodeURI(item.topicContent)
                .replace(/<[^>]+>/g, '')
                .replace(/&nbsp;/gi, '')
                .replace(/&ldquo;/gi, '')
                .replace(/&rdquo;/gi, '')
              this.myTopicsList.push(item)
              // 循环修改设备类型
              this.equipmentTypes.forEach(int => {
                if (int.equipmentTypeCode === item.deviceType) {
                  item.deviceType = int.equipmentTypeName
                }
              })
              // 循环过滤帖子类型
              for (let key in this.topicTypeList) {
                if (item.topicType === key) {
                  item.topicType = this.topicTypeList[key]
                }
              }
            })
          }
        })
      }
    },
    /**
     * @Description: 我的发表滑动底部触发
     * @Author: 肖巧伦
     * @Desc: 分页加载
     */
    load() {
      this.loading = true
      if (!this.count) {
        setTimeout(() => {
          this.pageNum++
          this.loading = false
        }, 2000)
        this._onMyTopics()
      }
    },
    /**
     * @Description: 点击发表删除icon
     * @Author: 肖巧伦
     * @Desc: 删除我的发表
     */
    _onDelete(id) {
      this.$confirm(
        this.$t('fornum.confirmTheDeletion'), // $t 您确认删除该贴吗？
        this.$t('fornum.confirmDel'), // $t 确认删除
        {
          confirmButtonText: this.$t('fornum.confirm'), // $t 确定
          cancelButtonText: this.$t('fornum.cancel'), // $t 取消
          type: 'warning'
        }
      )
        .then(() => {
          onDelete({ id }).then(() => {
            this.$message.success(this.$t('fornum.haveDeleted')) // $t 已删除
            this.pageNum = 1
            this.myTopicsList = []
            // 刷新我的发表
            this._onMyTopics()
          })
        })
        .catch(() => {
          this.$message.info(this.$t('fornum.Deletecancel')) // $t 已取消删除
        })
    },
    /**
     * @Description: 点击发帖/编辑触发
     * @Author: 肖巧伦
     */
    postPush(id) {
      this.$router.push({
        path: '/post-message',
        query: {
          id: id
        }
      })
    },
    /**
     * @Description: 调用触发
     * @Author: 肖巧伦
     * @Desc: 过滤帖子状态
     */
    states(its) {
      if (its === '1') {
        return {
          type: 'info',
          topicStatus: this.$t('fornum.audit') // $t 审核中
        }
      } else if (its === '2') {
        return {
          type: 'success',
          topicStatus: this.$t('fornum.issue') // $t 已发布
        }
      } else if (its === '3') {
        return {
          type: 'danger',
          topicStatus: this.$t('fornum.rejectyin') // $t 被驳回
        }
      }
    },
    /**
     * @Description: 点击列表触发
     * @Author: 肖巧伦
     * @Desc: 跳转帖子详情
     */
    clickList(id) {
      this.$router.push({
        path: '/post-details',
        query: { postId: id }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
// 滚动组件
.machinery-information__list-wrapper {
  width: 800px;
  height: 85%;
  position: fixed;
  overflow: auto;
  background-color: $white;
  .machinery-information__loading {
    height: 44px;
    text-align: center;
    line-height: 44px;
    color: $date-icon-color;
    font-size: $base-font-size;
  }
}
.post-reply__first {
  margin-top: 20px;
  min-height: 40px;
  padding: 4px 24px 27px;
  box-sizing: border-box;
  border-bottom: 1px solid #e4e7ed;
  .post-reply__first-text {
    float: left;
    width: 650px;
    overflow: hidden; //溢出隐藏
    text-overflow: ellipsis; //超出部分裁剪
    white-space: nowrap; //不换行
    font-family: MicrosoftYaHei;
    font-size: 16px;
    font-weight: bold;
    color: #212121;
  }
  // 回复帖子的标题
  .post-reply__first-title {
    max-width: 650px;
    overflow: hidden; //溢出隐藏
    text-overflow: ellipsis; //超出部分裁剪
    white-space: nowrap; //不换行
    padding: 0 8px;
    font-size: 12px;
    float: left;
    height: 24px;
    line-height: 24px;
    color: #8b8b8b;
    background-color: #f5f5f5;
  }
  .post-reply__first-tag {
    float: right;
    width: 52px;
    height: 20px;
    line-height: 20px;
    text-align: center;
  }
  // 回复内容
  .post-reply__first-center {
    margin-top: 35px;
    min-height: 20px;
    font-size: 14px;
    color: #212121;
    overflow: hidden;
    // 帖子内的图片 等比例缩放
    /deep/img {
      width: auto !important;
      height: auto !important;
      max-width: 100% !important;
    }
  }
  .post-reply__first-botton {
    margin-top: 16px;
    color: #8b8b8b;
    font-size: 14px;
    .post-reply__first-left {
      float: left;
    }
    // 删除和编辑图标
    .post-reply__first-right {
      position: absolute;
      right: 15px;
      width: 60px;
      .post-reply__first-shanchu {
        float: right;
      }
    }
  }
}
</style>
