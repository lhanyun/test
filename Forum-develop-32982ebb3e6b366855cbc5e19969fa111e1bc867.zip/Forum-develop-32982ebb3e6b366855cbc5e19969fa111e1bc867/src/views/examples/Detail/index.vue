<template>
  <div class="detail">
    <div>这是详情页</div>
  </div>
</template>

<script>
export default {
  name: 'SimpleLayout'
}
</script>

<style lang="scss" scoped>
.detail {
  height: 800px;
  width: 100%;
}
</style>
