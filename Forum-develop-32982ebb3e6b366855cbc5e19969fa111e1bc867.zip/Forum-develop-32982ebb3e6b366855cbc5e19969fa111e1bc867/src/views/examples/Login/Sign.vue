<template>
  <div class="login-short-message">
    <div class="login-short-message__input">
      <!-- $t 手机号 请输入您的手机号码 -->
      <zv-input
        :label="$t('login.phoneNum')"
        isInt
        :placeholder="$t('login.placeholderPhoneNum')"
        v-model="phoneNum"
      />
    </div>
    <div class="login-short-message__input">
      <!-- $t 验证码 请输入手机验证码 -->
      <zv-input
        :label="$t('login.authCode')"
        :placeholder="$t('login.placeholderAuthCode')"
        v-model="authCode"
      >
        <zv-button type="primary" :disabled="!sendMsgAble" @click="sendmsg">
          {{ sendMsgTxt }}
        </zv-button>
      </zv-input>
    </div>

    <div class="login-short-message__input">
      <!-- $t 新密码 包含小/大写字母,数字,特殊字符 -->
      <zv-input
        :label="$t('login.newPassword')"
        :placeholder="$t('login.placeholderNewPassword')"
        :type="showPassword1 ? 'text' : 'password'"
        :icon="showPassword1 ? 'eye-open' : 'eye'"
        @clickIcon="showPassword1 = !showPassword1"
        v-model="password"
      />
    </div>
    <div class="login-short-message__input">
      <!-- $t 确认密码 请再次输入密码 -->
      <zv-input
        :label="$t('login.makeSurePassword')"
        :placeholder="$t('login.placeholderMakeSurePassword')"
        :type="showPassword2 ? 'text' : 'password'"
        :icon="showPassword2 ? 'eye-open' : 'eye'"
        @clickIcon="showPassword2 = !showPassword2"
        v-model="newPassWord"
      />
    </div>
    <div class="login-short-message__input agreement-state">
      <zv-svg-icon
        :class-name="icon === 'check-circle-fill' ? 'green' : ''"
        :icon-class="icon"
        @click.native="hadAgree = !hadAgree"
      />
      <div class="ml6">
        同意
        <span @click="showUserAgreementDialog = true">
          ”软件许可及服务协议“
        </span>
      </div>
    </div>
    <div class="login-short-message__backBtn">
      <!-- $t 注册 -->
      <zv-button size="large" type="primary" @click="sign">
        {{ $t('login.sign') }}
      </zv-button>
      <!-- $t 返回登录 -->
      <zv-button
        class="mt16"
        size="large"
        type="primary"
        plain
        @click="goBackLogin"
      >
        {{ $t('login.goBackLoinIn') }}
      </zv-button>
    </div>
    <user-agreement v-model="showUserAgreementDialog" />
  </div>
</template>

<script>
import * as api from '@/api/login'
import { handleRSA } from './login_utils'
import UserAgreement from './UserAgreement/index'
export default {
  name: 'Sign',
  components: {
    UserAgreement
  },
  data() {
    return {
      phoneNum: '', // 手机号
      authCode: '', // 验证码
      sendMsgAble: true, // 是否可以发送验证码
      certifiCate: '', // 验证码校验结果
      password: '',
      newPassWord: '',
      hadAgree: false, // 已经同意了协议
      showPassword1: false, // 显示密码
      showPassword2: false, // 显示重复密码
      showUserAgreementDialog: false, // 用户协议
      i: 60
    }
  },
  computed: {
    icon() {
      return this.hadAgree ? 'check-circle-fill' : 'check-circle'
    },
    sendMsgTxt() {
      // 倒计时
      return this.i === 60 ? '发送验证码' : `发送中(${this.i}s)`
    }
  },
  methods: {
    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 注册
     */
    async sign() {
      if (!this.verificationPhone(this.phoneNum)) {
        // $t 手机号码不符合规则，请重新输入
        this.$message.error(this.$t('login.error2'))
        return
      } else if (!this.authCode.length) {
        // $t 验证码不能为空
        this.$message.error(this.$t('login.error3'))
        return
      } else if (!this.hadAgree) {
        // $t 注册请先同意用户协议
        this.$message.error(this.$t('login.error6'))
        return
      }
      // 密码强度校验
      if (this.strongPassword()) {
        if (
          !this.password ||
          !this.newPassWord ||
          this.password !== this.newPassWord
        ) {
          // $t 密码不能为空或者两次输入密码不一致
          this.$message.error(this.$t('login.error4'))
          return
        }
      } else {
        // $t 输入的密码不符合规则
        this.$message.error(this.$t('login.error5'))
      }
      try {
        // 注册
        const data = await api.verificationCodeCheck({
          code: this.authCode,
          phone: this.phoneNum,
          msgType: '00'
        })
        this.certifiCate = data.certifiCate
        this.register()
      } catch (e) {
        throw e
      }
    },
    /**
     * @author: 刘宇琳
     * @date: 2019-04-23
     * @description: 从忘记密码页面返回用户登录页面
     */
    goBackLogin() {
      this.$emit('onBackLogin')
    },
    /**
     * @author: 肖景
     * @date: 2019-07-16
     * @description: 跳转到对应的注册页面
     */
    doSign() {
      this.$emit('to-sign')
    },

    /** 2019-09-09
     * @Author: 肖景
     * @Desc: 注册
     */
    async register() {
      try {
        const password = await handleRSA(this.password)
        await api.register({
          phone: this.phoneNum,
          certificate: this.certifiCate,
          password
        })
        this.$message.success('注册成功，请登录')
        this.doSign()
      } catch (error) {
        throw error
      }
    },
    /**
     * @author: 刘宇琳
     * @date: 2019-04-23
     * @description: 发送短信验证码
     */
    sendmsg() {
      if (!this.verificationPhone(this.phoneNum)) {
        // $t 手机号码不符合规则，请重新输入
        this.$message.error(this.$t('login.error2'))
        return
      }

      if (!this.sendMsgAble) {
        return
      }

      this.sendMsgAble = false

      if (this.i < 60) {
        return
      }

      const smsType = '00'
      // 发送短信
      api
        .getMsgCode({ phone: this.phoneNum, smsType })
        .then(data => {
          if (data.code === '0') {
            this.setTimer()
          } else {
            this.clearTimer()
          }
        })
        .catch(() => {
          this.clearTimer()
        })
    },
    verificationPhone(phone) {
      // 判断手机号格式是否正确
      return phone && phone.length === 11
    },
    setTimer() {
      // 设置定时
      this.i--
      this.timer = setInterval(() => {
        this.i--
        if (this.i <= 0) {
          this.clearTimer()
        }
      }, 1000)
    },
    clearTimer() {
      // 清除定时
      if (this.timer) {
        clearInterval(this.timer)
      }
      this.i = 60
      this.sendMsgAble = true
    },
    strongPassword() {
      const value = this.password
      let lv = 0
      if (value.length >= 8 && value.length <= 20) {
        if (value.match(/[a-z]/g)) {
          lv++
        } // 含有小写字母
        if (value.match(/[A-Z]/g)) {
          lv++
        } // 含有大写字母
        if (value.match(/[0-9]/g)) {
          lv++
        } // 含有数字
        if (
          // eslint-disable-next-line
            value.match(/[\-\_\,\!\|\~\`\(\)\#\$\%\^\&\*\{\}\:\;\"\L\<\>\?]/g)
        ) {
          lv++
        } // 含有特殊字符
        // 满足其中两项时,查询密码强度
        return lv >= 2
      } else {
        return false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.login-short-message {
  &__input {
    margin-top: 16px;
  }
  &__nextBtn {
    margin-top: 40px;
  }
  &__backBtn {
    margin-top: 60px;
  }
  .agreement-state {
    @include containerH44();
    @include flex($justifyContent: flex-start);
    font-size: $base-font-size;
    color: $sub-font-color;
    span {
      color: $base-font-color;
      cursor: pointer;
    }
    .green {
      color: $base-color;
    }
  }
}
</style>
