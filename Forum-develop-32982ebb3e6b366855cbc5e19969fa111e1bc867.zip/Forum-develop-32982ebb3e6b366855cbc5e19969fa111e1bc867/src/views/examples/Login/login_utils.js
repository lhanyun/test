import store from '@/store'
import JsEncrypt from 'jsencrypt/bin/jsencrypt'
import { getCertificateInfo } from '@/api/login'
function handleRSA(value) {
  // 获取服务端传来的公钥
  return new Promise((resolve, reject) => {
    getCertificateInfo()
      .then(data => {
        if (data.publicKey) {
          var encrypt = new JsEncrypt()

          // 设置公钥
          encrypt.setPublicKey(data.publicKey)
          resolve(encrypt.encrypt(value))
        }
      })
      .catch(error => {
        reject(error)
      })
  })
}

// 获取用户信息
function onUserInfo() {
  return store.dispatch('GetUserInfo')
}

function onUserMenus() {
  return store.dispatch('GetUserMenus')
}

export { handleRSA, onUserInfo, onUserMenus }
