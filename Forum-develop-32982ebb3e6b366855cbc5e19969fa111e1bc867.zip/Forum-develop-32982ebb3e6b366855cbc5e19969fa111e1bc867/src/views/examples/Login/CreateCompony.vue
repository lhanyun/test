<template>
  <div class="create-compony">
    <zv-form :model="formData" ref="validateForm" class="create-compony__input">
      <zv-form-item
        prop="name"
        :rules="[returnValidateNotEmpty($t('login.componyName'))]"
      >
        <!-- $t 创建公司-->
        <zv-input
          :label="$t('login.componyName')"
          v-model="formData.name"
          :placeholder="$t('login.placeholderComponyName')"
          labelTop
          required
          showBorder
        />
      </zv-form-item>
    </zv-form>

    <div class="create-compony__btn">
      <!-- $t 确定 -->
      <zv-button size="large" type="primary" @click="submitData">
        {{ $t('login.makeSure') }}
      </zv-button>
    </div>
  </div>
</template>

<script>
import { createTenant } from '@/api/login'

export default {
  name: 'CreateCompony',
  data() {
    return {
      formData: {
        name: ''
      }
    }
  },
  methods: {
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 验证为空的返回消息
     */
    returnValidateNotEmpty(msg) {
      return {
        required: true,
        // $t 不能为空
        message: `${msg}${this.$t('login.notEmpty')}`,
        trigger: ['blur']
      }
    },
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 创建公司验证通过
     */
    submitData() {
      this.$refs['validateForm'].$children[0].validate(valid => {
        if (valid) {
          this.createTenant()
        } else {
          return false
        }
      })
    },
    async createTenant() {
      try {
        const { tenantId } = await createTenant(this.formData)
        this.$store.commit('UPDATE_USERINFO', { tenantId })
        this.submit()
      } catch (error) {
        throw error
      }
    },
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 传输到后台的数据接口
     */
    async submit() {
      this.$emit('on-home')
    }
  }
}
</script>

<style scoped lang="scss">
.create-compony {
  &__input {
    margin-top: 16px;
  }
  &__forget {
    @include containerH44();
    @include flex($justifyContent: flex-end);
  }
  &__btn {
    margin-top: 60px;
  }
}
</style>
<style lang="scss">
.create-compony {
  .el-dialog__body__default {
    height: 312px;
    .el-scrollbar__wrap {
      overflow-x: hidden;
    }
  }
}
</style>
