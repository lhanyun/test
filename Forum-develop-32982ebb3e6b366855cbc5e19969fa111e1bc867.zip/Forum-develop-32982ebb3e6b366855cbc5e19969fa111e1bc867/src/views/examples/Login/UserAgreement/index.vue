<template>
  <!-- $t 土方物联网平台软件许可及服务协议 -->
  <zv-dialog
    v-model="currentValue"
    width="736px"
    :title="title"
    :btnList="['cancel']"
    @closed="cancel"
    @submit="submit"
    class="agreement-dialog"
  >
    <el-scrollbar style="height:100%">
      <div class="agreement">
        <h3>中联e管家 软件许可及服务协议</h3>
        <div v-for="(item, index) in AgreementText.context" :key="index">
          <p v-if="item.strong">
            <strong>{{ item.text }}</strong>
          </p>
          <p v-else>{{ item.text }}</p>
        </div>
        <p class="text-right">中联重科股份有限公司</p>
      </div>
    </el-scrollbar>
  </zv-dialog>
</template>

<script>
import ZvModel from 'mixins/zv-model'
import { AgreementText } from './config.js'
export default {
  name: 'UserAgreement',
  mixins: [ZvModel],
  data() {
    return {
      title: '中联e管家软件许可及服务协议',
      AgreementText: Object.freeze(AgreementText)
    }
  },
  methods: {
    cancel() {
      this.value = false
      this.$emit('cancel')
    },
    submit() {
      this.value = false
      this.$emit('submit')
    }
  }
}
</script>

<style lang="scss" scoped>
.agreement-dialog {
  .agreement {
    padding: 0 16px;
    .text-right {
      text-align: right;
    }
  }
}
</style>

<style lang="scss">
.agreement-dialog {
  .el-dialog__body__default {
    height: 312px;
    .el-scrollbar__wrap {
      overflow-x: hidden;
    }
  }
}
</style>
