<template>
  <div class="login-account-password">
    <div class="login-account-password__input">
      <!-- $t 用户名称 请输入您的账号 -->
      <zv-input
        :label="$t('login.username')"
        :placeholder="$t('login.placeholderUsername')"
        v-model="username"
      />
    </div>

    <div class="login-account-password__input">
      <!-- $t 登录密码 请输入您的登录密码 -->
      <zv-input
        :label="$t('login.passwordLabel')"
        :placeholder="$t('login.placeholderPassword')"
        v-model="password"
        :type="showPassword ? 'text' : 'password'"
        :icon="showPassword ? 'eye-open' : 'eye'"
        @clickIcon="showPassword = !showPassword"
      />
    </div>

    <div class="login-account-password__forget">
      <!-- $t 忘记密码 -->
      <zv-button type="text" @click.native="forgetPassword">
        {{ $t('login.forgetPassword') }}
      </zv-button>
    </div>

    <div class="login-account-password__btn">
      <!-- $t 登录 -->
      <zv-button size="large" type="primary" @click="doLogin">
        {{ $t('login.logIn') }}
      </zv-button>
      <!-- $t 注册 -->
      <zv-button size="large" @click="doSign" class="mt16">
        {{ $t('login.sign') }}
      </zv-button>
    </div>
  </div>
</template>

<script>
import { handleRSA } from './login_utils'
export default {
  name: 'UserLogin',
  data() {
    return {
      username: '18570666862',
      password: 'zlzk@.1570',
      showPassword: false
    }
  },
  methods: {
    async doLogin() {
      if (!this.username.length || !this.password.length) {
        // $t 账号或者密码不能为空
        this.$message.error(this.$t('login.error1'))
        return
      }
      const password = await handleRSA(this.password)
      const request = {
        username: this.username,
        password
      }
      try {
        await this.$store.dispatch('Login', request)
        this.$emit('on-home')
      } catch (error) {
        throw error
      }
    },
    /**
     * @author: 肖景
     * @date: 2019-07-16
     * @description: 跳转到对应的注册页面
     */
    doSign() {
      this.$emit('to-sign')
    },
    forgetPassword() {
      this.$emit('handleForget')
    }
  }
}
</script>

<style scoped lang="scss">
.login-account-password {
  &__input {
    margin-top: 16px;
  }
  &__forget {
    @include containerH44();
    @include flex($justifyContent: flex-end);
  }
  &__btn {
    margin-top: 60px;
  }
}
</style>
<style lang="scss">
.login-account-password {
  .el-dialog__body__default {
    height: 312px;
    .el-scrollbar__wrap {
      overflow-x: hidden;
    }
  }
}
</style>
