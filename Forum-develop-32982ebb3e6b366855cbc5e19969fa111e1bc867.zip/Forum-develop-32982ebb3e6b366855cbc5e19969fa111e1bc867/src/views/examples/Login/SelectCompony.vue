<template>
  <div class="select-compony">
    <zv-form :model="formData" ref="validateForm" class="select-compony__input">
      <zv-form-item
        prop="componyName"
        :rules="[returnValidateNotEmpty($t('login.componyName'))]"
      >
        <!-- $t 公司列表 -->
        <zv-select
          :title="$t('login.componyName')"
          v-model="formData.componyName"
          :placeholder="$t('login.placeholderComponyName')"
          required
          :options="componyList"
        />
      </zv-form-item>
    </zv-form>

    <div class="select-compony__btn">
      <!-- $t 确定 -->
      <zv-button size="large" type="primary" @click="submitData">
        {{ $t('login.makeSure') }}
      </zv-button>
    </div>
  </div>
</template>

<script>
import { queryUserTenant, changeDefaultTenant } from '@/api/login'

export default {
  name: 'SelectCompony',
  data() {
    return {
      formData: {
        componyName: ''
      },
      componyList: []
    }
  },
  created() {
    this.queryUserTenant()
  },
  methods: {
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 验证为空的返回消息
     */
    returnValidateNotEmpty(msg) {
      return {
        required: true,
        // $t 不能为空
        message: `${msg}${this.$t('login.notEmpty')}`,
        trigger: ['blur']
      }
    },
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 创建公司验证通过
     */
    submitData() {
      this.$refs['validateForm'].$children[0].validate(valid => {
        if (valid) {
          this.submit()
        } else {
          return false
        }
      })
    },
    /**
     * @author 肖景
     * @date 2019/07/17
     * @description 传输到后台的数据接口
     */
    async submit() {
      try {
        await changeDefaultTenant({ tenantId: this.formData.componyName })
        this.$store.commit('UPDATE_USERINFO', {
          tenantId: this.formData.componyName
        })
        this.$message.success('选择公司成功，请重新登录')
        this.$emit('on-home')
      } catch (error) {
        throw error
      }
    },
    /**
     * @author 肖景
     * @date 2019/09/11
     * @description 获取用户的公司列表
     */
    async queryUserTenant() {
      try {
        const { tenantDtoList = [] } = await queryUserTenant()
        tenantDtoList.forEach(ele => {
          ele.value = ele.id
          ele.label = ele.name
          ele.disabled = ele.isLocked === 'Y'
          if (ele.isDefault === 'Y') {
            this.formData = {
              componyName: ele.id
            }
          }
        })
        this.componyList = tenantDtoList
      } catch (error) {
        throw error
      }
    }
  }
}
</script>

<style scoped lang="scss">
.select-compony {
  &__input {
    margin-top: 16px;
  }
  &__forget {
    @include containerH44();
    @include flex($justifyContent: flex-end);
  }
  &__btn {
    margin-top: 60px;
  }
}
</style>
<style lang="scss">
.select-compony {
  .el-dialog__body__default {
    height: 312px;
    .el-scrollbar__wrap {
      overflow-x: hidden;
    }
  }
  .el-select,
  .zv-select-default .el-input__inner {
    width: 100%;
  }
}
</style>
