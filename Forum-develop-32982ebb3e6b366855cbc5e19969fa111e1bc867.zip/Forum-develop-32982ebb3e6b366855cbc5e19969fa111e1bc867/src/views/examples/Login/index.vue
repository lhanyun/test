<template>
  <div
    class="login"
    :style="{
      backgroundImage: 'url(' + require('@/assets/img/login/login-bg.jpg') + ')'
    }"
  >
    <login-layout justify-content="flex-end">
      <el-scrollbar class="login-scroll">
        <div class="login__wrapper">
          <template v-if="actionType === 'login'">
            <div class="login__title">
              <!-- $t 用户登录 找回密码 -->
              {{
                hiddenForgetView
                  ? $t('login.userLoin')
                  : $t('login.findPassword')
              }}
            </div>

            <zv-tabs
              v-if="hiddenForgetView"
              :tab-pane="tabPane"
              v-model="activeName"
              @tab-click="handleClick"
            >
              <!-- $t 用户登录 -->
              <div slot="first">
                <account-password
                  @on-home="onPushHomeView"
                  @to-sign="toSign"
                  @handleForget="hiddenForgetView = !hiddenForgetView"
                />
              </div>
              <!-- $t 短信登录 -->
              <div slot="second">
                <short-message
                  @on-home="onPushHomeView"
                  @to-sign="toSign"
                  :hiddenForgetView="hiddenForgetView"
                />
              </div>
            </zv-tabs>

            <short-message
              :hiddenForgetView="hiddenForgetView"
              v-else
              @onBackLogin="hiddenForgetView = true"
              @handleForget="hiddenForgetView = !hiddenForgetView"
              @on-home="onPushHomeView"
            />
          </template>
          <template v-else-if="actionType === 'sign'">
            <div class="login__title">
              用户注册
            </div>
            <sign @onBackLogin="backLogin" />
          </template>
          <template v-else-if="actionType === 'createCompony'">
            <div class="login__title">
              创建公司
            </div>
            <create-compony @on-home="setUrl" />
          </template>
          <template v-else-if="actionType === 'selectCompony'">
            <div class="login__title">
              选择公司
            </div>
            <select-compony @on-home="actionType = 'login'" />
          </template>
        </div>
      </el-scrollbar>
    </login-layout>
  </div>
</template>

<script>
import LoginLayout from 'layouts/LoginLayout/index'
import AccountPassword from './AccountPassword'
import ShortMessage from './ShortMessage'
import Sign from './Sign'
import CreateCompony from './CreateCompony'
import SelectCompony from './SelectCompony'
// import { getRedirectUrl, removeRedirectUrl, setAppType } from '@/utils/auth' // getToken from cookie
// import { getProductInfo } from '@/api/login'

export default {
  name: 'Login',
  components: {
    ShortMessage,
    AccountPassword,
    LoginLayout,
    Sign,
    CreateCompony,
    SelectCompony
  },
  data() {
    return {
      activeName: 'first',
      hiddenForgetView: true,
      actionType: 'login',
      tabPane: [
        {
          label: this.$t('login.userLoin'),
          name: 'first'
        },
        {
          label: this.$t('login.smsLogin'),
          name: 'second'
        }
      ]
    }
  },
  beforeCreate() {
    if (process.env.VUE_APP_HAVE_LOGIN === '1') {
      this.$configParams.redirectHome()
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    },
    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 登录的接口
     */
    async onPushHomeView() {
      const userInfo = this.$store.getters.userInfo
      if (userInfo.tenantId) {
        this.setUrl()
      } else {
        if (userInfo.effectiveTenantNum === 0) {
          this.actionType = 'createCompony'
        } else {
          this.actionType = 'selectCompony'
        }
      }
    },
    toSign() {
      this.actionType = 'sign'
    },
    backLogin() {
      this.actionType = 'login'
    },
    // 跳转相关逻辑
    async setUrl() {
      // 收否本地有重定向的地址
      // if (getRedirectUrl()) {
      //   const url = getRedirectUrl()
      //   removeRedirectUrl()
      //   window.location.href = url
      // } else {
      //   const userInfo = this.$store.getters.userInfo
      //   // 是否有默认的产品跳转
      //   if (userInfo.appType) {
      //     try {
      // if (Number(userInfo.appType) === 0) {
      //   this.$router.push('/')
      //   return
      // }
      //       const {
      //         productDto: { url }
      //       } = await getProductInfo({
      //         appType: userInfo.appType
      //       })
      //       if (url) {
      //         setAppType(userInfo.appType)
      //         window.location.href = url + '?appType=' + userInfo.appType
      //       } else {
      //         this.$router.push('/')
      //       }
      //     } catch (error) {
      //       throw error
      //     }
      //   } else {
      this.$router.push('/')
      //   }
      // }
    }
  }
}
</script>

<style lang="scss" scoped>
.login {
  background-size: calc(100vw - 440px);
  background-repeat: no-repeat;
  position: relative;
  .login-scroll {
    height: calc(100vw - 44px);
    width: 440px;
  }
  .login__wrapper {
    box-sizing: border-box;
    padding: 0 40px;
    width: 440px;
    height: 100%;
    background-color: #fff;
    .login__title {
      color: $base-font-color;
      font-size: 28px;
      margin: 80px 0 56px 0;
    }
  }
}
</style>
