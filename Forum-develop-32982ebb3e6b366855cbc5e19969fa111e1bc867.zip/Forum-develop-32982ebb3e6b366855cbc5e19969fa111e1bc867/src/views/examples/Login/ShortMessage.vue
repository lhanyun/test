<template>
  <div class="login-short-message">
    <!--短信登录or忘记密码-->
    <template v-if="!setPassword">
      <div class="login-short-message__input">
        <!-- $t 手机号 请输入您的手机号码 -->
        <zv-input
          :label="$t('login.phoneNum')"
          isInt
          :placeholder="$t('login.placeholderPhoneNum')"
          v-model="phoneNum"
        />
      </div>
      <div class="login-short-message__input">
        <!-- $t 验证码 请输入手机验证码 -->
        <zv-input
          :label="$t('login.authCode')"
          :placeholder="$t('login.placeholderAuthCode')"
          v-model="authCode"
        >
          <zv-button type="primary" :disabled="!sendMsgAble" @click="sendmsg">
            {{ sendMsgTxt }}
          </zv-button>
        </zv-input>
      </div>

      <div class="login-short-message__nextBtn">
        <!-- $t 登录 下一步 -->
        <zv-button size="large" type="primary" @click="doLogin">
          {{ hiddenForgetView ? $t('login.logIn') : $t('login.next') }}
        </zv-button>
        <!-- $t 注册 -->
        <zv-button
          size="large"
          @click="doSign"
          v-if="hiddenForgetView"
          class="mt16"
        >
          {{ $t('login.sign') }}
        </zv-button>
      </div>
    </template>

    <!--设置新密码-->
    <template v-else>
      <div class="login-short-message__input">
        <!-- $t 新密码 包含小/大写字母,数字,特殊字符 -->
        <zv-input
          :label="$t('login.newPassword')"
          :placeholder="$t('login.placeholderNewPassword')"
          v-model="password"
          :type="showPassword1 ? 'text' : 'password'"
          :icon="showPassword1 ? 'eye-open' : 'eye'"
          @clickIcon="showPassword1 = !showPassword1"
        />
      </div>
      <div class="login-short-message__input">
        <!-- $t 确认密码 请再次输入密码 -->
        <zv-input
          :label="$t('login.makeSurePassword')"
          :placeholder="$t('login.placeholderMakeSurePassword')"
          v-model="newPassWord"
          :type="showPassword2 ? 'text' : 'password'"
          :icon="showPassword2 ? 'eye-open' : 'eye'"
          @clickIcon="showPassword2 = !showPassword2"
        />
      </div>

      <div class="login-short-message__nextBtn">
        <!-- $t 确 认 -->
        <zv-button size="large" type="primary" @click="onPassword">
          {{ $t('login.submit') }}
        </zv-button>
      </div>
    </template>

    <div class="login-short-message__backBtn">
      <!-- $t 返回登录 -->
      <zv-button
        v-if="!hiddenForgetView"
        size="large"
        type="primary"
        plain
        @click="goBackLogin"
      >
        {{ $t('login.goBackLoinIn') }}
      </zv-button>
    </div>
  </div>
</template>

<script>
import * as api from '@/api/login'
import { handleRSA } from './login_utils'
export default {
  name: 'ShortMessage',
  props: {
    /** 2019-07-10
     * @Author: 肖景
     * @Desc: hiddenForgetView:true 短信登入， hiddenForgetView:false 找回密码
     */
    hiddenForgetView: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      phoneNum: '', // 手机号
      authCode: '', // 验证码
      sendMsgAble: true, // 是否可以发送验证码
      setPassword: false, // 是否跳转到设置新密码页面
      certifiCate: '', // 验证码校验结果
      password: '',
      newPassWord: '',
      showPassword1: false,
      showPassword2: false,
      i: 60
    }
  },
  computed: {
    sendMsgTxt() {
      // 倒计时
      return this.i === 60 ? '发送验证码' : `发送中(${this.i}s)`
    }
  },
  methods: {
    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 登录或者忘记密码操作   添加相关的证书认证逻辑
     */
    async doLogin() {
      if (!this.verificationPhone(this.phoneNum)) {
        // $t 手机号码不符合规则，请重新输入
        this.$message.error(this.$t('login.error2'))
        return
      } else if (!this.authCode.length) {
        // $t 验证码不能为空
        this.$message.error(this.$t('login.error3'))
        return
      }
      try {
        // 短信登录
        if (this.hiddenForgetView) {
          try {
            await this.$store.dispatch('SMSLogin', {
              code: this.authCode,
              phone: this.phoneNum
            })
            this.$emit('on-home')
          } catch (error) {
            throw error
          }
        } else {
          // 忘记密码
          const data = await api.verificationCodeCheck({
            code: this.authCode,
            phone: this.phoneNum,
            msgType: '02'
          })
          this.certifiCate = data.certifiCate
          this.setPassword = true
        }
      } catch (e) {
        throw e
      }
    },
    /**
     * @author: 刘宇琳
     * @date: 2019-04-23
     * @description: 从忘记密码页面返回用户登录页面
     */
    goBackLogin() {
      this.$emit('onBackLogin')
    },
    /**
     * @author: 肖景
     * @date: 2019-07-16
     * @description: 跳转到对应的注册页面
     */
    doSign() {
      this.$emit('to-sign')
    },

    /** 2019-03-25
     * @Author: 刘宇琳
     * @Desc: 设置新密码
     */
    async onPassword() {
      if (this.strongPassword()) {
        if (this.password.length === this.password.length) {
          try {
            const password = await handleRSA(this.newPassWord)
            await api.forgetPassword({
              phone: this.phoneNum,
              newPassWord: password,
              certifiCate: this.certifiCate
            })
            // $t 修改成功
            this.$message.success(this.$t('login.reviseSuccess'))
            this.$emit('handleForget')
          } catch (e) {
            throw e
          }
        } else {
          // $t 密码不能为空或者两次输入密码不一致
          this.$message.error(this.$t('login.error4'))
        }
      } else {
        // $t 输入的密码不符合规则
        this.$message.error(this.$t('login.error5'))
      }
    },
    /**
     * @author: 刘宇琳
     * @date: 2019-04-23
     * @description: 发送短信验证码
     */
    sendmsg() {
      if (!this.verificationPhone(this.phoneNum)) {
        // $t 手机号码不符合规则，请重新输入
        this.$message.error(this.$t('login.error2'))
        return
      }

      if (!this.sendMsgAble) {
        return
      }

      this.sendMsgAble = false

      if (this.i < 60) {
        return
      }

      const smsType = this.hiddenForgetView ? '01' : '02'
      // 发送短信
      api
        .getMsgCode({ phone: this.phoneNum, smsType })
        .then(data => {
          if (data.code === '0') {
            this.setTimer()
          } else {
            this.clearTimer()
          }
        })
        .catch(() => {
          this.clearTimer()
        })
    },
    verificationPhone(phone) {
      // 判断手机号格式是否正确
      return phone && phone.length === 11
    },
    setTimer() {
      // 设置定时
      this.i--
      this.timer = setInterval(() => {
        this.i--
        if (this.i <= 0) {
          this.clearTimer()
        }
      }, 1000)
    },
    clearTimer() {
      // 清除定时
      if (this.timer) {
        clearInterval(this.timer)
      }
      this.i = 60
      this.sendMsgAble = true
    },
    strongPassword() {
      const value = this.password
      let lv = 0
      if (value.length >= 8 && value.length <= 20) {
        if (value.match(/[a-z]/g)) {
          lv++
        } // 含有小写字母
        if (value.match(/[A-Z]/g)) {
          lv++
        } // 含有大写字母
        if (value.match(/[0-9]/g)) {
          lv++
        } // 含有数字
        if (
          // eslint-disable-next-line
            value.match(/[\-\_\,\!\|\~\`\(\)\#\$\%\^\&\*\{\}\:\;\"\L\<\>\?]/g)
        ) {
          lv++
        } // 含有特殊字符
        // 满足其中两项时,查询密码强度
        return lv >= 2
      } else {
        return false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.login-short-message {
  &__input {
    margin-top: 16px;
  }
  &__nextBtn {
    margin-top: 40px;
  }
  &__backBtn {
    margin-top: 60px;
  }
}
</style>
