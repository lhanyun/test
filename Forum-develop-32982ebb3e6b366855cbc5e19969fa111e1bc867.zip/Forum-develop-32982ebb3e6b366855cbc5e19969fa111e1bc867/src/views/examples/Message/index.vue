<!-- 
/**
 * author: 肖景
 * description: 消息列表
 * time: 2019-10-24
 */
-->

<template>
  <div>
    <zv-title
      :title="$t('message.messageCenter')"
      sub-title=" "
      class="zv-message__title"
    >
      <zv-button type="primary" icon="shezhi-o" @click="settingVisible = true">
        {{ $t('message.messageSetting') }}
      </zv-button>
    </zv-title>
    <zv-tabs
      v-model="search.messageStatus"
      :tab-pane="tabPane"
      class="zv-message"
      @tab-click="tabClick"
    >
      <div class="zv-message__container" slot="0">
        <div class="zv-message__select">
          <!-- $t 请选择消息类型 -->
          <zv-select
            v-model="search.messageType"
            :options="options"
            :placeholder="$t('message.messageTypePlaceholder')"
            clearable
            @change="getList"
            row
          />
        </div>
        <zv-table
          ref="myTable"
          :tableData="tableData"
          :params="tableParam0"
          @select="handleSelect"
          class="zv-message__table"
        />
        <zv-table-footer
          class="zv-message__footer"
          :total="total"
          :current-selected-number="multipleSelection.length"
          :page-size.sync="pageSize"
          :current-page.sync="pageNum"
          @size-change="getList"
          @current-change="getList"
        >
          <zv-button
            :disabled="!multipleSelection.length"
            @click="dialogVisible = true"
          >
            <!-- $t 标记已读 -->
            {{ $t('message.toHadRead') }}
          </zv-button>
        </zv-table-footer>
        <zv-dialog
          v-model="dialogVisible"
          width="320px"
          bodyHeight="152px"
          @submit="changeStateToReaded"
          :title="$t('message.notice')"
        >
          <!-- $t 是否确认标记为已读 -->
          {{ $t('message.reNotice') }}
        </zv-dialog>
      </div>

      <div class="zv-message__container" slot="1">
        <div class="zv-message__select">
          <!-- $t 请选择消息类型 -->
          <zv-select
            v-model="search.messageType"
            :options="options"
            :placeholder="$t('message.messageTypePlaceholder')"
            clearable
            @change="getList"
            row
          />
        </div>
        <zv-table
          ref="myTable"
          :tableData="tableData"
          :params="tableParam1"
          @select="handleSelect"
          class="zv-message__table"
        />
        <zv-table-footer
          class="zv-message__footer"
          :total="total"
          :have-check-box="false"
          :page-size.sync="pageSize"
          :current-page.sync="pageNum"
          @size-change="getList"
          @current-change="getList"
        />
      </div>
    </zv-tabs>
    <zv-message-detail v-model="detailVisible" :message-id="messageId" />
    <zv-message-setting v-model="settingVisible" />
  </div>
</template>

<script>
import ZvMessageDetail from './Detail'
import ZvMessageSetting from './Setting'
export default {
  name: 'Message',
  components: {
    ZvMessageDetail,
    ZvMessageSetting
  },
  data() {
    const self = this
    // 表格参数公共项
    const columns = [
      {
        prop: 'title',
        // $t 标题
        label: this.$t('message.title'),
        render: {
          default: ({ row }) => (
            <div
              class="zv-message__table-title"
              onClick={() => self.watchDetails(row)}
            >
              {row.title}
            </div>
          )
        }
      },
      {
        prop: 'sendTime',
        // $t 发送时间
        label: this.$t('message.sendTime'),
        width: `200px`
      },
      {
        prop: 'messageType',
        // $t 消息类型
        label: this.$t('message.messageType'),
        width: `200px`,
        render: {
          default: ({ row }) => self.options[row.messageType]
        }
      },
      {
        prop: 'operate',
        // $t 操作类型
        label: this.$t('message.operateName'),
        width: `160px`,
        align: 'center',
        render: {
          default: ({ row }) => (
            <zv-table-operate
              trigger="click"
              params={self.operateOptions}
              onCommand={() => self.watchDetails(row)}
            />
          )
        }
      }
    ]
    return {
      dialogVisible: false,
      detailVisible: false,
      settingVisible: false,
      messageId: '',
      tabPane: [
        {
          // $t 未读消息
          label: this.$t('message.unreadMessage'),
          name: '0'
        },
        {
          // $t 已读消息
          label: this.$t('message.readedMessage'),
          name: '1'
        }
      ],
      options: this.$getDataDic('messageType'),
      tableData: [],
      // 加两个tableParam的用处是 防止样式出现问题
      tableParam0: {
        isCheckAll: false,
        haveCheckBox: true,
        maxHeight: document.body.clientHeight - 296,
        columns
      },
      tableParam1: {
        columns,
        maxHeight: document.body.clientHeight - 296
      },
      operateOptions: [
        {
          name: this.$t('message.watch'),
          command: 'watch'
        }
      ],
      search: {
        messageType: '', // 类型
        messageStatus: '0' // 全部 1已读 0未读
      },
      pageNum: 1,
      pageSize: 10,
      total: 0,
      multipleSelection: []
    }
  },
  created() {
    this.getList()
  },
  methods: {
    // 获取列表
    getList() {
      var params = {
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        ...this.search
      }
      this.$store.dispatch('message_messageInfo', params).then(data => {
        this.tableData = data.list
        this.total = data.total
        this.multipleSelection = []
      })
    },
    // 已经选择的列表项
    handleSelect(val = []) {
      this.multipleSelection = val
    },
    // 查看详情
    watchDetails({ id }) {
      this.detailVisible = true
      this.messageId = id
    },
    // 将未读标记为已读
    changeStateToReaded() {
      this.$store
        .dispatch('message_readMessageInfo', {
          id: this.multipleSelection.map(x => x.id).join(),
          messageSource: this.multipleSelection.map(x => x.messageSource).join()
        })
        .then(res => {
          if (res.code === '0') {
            this.$message.success(this.$t('message.success'))
            this.dialogVisible = false
            this.pageNum = 1
            this.getList()
          }
        })
    },
    // 标签切换
    tabClick() {
      this.pageNum = 1
      this.search.messageType = ''
      this.getList()
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.zv-message__title {
  padding: 0 16px;
  border-bottom: 1px solid $border-color;
}
.zv-message {
  &__container {
    padding: 0 16px;
  }
  &__table-title {
    cursor: pointer;
    &:hover {
      color: $base-color;
    }
  }
  &__footer {
    border-top: 1px solid $border-color;
    position: relative;
    z-index: 10;
    background: #fff;
  }
}
</style>
