<!-- 
/**
 * author: 肖景
 * description: 消息设置
 * time: 2019-10-25
 */
-->

<template>
  <zv-dialog
    v-model="currentValue"
    :title="$t('message.dialogTitle')"
    width="440px"
    bodyHeight="312px"
    @submit="submit"
  >
    <zv-dymanic-form
      ref="dymanicForm"
      type="block"
      v-model="formValue"
      :schema="schema"
    />
  </zv-dialog>
</template>

<script>
import ZvModel from '@/mixins/zv-model'
import { getDetail, createMessageSetting } from '@/api/message'
export default {
  name: 'ZvMessageSetting',
  mixins: [ZvModel],
  data() {
    return {
      formValue: {
        messageType: [],
        subtype: []
      },
      schema: {
        messageType: {
          componentName: 'ZvSelectLabel',
          options: this.$getDataDic('messageType'),
          placeholder: this.$t('message.messageTypePlaceholder'),
          componentType: 'Select',
          isRequired: true,
          multiple: true,
          collapseTags: true,
          title: this.$t('message.messageType'),
          validator: [
            [
              'checkRequired',
              {
                msg: this.$t('message.messageTypePlaceholder'),
                trigger: ['change']
              }
            ]
          ]
        }
      }
    }
  },
  watch: {
    currentValue(value) {
      if (value) {
        this.getDetail()
      }
    },
    // 根据内容来动态来渲染子内容
    'formValue.messageType'(value) {
      if (value.includes('12')) {
        this.$set(this.schema, 'subtype', {
          componentName: 'ZvSelectLabel',
          options: this.$getDataDic('dangerousOperationType'),
          placeholder: this.$t('message.warningTypePlaceholder'),
          componentType: 'Select',
          isRequired: true,
          multiple: true,
          collapseTags: true,
          title: this.$t('message.warningType'),
          validator: [
            [
              'checkRequired',
              {
                msg: this.$t('message.warningTypePlaceholder'),
                trigger: ['change']
              }
            ]
          ]
        })
      } else {
        this.$set(this.schema, 'subtype', {})
      }
    }
  },
  methods: {
    // 获取设置信息
    async getDetail() {
      try {
        const { dataList } = await getDetail()
        const messageType = Object.keys(dataList)
        let subtype = []
        if (messageType.includes('12') && dataList['12']) {
          subtype = dataList['12'].split()
        }
        this.formValue = {
          messageType,
          subtype
        }
      } catch (error) {
        throw error
      }
    },
    // 更新设置信息
    async createMessageSetting() {
      try {
        let dtos = []
        this.formValue.messageType.forEach(value => {
          let subtype = value !== '12' ? '' : this.formValue.subtype.join()
          dtos.push({
            messageType: value,
            subtype
          })
        })
        await createMessageSetting({
          messageTypes: JSON.stringify({ dtos })
        })
        this.$message.success('设置成功')
        this.currentValue = false
      } catch (error) {
        throw error
      }
    },
    // 提交前的表单校验
    submit() {
      this.$refs['dymanicForm'].validate().then(res => {
        if (res) {
          this.createMessageSetting()
        }
      })
    }
  }
}
</script>
