<!-- 
/**
 * author: 肖景
 * description: 消息详情
 * time: 2019-10-25
 */
-->

<template>
  <zv-dialog
    v-model="currentValue"
    :title="$t('message.dialogTitle')"
    :btn-list="['submit']"
    width="440px"
    bodyHeight="312px"
    @submit="currentValue = false"
  >
    <div class="zv-message__detail">
      <div class="zv-message__detail-title">
        {{ details.appTitle }}
      </div>
      <div class="zv-message__detail-content" v-html="details.content"></div>
      <div
        class="zv-message__detail-link"
        v-if="details.isUrl === 'Y' && details.pcUrl"
      >
        <zv-link type="primary" @click.native="toUrl">
          {{ $t(message.toDeal) }}
        </zv-link>
      </div>
      <div class="zv-message__detail-info">
        {{ details.creator }}/{{ details.sendTime }}
      </div>
    </div>
  </zv-dialog>
</template>

<script>
import ZvModel from '@/mixins/zv-model'
export default {
  name: 'ZvMessageDetail',
  mixins: [ZvModel],
  props: {
    messageId: {
      type: String
    }
  },
  data() {
    return {
      details: {}
    }
  },
  watch: {
    messageId(id) {
      this.$store.dispatch('message_queryDetail', { id }).then(data => {
        this.details = data.messageInfoDto || data.detailDto
      })
    }
  },
  methods: {
    toUrl() {
      window.location.href = this.details.pcUrl
    }
  }
}
</script>

<style lang="scss" scoped>
.zv-message__detail {
  &-title {
    margin: 14px 0 22px 0;
    color: $base-font-color;
    font-size: 16px;
  }
  &-content {
    color: $base-font-color;
    font-size: $base-font-size;
  }
  &-link {
    margin-top: 16px;
  }
  &-info {
    color: $sub-font-color;
    font-size: $base-font-size;
    margin-top: 30px;
  }
}
</style>
