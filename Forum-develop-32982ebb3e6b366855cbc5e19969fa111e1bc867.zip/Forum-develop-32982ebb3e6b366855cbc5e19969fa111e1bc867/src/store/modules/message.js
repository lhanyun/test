/*
 * @Author: your name
 * @Date: 2019-11-08 09:22:40
 * @LastEditTime: 2019-11-12 13:21:56
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \pc-bbs\src\store\modules\message.js
 */
import * as api from '@/api/message'
import * as companyApi from '@/api/companyApi'

var message = {
  state: {
    taskCount: 0,
    messageCount: 0
  },
  mutations: {
    SET_TASK_COUNT(state, payload) {
      state.taskCount = payload
    },
    SET_MESSAGE_COUNT(state, payload) {
      state.messageCount = payload
    }
  },
  actions: {
    // 消息列表
    message_messageInfo(store, payload) {
      return api.messageInfo(payload)
    },
    message_queryDetail(store, payload) {
      return api.queryDetail(payload)
    },
    message_readMessageInfo(store, payload) {
      return api.readMessageInfo(payload)
    },
    message_queryUnreadTask(store, payload) {
      return api.queryUnreadTask(payload)
    },
    message_queryUnreadMessage(store, payload) {
      return api.queryUnreadMessage(payload)
    },
    getCompanyUploadFile(store, payload) {
      return new Promise((resolve, reject) => {
        companyApi
          .uploadFile(payload)
          .then(res => {
            resolve(res)
          })
          .catch(error => {
            console.log(error)
            reject(error)
          })
      })
    }
  }
}

export default message
