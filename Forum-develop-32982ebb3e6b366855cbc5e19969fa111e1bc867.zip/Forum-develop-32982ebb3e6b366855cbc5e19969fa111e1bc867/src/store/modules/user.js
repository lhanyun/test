import {
  login,
  logout,
  getUserInfo,
  smsLogin,
  getUserMenuTreeByAppType,
  chooseCorp
} from '@/api/login'
import {
  getToken,
  setToken,
  removeToken,
  getUserInfoByKey,
  setUserInfo,
  getAppType,
  removeUserInfo
} from '@/utils/auth'
import storage from 'good-storage'

import * as companyApi from '@/api/companyApi'

const user = {
  state: {
    token: getToken(),
    appType: getAppType(),
    name: '',
    avatar: '',
    roles: [],
    userInfo: getUserInfoByKey() ? JSON.parse(getUserInfoByKey()) : {},
    menuTree: [],
    orgList: [],
    functionLists: [],
    loginType: 'password' // 登录页面登录方式
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_LOGIN_TYPE(state, payload) {
      state.loginType = payload
    },
    SET_USERINFO: (state, data) => {
      state.userInfo = data
    },
    UPDATE_USERINFO: (state, data) => {
      state.userInfo = {
        ...state.userInfo,
        ...data
      }
      setUserInfo(state.userInfo)
    },
    SET_MENU: (state, data) => {
      state.menuTree = data
    },
    SET_ORGLIST: (state, orgList) => {
      state.orgList = orgList
    },
    SET_FUNCTIONLISTS: (state, functionDtos) => {
      state.functionLists = functionDtos
    }
  },

  actions: {
    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 账号登录
     */
    Login({ commit }, userInfo) {
      userInfo.username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        login(userInfo)
          .then(response => {
            if (response.sessionId) {
              setToken(response.sessionId)
              commit('SET_TOKEN', response.sessionId)
              setUserInfo(response)
              commit('SET_USERINFO', response)
            }
            resolve(response)
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 短信登录
     */
    SMSLogin({ commit }, userInfo) {
      return new Promise((resolve, reject) => {
        smsLogin(userInfo)
          .then(response => {
            if (response.sessionId) {
              setToken(response.sessionId)
              commit('SET_TOKEN', response.sessionId)
              setUserInfo(response)
              commit('SET_USERINFO', response)
            }
            resolve(response)
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    /**
     * @author: 肖景
     * @date: 2019-07-10
     * @description: 登出
     */
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token)
          .then(data => {
            commit('SET_TOKEN', '')
            removeToken()
            removeUserInfo()
            storage.clear()
            resolve(data)
          })
          .catch(error => {
            reject(error)
          })
      })
    },

    GetUserInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        console.log(state.appType)

        getUserInfo({
          appType: state.appType
        })
          .then(data => {
            commit('SET_USERINFO', data.userRoleTypeDto)
            resolve(data)
          })
          .catch(e => {
            reject(e)
          })
      })
    },

    GetConfigRouter({ commit, state }) {
      return new Promise((resolve, reject) => {
        getUserMenuTreeByAppType(state.appType)
          .then(data => {
            commit('SET_MENU', data.menuTree[0].children)
            commit('SET_ORGLIST', data.orgList)
            commit('SET_FUNCTIONLISTS', data.functionDtos)
            resolve(data)
          })
          .catch(e => {
            reject(e)
          })
      })
    },

    // 选择公司
    ChooseCorp(store, param) {
      return new Promise((resolve, reject) => {
        chooseCorp(param)
          .then(data => {
            resolve(data)
          })
          .catch(error => {
            reject(error)
          })
      })
    }
  },

  getCompanyUploadFile(store, payload) {
    return new Promise((resolve, reject) => {
      companyApi
        .uploadFile(payload)
        .then(res => {
          resolve(res)
        })
        .catch(error => {
          console.log(error)
          reject(error)
        })
    })
  }
}

export default user
