const getters = {
  token: state => state.user.token,
  appType: state => state.user.appType,
  userInfo: state => state.user.userInfo,
  sidebar: state => state.app.sidebar,
  orgList: state => state.user.orgList,
  functionLists: state => state.user.functionLists,
  menuTree: state => state.user.menuTree
}
export default getters
