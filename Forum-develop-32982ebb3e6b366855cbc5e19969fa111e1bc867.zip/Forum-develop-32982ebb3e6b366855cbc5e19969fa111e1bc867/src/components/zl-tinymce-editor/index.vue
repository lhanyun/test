<!--公用组件：富文本
    /**
    *
    * @desc 
    * @author 白杨
    * @date 2019年8月7日19:00:00
    * // 示例
    *  <tinymce-editor ref="editor"
    *      v-model="contentText"
    *      :disabled="disabled"
    *      @urlUpload="urlUpload"
    *      @onClick="onClick">
    *  </tinymce-editor>
    * @example 示例地址 @/views/knowledge-base/knowledge-base-details
    */
-->
<template>
  <div class="tinymce-editor">
    <editor
      v-model="myValue"
      :init="init"
      :disabled="disabled"
      @onClick="onClick"
    >
    </editor>
  </div>
</template>
<script>
import tinymce from 'tinymce/tinymce'
import Editor from '@tinymce/tinymce-vue'
import 'tinymce/themes/silver'
import 'tinymce/plugins/image' // 插入上传图片插件
import 'tinymce/plugins/imagetools'
// import 'tinymce/plugins/media' // 插入视频插件
import 'tinymce/plugins/table' // 插入表格插件
import 'tinymce/plugins/lists' // 列表插件
import 'tinymce/plugins/wordcount' // 字数统计插件
import * as knowledgeApi from '@/api/knowledgeApi'

import { getToken } from '@/utils/auth'
export default {
  name: 'zl-tinymce-editor',
  components: {
    Editor
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    plugins: {
      type: [String, Array],
      default: 'lists image media table wordcount imagetools'
    },
    toolbar: {
      type: [String, Array],
      default:
        'undo redo |  formatselect | bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | lists image media table | removeformat'
    }
  },
  data() {
    return {
      fileClass: 'BBSTopic',
      isOpen: 'Y',
      baseUrl: this.$BASE_API,
      arrImg: [], // 图片路径存储
      init: {
        language_url: '/forum/tinymce/zh_CN.js', // 打包用这个地址
        // language_url: '/tinymce/zh_CN.js', // 调试用这个地址
        language: 'zh_CN',
        skin_url: '/forum/skins/ui/oxide', // 打包用这个地址
        // skin_url: '/skins/ui/oxide', // 调试用这个地址
        // skin_url: '/tinymce/skins/ui/oxide-dark', //暗色系
        height: 500,
        plugins: this.plugins,
        toolbar: this.toolbar,
        branding: false,
        menubar: false,
        // 此处为图片上传处理函数，这个直接用接口形式上传图片，
        images_upload_handler: (blobInfo, success) => {
          // const img = 'data:image/jpeg;base64,' + blobInfo.base64()
          var form = new FormData()
          form.append('fileClass', this.fileClass)
          form.append('isOpen', this.isOpen)
          form.append('sessionId', getToken())
          form.append('clientId', 'poweb')
          form.append('file', blobInfo.blob(), blobInfo.filename())
          this.$store.dispatch('getCompanyUploadFile', form).then(res => {
            knowledgeApi
              .richTextUpdateImg({ baseUrl: this.baseUrl, imgId: res.id })
              .then(res => {
                success(res.pictureUrl)
                this.arrImg.push(res.pictureUrl)
                this.$emit('imgUrl', this.arrImg)
              })
          })
        }
      },
      myValue: this.value
    }
  },
  watch: {
    value(newValue) {
      this.myValue = newValue
    },
    myValue(newValue) {
      this.$emit('input', newValue)
    }
  },
  mounted() {
    tinymce.init({})
  },
  methods: {
    // 需要什么事件可以自己增加
    onClick(e) {
      this.$emit('onClick', e, tinymce)
    },
    // 可以添加一些自己的自定义事件，如清空内容
    clear() {
      this.myValue = ''
    }
  }
}
</script>
<style lang="scss" scoped>
// 选项上下边框
/deep/.tox-tinymce {
  border: 1px solid #e0e0e0 !important;
}
/deep/.tox-toolbar__primary {
  border: 0 !important;
}
// 内部边框
/deep/.tox-toolbar__group:not(:last-of-type) {
  border-right: 1px solid #e0e0e0 !important;
}
//文字上边框
/deep/.tox-edit-area {
  border-top: 1px solid #e0e0e0 !important;
}
// 字数统计上边框
/deep/.tox-statusbar {
  border-top: 1px solid #e0e0e0 !important;
}
</style>
