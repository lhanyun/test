<!-- 区域围栏地图组件
    /**
    * @author 肖景
    * @date 2019/7/05
    */
-->
<template>
  <el-amap
    vid="amapDemo"
    :plugin="plugin"
    :zoom="zoom"
    :center="path.length && path[0].length ? path[0] : center"
    class="zv-amap-polygon"
  >
    <el-amap-polygon
      v-for="(polygon, index) in polygons"
      :key="index"
      :vid="index"
      :ref="`polygon_${index}`"
      fill-opacity="0.3"
      stroke-weight="2"
      stroke-color="#7cb342"
      fill-color="#7cb342"
      :path="polygon.path"
      :draggable="false"
      :editable="editable"
      :events="polygon.events"
    />
  </el-amap>
</template>

<script>
import mapMixins from './mixins'
export default {
  name: 'ZvMapPolygon',
  mixins: [mapMixins],
  props: {
    editable: {
      type: Boolean,
      default: false
    },
    path: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      polygons: [
        {
          path: [],
          events: {
            end: ({ type, target }) => {
              console.log('多边形编辑结束', type, target)
              this.$emit('handler-adjust', target)
            }
          }
        }
      ],
      events: {
        click: e => {
          if (this.editable) {
            const arr = [e.lnglat.lng, e.lnglat.lat]
            let polygons = this.polygons[0]
            polygons.path.push(arr)
            this.polygons = [polygons]
          }
        },
        init: () => {
          let polygons = this.polygons[0]
          polygons.path = this.path
          this.polygons = [polygons]
        }
      }
    }
  }
}
</script>
