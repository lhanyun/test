<!-- 海量点地图组件
    /**
    * @author 肖景
    * @date 2019/7/05
    */
-->
<template>
  <el-amap
    vid="amapDemo"
    :plugin="plugin"
    :zoom="zoom"
    :center="center"
    :events="events"
    class="zv-amap"
  >
    <template v-if="markersType === 'markers'">
      <el-amap-marker
        v-for="(marker, index) in markers"
        :key="index"
        :position="marker.position"
        :events="markerEvents"
        :visible="marker.visible"
        :icon="marker.icon"
        :offset="[-16, -32]"
        :vid="index"
      />
    </template>
    <el-amap-info-window
      v-if="window.showInfoWindow"
      :position="window.position"
      :offset="[-10, -10]"
    >
      <div class="infobox-container">
        <slot v-bind:params="content" />
      </div>
    </el-amap-info-window>
  </el-amap>
</template>

<script>
/* eslint-disable */
import mapMixins from './mixins'
export default {
  name: 'ZvMapMarker',
  mixins: [mapMixins],
  props: {
    markers: {
      type: Array,
      default() {
        return []
      }
    },
    styleList: {
      type: Array,
      default() {
        return []
      }
    },
    markersType: {
      type: String,
      default: 'canvas',
      validator(value) {
        return ['canvas', 'markers'].includes(value)
      }
    }
  },
  data() {
    return {
      content: {},
      Map: null,
      massMarks: null,
      timeout: '',
      window: {
        showInfoWindow: false,
        position: [121.59996, 31.197646]
      },
      markerEvents: {
        click: e => {
          this.window.showInfoWindow = false
          this.window.position = [e.lnglat.lng, e.lnglat.lat]
          this.center = [e.lnglat.lng, e.lnglat.lat]
          this.content = this.markers[e.target.ue.vid]
          this.$nextTick(() => {
            this.window.showInfoWindow = true
          })
        }
      },
      events: {
        init: e => {
          let style = this.styleList.length ? this.styleList : []
          style.forEach(ele => {
            ele.anchor = new AMap.Pixel(6, 6)
            ele.size = new AMap.Size(24, 24)
          })
          let massMarks = new AMap.MassMarks(this.markers, {
            opacity: 0.8,
            zIndex: 111,
            cursor: 'pointer',
            style
          })
          this.Map = e
          this.massMarks = massMarks
          massMarks.on(
            'click',
            function(e) {
              this.window.showInfoWindow = false
              this.center = [e.data.lnglat.lng, e.data.lnglat.lat]
              this.window.position = [e.data.lnglat.lng, e.data.lnglat.lat]
              this.content = e.data
              this.zoom = 4
              this.$nextTick(() => {
                this.zoom = 16
                this.window.showInfoWindow = true
              })
            }.bind(this)
          )
          massMarks.setMap(e)
          if (this.markers.length < 100) {
            this.massMarks.setData([])
          }
        }
      },
      currentPath: this.$route.name
    }
  },
  watch: {
    markers(value) {
      if (this.timeout) {
        clearInterval(this.timeout)
      }
      this.zoom = 4
      this.window.showInfoWindow = false
      if (this.Map && this.massMarks) {
        if (this.markersType === 'canvas') {
          let style = this.styleList.length ? this.styleList : []
          style.forEach(ele => {
            ele.anchor = new AMap.Pixel(6, 6)
            ele.size = new AMap.Size(24, 24)
          })
          this.massMarks.setStyle(style)
          this.massMarks.setData(value)
        } else {
          this.massMarks.setData([])
        }
      } else {
        this.timeout = setInterval(() => {
          if (this.Map && this.massMarks) {
            clearInterval(this.timeout)
            if (this.markersType === 'canvas') {
              let style = this.styleList.length ? this.styleList : []
              style.forEach(ele => {
                ele.anchor = new AMap.Pixel(6, 6)
                ele.size = new AMap.Size(24, 24)
              })
              this.massMarks.setStyle(style)
              this.massMarks.setData(value)
            } else {
              this.massMarks.setData([])
            }
          }
        }, 1000)
      }
    }
  },
  destroyed() {
    if (this.timeout) {
      clearInterval(this.timeout)
    }
  },
  methods: {
    refresh() {
      this.massMarks.setData([])
      this.$nextTick(() => {
        this.massMarks.setData(this.markers)
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.zv-amap {
  // 调整地图上的信息窗体的样式
  .amap-info-outer {
    padding: 0 16px;
    color: #fff;
    background: #000;
    opacity: 0.8;
  }

  .amap-info-close {
    color: #fff;
  }

  .amap-info-sharp {
    background: url('~@/assets/img/map_icon/sharp.png') no-repeat;
  }
}

.infobox-container {
  position: relative;
  padding-top: 10px;
}

.infobox-close {
  position: absolute;
  width: 14px;
  height: 14px;
  right: -14px;
  top: -20px;
}
</style>
