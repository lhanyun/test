<!-- 地图第二版组件
    /**
    * @author 肖景
    * @date 2019/7/05
    */
-->
<template>
  <div class="zv-map2">
    <zv-map-marker
      ref="map"
      v-if="type === 'marker'"
      v-bind="$attrs"
      v-on="$listeners"
    >
      <template v-slot:default="{ params }">
        <slot v-bind:params="params" />
      </template>
    </zv-map-marker>
    <zv-map-circle
      ref="map"
      v-else-if="type === 'circle'"
      v-bind="$attrs"
      v-on="$listeners"
    >
      <template #default>
        <slot />
      </template>
    </zv-map-circle>
    <zv-map-polygon
      ref="map"
      :editable="editable"
      v-else
      v-bind="$attrs"
      v-on="$listeners"
    />
  </div>
</template>

<script>
import ZvMapMarker from './zv-map-marker'
import ZvMapCircle from './zv-map-circle'
import ZvMapPolygon from './zv-map-polygon'
export default {
  name: 'ZvMap2',
  components: { ZvMapMarker, ZvMapCircle, ZvMapPolygon },
  props: {
    // 地图的类型
    // 坐标点/点围栏/区域围栏
    type: {
      type: String,
      default: 'marker',
      validator(value) {
        return ['marker', 'circle', 'polygon'].includes(value)
      }
    },
    // 是否可编辑
    editable: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    /**
     * @author 肖景
     * @date 2019-07-05
     * @description 地址转经纬度方法
     */
    getLocation(address) {
      return this.$refs.map.getLocation(address)
    },
    /**
     * @author 肖景
     * @date 2019-07-05
     * @description 经纬度转地址的方法
     */
    getAddress(lnglat = []) {
      return this.$refs.map.getAddress(lnglat)
    },
    /**
     * @author 肖景
     * @date 2019-07-05
     * @description 刷新地图的图标
     */
    refresh() {
      if (this.$refs.map.refresh) {
        this.$refs.map.refresh()
      }
    }
  }
}
</script>

<style lang="scss">
.zv-map2 {
  height: calc(100vh - 140px);
  .amap-scalecontrol {
    right: 2px !important;
    left: auto !important;
  }
}
</style>
