/* eslint-disable */
export default {
  data() {
    return {
      zoom: 4,
      center: [121.5273285, 31.21515044],
      plugin: [
        {
          pName: 'Scale',
          visible: true
        },
        {
          pName: 'ToolBar',
          visible: true
        }
      ]
    }
  },
  computed: {
    geocoder() {
      return new AMap.Geocoder({})
    }
  },
  methods: {
    /**
     * @author 肖景
     * @date 2019-07-05
     * @description 地址转经纬度
     */
    getLocation(address = '') {
      if (!this.geocoder) {
        this.geocoder = new AMap.Geocoder({})
      }
      return new Promise((resolve, reject) => {
        this.geocoder.getLocation(address, function(status, result) {
          if (status === 'complete' && result.geocodes.length) {
            resolve(result.geocodes[0])
          } else {
            reject({})
          }
        })
      })
    },
    /**
     * @author 肖景
     * @date 2019-07-05
     * @description 经纬度转地址
     */
    getAddress(lnglat = []) {
      if (!this.geocoder) {
        this.geocoder = new AMap.Geocoder({})
      }
      return new Promise((resolve, reject) => {
        this.geocoder.getAddress(lnglat, function(status, result) {
          if (status === 'complete' && result.regeocode) {
            resolve(result.regeocode)
          } else {
            reject()
          }
        })
      })
    }
  }
}
