<!-- 地图选择位置组件
    /**
    * @author 肖景
    * @date 2019/7/05
    */
-->
<template>
  <el-amap
    vid="amapDemo"
    :plugin="plugin"
    :zoom="zoom"
    :center="markers.length ? markers[0].position : center"
    :events="events"
    class="zv-amap"
  >
    <template v-if="markers.length < 100">
      <el-amap-marker
        v-for="(marker, index) in markers"
        :key="index"
        :position="marker.position"
        visible
        :icon="marker.icon"
        :offset="[-16, -32]"
        :vid="index"
      />
    </template>
  </el-amap>
</template>

<script>
import mapMixins from './mixins'
export default {
  name: 'ZvMapChoose',
  mixins: [mapMixins],
  props: {
    markers: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      events: {
        click: e => {
          this.$emit('click', e)
        }
      }
    }
  },
  watch: {
    markers() {
      this.zoom = 4
      this.$nextTick(() => {
        this.zoom = 12
      })
    }
  }
}
</script>

<style lang="scss">
.zv-map2 {
  .amap-scalecontrol {
    right: 2px !important;
    left: auto !important;
  }
}
</style>
