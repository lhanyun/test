<!-- 点围栏组件
    /**
    * @author 肖景
    * @date 2019/7/05
    */
-->
<template>
  <el-amap
    vid="amapDemo"
    :plugin="plugin"
    :zoom="zoom"
    :center="center"
    class="zv-amap"
  >
    <el-amap-marker
      v-for="(marker, index) in markers"
      :key="index"
      :position="marker.position"
      :events="marker.events"
      :visible="marker.visible"
      :icon="marker.icon"
      :offset="marker.offset"
      :vid="index"
    />
    <el-amap-circle
      v-for="(circle, index) in circles"
      :center="circle.center"
      :key="index"
      :radius="circle.radius"
      fill-opacity="0.3"
      stroke-weight="2"
      stroke-color="#7cb342"
      fill-color="#7cb342"
      :events="circle.events"
    />
    <el-amap-info-window
      v-if="window.showInfoWindow"
      :position="window.position"
      :offset="[-10, -10]"
    >
      <div>
        <slot />
      </div>
    </el-amap-info-window>
  </el-amap>
</template>

<script>
import mapMixins from './mixins'
export default {
  name: 'ZvMapCircle',
  mixins: [mapMixins],
  props: {},
  data() {
    return {
      count: 1,
      window: {
        showInfoWindow: false,
        position: [121.5273285, 31.21515044]
      },
      markers: [
        {
          position: [121.5273285, 31.21515044],
          events: {
            click: e => {
              this.window.showInfoWindow = false
              console.log('click marker', e)
              this.window.position = [e.lnglat.lng, e.lnglat.lat]
              this.$nextTick(() => {
                this.window.showInfoWindow = true
              })
            }
          },
          visible: true,
          draggable: false,
          icon: 'http://apisandbox.zoomlion.com/image/location/s/default.png',
          offset: [-16, -32]
        }
      ],
      circles: [
        {
          center: [121.5273285, 31.21515044],
          radius: 200,
          fillOpacity: 0.3, //圆不透明度
          fillColor: '#7cb342', // 圆形填充颜色
          strokeColor: '#7cb342', // 描边颜色
          strokeWeight: 2 // 描边宽度
        }
      ],
      events: {
        click: e => {
          const arr = [e.lnglat.lng, e.lnglat.lat]
          let polygons = this.polygons[0]
          polygons.path.push(arr)
          this.polygons = [polygons]
        }
      }
    }
  },
  methods: {
    onClick() {}
  }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.zv-amap {
  // 调整地图上的信息窗体的样式
  .amap-info-outer {
    padding: 0 16px;
    color: #fff;
    background: #000;
    opacity: 0.8;
  }

  .amap-info-close {
    color: #fff;
  }

  .amap-info-sharp {
    background: url('~@/assets/img/map_icon/sharp.png') no-repeat;
  }
}
</style>
