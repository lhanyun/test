<!--公用组件：地图组件
    /**
    * @desc 组件描述
    * @author 赵丹
    * @date 2019年4月4日15:32:00
    * @param {Number, String} [mapHeight]    - 地图高度(必填)
    * @param {Array} [markers]    - 点标记数据
    * @param {Boolean} [showMarker]    - 地图加载完成是否直接显示marker，默认为false不显示
    * @param {Array} [regionPosition]    - 多边形顶点坐标数组
    * @param {Object} [addData] - 针对点围栏定制的对象，包含传递的围栏名称（name）和围栏半径（radius）
    * @param {String} [markContentHtml] - 针对点围栏定制的对象，气泡窗体中内容的html的字符串
    * @param {String} [address] - 针对电子围栏定制的对象，用户输入的具体地址
    * @example 调用示例
    * <zv-map
        :address="address"
        ref="regionFenceMap"
        :markers="markers"
        :regionPosition="regionPosition"
        :addData="addData"
    * ></zv-map>
    */
-->
<template>
  <div class="amap-page-container" id="mapContainer" v-loading="mapLoading">
    <el-amap
      v-if="!refresh"
      ref="map"
      vid="aMap"
      :center="mapCenter"
      :style="`height:${thisMapHeight}`"
      :events="events"
      :plugin="plugin"
    />
  </div>
</template>

<script>
/* eslint-disable */
import point from '@/assets/img/map_icon/point.png'
import { lazyAMapApiLoaderInstance } from 'vue-amap'
import { Message } from 'element-ui'
const MyMarks = (param = {}) => {
  // 构造点标记
  return new AMap.Marker(param)
}
const MyCircleMarker = (param = {}) => {
  // 构造圆圈围栏
  let defaultParam = {
    center: '', // 圆心位置
    radius: '', // 圆半径
    fillOpacity: 0.3, //圆不透明度
    fillColor: '#7cb342', // 圆形填充颜色
    strokeColor: '#7cb342', // 描边颜色
    strokeWeight: 2 // 描边宽度
  }
  defaultParam.center = param.center
  defaultParam.radius = param.radius
  return new AMap.Circle(defaultParam)
}
export default {
  name: 'ZvMap',
  props: {
    // 地图高度
    mapHeight: {
      type: [Number, String],
      default: ''
    },
    // 标记点的数组
    markers: {
      type: Array,
      default() {
        return []
      }
    },
    // 多边形顶点坐标数组
    regionPosition: {
      type: Array,
      default() {
        return []
      }
    },
    // 针对点围栏定制的对象
    addData: {
      type: Object,
      default() {
        return {}
      }
    },
    // 气泡窗体中内容的html的字符串
    markContentHtml: {
      type: String,
      default: ''
    },
    // 用户输入的具体地址
    address: {
      type: String,
      default: ''
    },
    // 地图加载完成是否直接显示marker
    showMarker: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    thisMapHeight() {
      return typeof this.mapHeight === 'number'
        ? this.mapHeight + 'px'
        : this.mapHeight
    }
  },
  data() {
    let that = this
    return {
      refresh: false,
      timer: null,
      timer1: null,
      timer2: null,
      point,
      mapLoading: true,
      mapFlag: false,
      addPointFenceFlag: true,
      drawPolygonFlag: true,
      map: null,
      mouseTool: null,
      mapObj: null,
      markersObjectArr: [],
      cluster: null,
      polyEditor: null,
      zoom: 14,
      radius: 0,
      mapCenter: [121.59996, 31.197646],
      geocoder: null,
      circleMarker: null,
      infoWindow: null,
      plugin: [
        {
          pName: 'Scale',
          visible: true
        },
        {
          pName: 'ToolBar',
          visible: true
        }
      ],
      mapInited: false,
      events: {
        async init() {
          that.mapLoading = false
          that.map = that.$refs.map.$$getInstance()
          if (that.timer1) {
            clearTimeout(that.timer1)
          }
          that.timer1 = setTimeout(() => {
            if (!that.mapInited) {
              that.refresh = true
              that.$nextTick(() => {
                that.refresh = false
              })
            }
          }, 5000)
          that.map.on('complete', function() {
            that.mapInited = true
            if (!that.geocoder) {
              that.geocoder = new AMap.Geocoder({})
            }
          })
          that.mapFlag = true
        },
        zoomchange() {
          that.zoom = that.map.getZoom()
        }
      }
    }
  },
  watch: {
    addData(val) {
      this.radius = !val ? 0 : val.radius || 0
    },
    markers: {
      handler(newValue, oldValue) {
        let that = this
        if (that.infoWindow) {
          that.infoWindow.close()
        }
        that.timer = setInterval(() => {
          if (!this.mapInited) return
          if (newValue !== oldValue) {
            let changeMarkers = []
            that.markersObjectArr = []
            that.showMakers()
            // 获取变更图标的marker并将视图定位到该点
            newValue.forEach(newItem => {
              oldValue.forEach((oldItem, index) => {
                if (
                  newItem.position.length &&
                  oldItem.position.length &&
                  newItem.position[0] === oldItem.position[0] &&
                  newItem.position[1] === oldItem.position[1] &&
                  newItem.icon !== oldItem.icon
                ) {
                  changeMarkers.push(that.markersObjectArr[index])
                }
              })
            })
            if (changeMarkers.length) {
              that.fitView(changeMarkers)
            }
            clearInterval(that.timer)
          }
        }, 200)
      },
      deep: true
    }
  },
  async created() {
    try {
      await lazyAMapApiLoaderInstance.load()
      this.addPointFenceFlag = true
      this.drawPolygonFlag = true
    } catch (error) {
      Message.error('地图资源加载失败,请刷新重尝试')
      throw error
    }
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  },
  methods: {
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 抛出整个vue实例
     */
    transVue() {
      this.$emit('on-trans-map', this)
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 根据详细地址转换成高德经纬度并设立maker
     */
    geoCode(type = '') {
      let that = this
      let marker
      let address = this.address
      that.geocoder.getLocation(address, function(status, result) {
        if (status === 'complete' && result.geocodes.length) {
          let lnglat = [
            result.geocodes[0].location.lng,
            result.geocodes[0].location.lat
          ]
          that.mapCenter = lnglat
          // that.map.setCenter(lnglat)
          if (!marker) {
            marker = new MyMarks()
            that.map.add(marker)
          }
          // 设置鼠标划过点标记显示的文字提示
          marker.setTitle(address)
          marker.setPosition(lnglat)
          // 点围栏
          if (type === 'point') {
            // 窗体
            if (that.infoWindow) {
              that.infoWindow.close()
            }
            that.infoWindow = new AMap.InfoWindow({
              position: lnglat,
              offset: new AMap.Pixel(0, -35)
            })
            // 标记点击事件
            let markerClick = e => {
              if (that.addPointFenceFlag) {
                that.infoWindow.setContent(that.markContentHtml)
                that.circleMarker = new MyCircleMarker({
                  center: lnglat,
                  radius: 0
                })
                that.map.add(that.circleMarker)
                that.infoWindow.open(that.map, e.target.getPosition())
              }
              that.addPointFenceFlag = false
              that.$emit('on-bind-function')
            }
            marker.on('click', markerClick)
            that.infoWindow.open(that.map)
          } else if (type === 'region') {
            that.drawPolygon()
          }
          that.fitView(marker)
        } else {
          this.$message({
            message: result,
            type: 'error'
          })
        }
      })
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 展示多个maker
     */
    showMakers() {
      let that = this
      try {
        let markersArr = []
        markersArr = that.markers
        if (that.infoWindow) {
          that.infoWindow.close()
        }
        that.infoWindow = new AMap.InfoWindow({
          offset: new AMap.Pixel(-3, -20)
        })
        let markerClick = e => {
          that.infoWindow.setContent(e.target.content)
          that.infoWindow.open(that.map, e.target.getPosition())
        }
        that.markersObjectArr = []
        if (markersArr && markersArr.length > 0) {
          markersArr.forEach(marker => {
            if (marker.position[0] && marker.position[1]) {
              let myMarker = new AMap.Marker({
                map: that.map,
                icon: marker.icon,
                position: marker.position
              })
              myMarker.content = marker.content
              if (marker.content) {
                myMarker.on('click', markerClick)
              }
              that.markersObjectArr.push(myMarker)
            }
          })
        }
        // 点聚合
        let pointStyle = [
          {
            url: point,
            size: new AMap.Size(56, 56),
            offset: new AMap.Pixel(-28, -28)
          }
        ]
        if (that.cluster) {
          that.cluster.setMap(null)
          that.cluster = null
        }
        // @param markersObjectArr为markers的Marker对象数组，不能为数据数组
        that.cluster = new AMap.MarkerClusterer(
          that.map,
          that.markersObjectArr,
          {
            gridSize: 80,
            minClusterSize: 2,
            averageCenter: true,
            styles: pointStyle
            // renderClusterMarker: that.myRenderClusterMarker
          }
        )
        that.fitView(that.markersObjectArr)
      } catch (e) {
        that.events.init()
        throw e
      }
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 点聚合样式
     */
    myRenderClusterMarker(context) {
      const zoom = this.map.getZoom()
      const zc = zoom > 12 ? 30 : 0
      const div = document.createElement('div')
      div.style.backgroundColor = '#95b223'
      const size = 100 - zc
      div.style.width = div.style.height = size + 'px'
      div.style.borderRadius = size / 2 + 'px'
      div.innerHTML = context.count
      div.style.lineHeight = size + 'px'
      div.style.color = '#ffffff'
      div.style.fontSize = '14px'
      div.style.textAlign = 'center'
      context.marker.setOffset(new AMap.Pixel(-size / 2, -size / 2))
      context.marker.setContent(div)
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 展示编辑信息窗体
     */
    showInfoWindow(param = {}) {
      let that = this
      if (!that.infoWindow) {
        console.log(1)
        that.infoWindow = new AMap.InfoWindow({
          position: param.lnglat,
          offset: new AMap.Pixel(0, -35)
        })
      }
      if (that.infoWindow) {
        that.infoWindow.close()
      }
      that.infoWindow = new AMap.InfoWindow({
        position: param.lnglat,
        offset: new AMap.Pixel(0, -35)
      })
      that.infoWindow.setContent(that.markContentHtml)
      that.infoWindow.open(that.map)
      that.fitView()
      setTimeout(() => {
        that.$emit('on-bind-function', param)
      }, 50)
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 点围栏更改半径生成新的围栏
     */
    changeRadius(param = {}) {
      if (this.circleMarker) {
        this.map.remove(this.circleMarker)
      }
      if (param.mapCenter) {
        this.mapCenter = param.mapCenter
      }
      this.circleMarker = new MyCircleMarker({
        center: param.mapCenter || this.mapCenter,
        radius: param.radius || this.addData.radius
      })
      this.map.add(this.circleMarker)
      this.fitView()
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 点围栏绘制完成
     */
    drawComplete() {
      this.infoWindow.close()
      this.addPointFenceFlag = false
      this.drawPolygonFlag = false
      this.transVue()
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 自适应视图
     */
    fitView(views) {
      if (!views || !views.length) {
        this.map.setZoom(14)
        return
      }
      this.map.setFitView(views)
      if (this.timer2) {
        clearTimeout(this.timer2)
      }
      this.timer2 = setTimeout(() => {
        // zoom: 14  =>   500米
        // zoom: 4   =>   500公里
        if (this.zoom > 14) {
          this.map.setZoom(14)
        }
        if (this.zoom < 4) {
          this.map.setZoom(4)
        }
      }, 500)
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 清理地图所有覆盖物
     */
    clearMap() {
      this.map.clearMap()
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 绘制多边形
     */
    drawPolygon() {
      let that = this
      if (that.drawPolygonFlag) {
        let mouseTool = new AMap.MouseTool(that.map)
        mouseTool.on('draw', function(event) {
          that.$emit('on-region-drawed', event.obj.ue.path)
          that.map.clearMap()
          // event.obj 为绘制出来的覆盖物对象
          let polygon = new AMap.Polygon({
            path: event.obj.ue.path,
            strokeColor: '#7cb342',
            strokeWeight: 3,
            strokeOpacity: 0.6,
            fillOpacity: 0.4,
            fillColor: '#7cb342',
            zIndex: 50
          })
          that.map.add(polygon)
          that.fitView([polygon])
          that.polyEditor = new AMap.PolyEditor(that.map, polygon)
          that.polyEditor.open()
          that.polyEditor.on('end', function(event) {
            that.$emit('on-region-drawed', event.target.ue.path)
          })
        })
        mouseTool.polygon({
          strokeColor: '#7cb342',
          strokeOpacity: 0.6,
          strokeWeight: 3,
          fillColor: '#7cb342',
          fillOpacity: 0.4,
          strokeStyle: 'solid'
        })
      }
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 展示多边形
     */
    showRegion(edit = false) {
      let that = this
      if (!that.map) {
        that.map = new AMap.Map('mapContainer', {
          resizeEnable: true
        })
        that.map.on('complete', function() {
          let toolBar = new AMap.ToolBar({
            visible: true
          })
          let scale = new AMap.Scale({
            visible: true
          })
          that.map.addControl(toolBar)
          that.map.addControl(scale)
        })
      }
      if (Array.isArray(that.regionPosition[0][0])) {
        // 展示多个多边形
        let polygonArr = []
        that.regionPosition.forEach(item => {
          let polygon = new AMap.Polygon({
            path: item,
            strokeColor: '#7cb342',
            strokeWeight: 3,
            strokeOpacity: 0.6,
            fillOpacity: 0.4,
            fillColor: '#7cb342',
            zIndex: 50
          })
          that.map.add(polygon)
          polygonArr.push(polygon)
        })
        that.fitView(polygonArr)
      } else {
        // 展示单个多边形并提供可编辑功能
        let polygon = new AMap.Polygon({
          path: that.regionPosition,
          strokeColor: '#7cb342',
          strokeWeight: 3,
          strokeOpacity: 0.6,
          fillOpacity: 0.4,
          fillColor: '#7cb342',
          zIndex: 50
        })
        that.map.add(polygon)
        that.fitView([polygon])
        if (edit) {
          that.polyEditor = new AMap.PolyEditor(that.map, polygon)
          that.polyEditor.open()
          that.polyEditor.on('end', function(event) {
            that.$emit('on-region-drawed', event.target.ue.path)
          })
        }
      }
    },
    /**
     * @author 赵丹
     * @date 2019/4/12
     * @description 关闭绘制多边形
     */
    closeDrawRegion() {
      if (this.polyEditor) {
        this.polyEditor.close()
      }
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
#mapContainer {
  position: relative;
}
</style>
<style>
.amap-scalecontrol {
  right: 2px !important;
  left: auto !important;
}
</style>
