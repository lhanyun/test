const directives = []
const requireAll = requireContext =>
  requireContext.keys().map(requireContext => {
    directives.push(requireContext)
    return requireContext
  })
const req = require.context('./', false, /\.js$/)
requireAll(req)

directives.forEach(directivePath => {
  if (directivePath !== './index.js') {
    require(`${directivePath}`)
  }
})
