import Vue from 'vue'
import store from '@/store'

Vue.directive('permissions', {
  bind(el, { value }) {
    const functionLists = store.getters.functionLists
    if (!functionLists.filter(item => item.code === value).length) {
      el.style.display = 'none'
    }
  }
})
