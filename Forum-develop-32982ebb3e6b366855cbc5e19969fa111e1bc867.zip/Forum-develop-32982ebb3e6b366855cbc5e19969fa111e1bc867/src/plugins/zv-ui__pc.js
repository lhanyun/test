import Vue from 'vue'

import ZvUI from 'zv-ui__pc'
import 'zv-ui__pc/lib/theme-chalk/index.css'

Vue.use(ZvUI)
