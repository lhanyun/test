import Vue from 'vue'
import VueAMap from 'vue-amap'

setTimeout(() => {
  let i = 0
  // eslint-disable-next-line
  while (true) {
    let key = window.localStorage.key(i)
    if (key === undefined || key === null) {
      break
    } else if (/_AMap_raster/g.test(key)) {
      window.localStorage.removeItem(key)
      break
    }
    i++
  }
  Vue.use(VueAMap)
  VueAMap.initAMapApiLoader({
    key: '44b4a42c39f5bdf712ec7d01524637a7',
    plugin: [
      'AMap.Autocomplete',
      'AMap.LngLat',
      'AMap.PolyEditor',
      'AMap.CircleEditor',
      'AMap.Marker',
      'AMap.MassMarks',
      'AMap.MouseTool',
      'AMap.Size',
      'AMap.Pixel',
      'AMap.Geocoder',
      'AMap.PlaceSearch',
      'AMap.Scale',
      'AMap.OverView',
      'AMap.ToolBar',
      'AMap.MapType',
      'MarkerClusterer'
    ],
    v: '1.4.9',
    uiVersion: '1.0.11'
  })
}, 0)
