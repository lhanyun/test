import Vue from 'vue'
import {
  removeToken,
  removeUserInfo,
  setRedirectUrl,
  removeRedirectUrl
} from '@/utils/auth' // getToken from cookie

const HOME_URL = process.env.VUE_APP_HOME_URL

const PERSON_SETTING = process.env.VUE_APP_PERSON_SETTING_URL

const ACCOUNT_INFO = process.env.VUE_APP_ACCOUNT_INFO_URL

// 非主动条件下注销用户
const redirectHome = (needSetUrl = true) => {
  removeToken()
  removeUserInfo()
  if (needSetUrl) {
    const href = window.location.href.split('#')
    setRedirectUrl(href[0])
  } else {
    removeRedirectUrl()
  }
  window.location.href = HOME_URL
}

// 主动条件下注销用户
const logout = () => {
  removeToken()
  removeUserInfo()
  window.location.href = HOME_URL
}

Vue.prototype.$configParams = {
  redirectHome,
  logout,
  personSetting: PERSON_SETTING,
  accountInfo: ACCOUNT_INFO
}

export const configParams = {
  redirectHome
}
