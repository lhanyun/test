import Vue from 'vue'
import VueI18n from 'vue-i18n'
import Cookies from 'js-cookie'
import elementEnLocale from 'element-ui/lib/locale/lang/en' // element-ui lang
import elementZhLocale from 'element-ui/lib/locale/lang/zh-CN' // element-ui lang
import { zh_CN, en_US } from './locate'

Vue.use(VueI18n)

const messages = {
  en_US: {
    ...en_US,
    ...elementEnLocale
  },
  zh_CN: {
    ...zh_CN,
    ...elementZhLocale
  }
}

const i18n = new VueI18n({
  // set locale
  // options: en or zh
  locale: Cookies.get('language') || 'zh_CN',
  // set locale messages
  messages
})

export default i18n
