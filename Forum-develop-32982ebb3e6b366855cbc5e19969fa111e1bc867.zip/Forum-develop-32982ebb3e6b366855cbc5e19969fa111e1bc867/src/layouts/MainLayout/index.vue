<template>
  <div :class="['main-layout', sidebar.opened ? '' : 'hideSidebar']">
    <sidebar class="sidebar-container" />
    <div class="main">
      <navigate />
      <tags-view />
      <app-main />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import AppMain from './AppMain'
import Navigate from './Navigate'
import TagsView from './TagsView/index'
import Sidebar from './Sidebar2/index'
export default {
  name: 'index',
  components: { AppMain, Navigate, TagsView, Sidebar },
  computed: {
    ...mapGetters(['sidebar'])
  }
}
</script>

<style lang="scss" scoped>
.main-layout {
  position: relative;
  height: 100vh;
  width: 100vw;
  // .sidebar-container {
  //   position: absolute;
  //   height: 100%;
  //   width: 200px;
  //   top: 0;
  //   left: 0;
  //   background: $sideBg;
  //   transition: all 0.15s;
  // }
  .main {
    @include flex($direction: column);
    margin-left: 200px;
  }
  &.hideSidebar {
    .main {
      margin-left: 50px;
    }
  }
}
</style>
