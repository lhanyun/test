<template>
  <div id="tags-view-container" class="tags-view-container">
    <zv-scroll-pane ref="scrollPane" class="tags-view-wrapper">
      <transition-group name="tags-view" tag="div">
        <router-link
          v-for="tag in visitedViews"
          ref="tag"
          :key="tag.path"
          :class="isActive(tag) ? 'active' : ''"
          :to="{ path: tag.path, query: tag.query, fullPath: tag.fullPath }"
          tag="span"
          class="tags-view-item"
          @click.middle.native="closeSelectedTag(tag)"
          @contextmenu.prevent.native="openMenu(tag, $event)"
        >
          {{ tag.title }}
          <span
            v-if="!tag.meta.affix"
            class="el-icon-close"
            @click.prevent.stop="closeSelectedTag(tag)"
          />
        </router-link>
      </transition-group>
    </zv-scroll-pane>
    <ul
      v-show="visible"
      :style="{ left: left + 'px', top: top + 'px' }"
      class="contextmenu"
    >
      <li @click="refreshSelectedTag(selectedTag)">
        {{ $t('tagsView.refresh') }}
      </li>
      <li
        v-if="!(selectedTag.meta && selectedTag.meta.affix)"
        @click="closeSelectedTag(selectedTag)"
      >
        {{ $t('tagsView.close') }}
      </li>
      <li @click="closeOthersTags">
        {{ $t('tagsView.closeOthers') }}
      </li>
      <li @click="closeAllTags(selectedTag)">
        {{ $t('tagsView.closeAll') }}
      </li>
    </ul>
  </div>
</template>

<script>
import ZvScrollPane from '@/components/zv-scroll-pane/index'
import path from 'path'
export default {
  name: 'TagsView',
  components: { ZvScrollPane },
  data() {
    return {
      visible: false,
      top: 0,
      left: 0,
      // 当前选择的tag
      selectedTag: {},
      // 固定的tag标签集合
      affixTags: [],
      // 访问过的页面列表
      visitedViews: []
    }
  },
  computed: {
    // 缓存全部路由列表
    routes() {
      return this.$store.getters.menuTree || this.$router.options.routes
    }
  },
  watch: {
    // 当路由变化的时候，添加路由，并将视图移动到对应的位置
    $route() {
      this.addTags()
      this.moveToCurrentTag()
    },
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  },
  mounted() {
    this.initTags()
    this.addTags()
  },
  methods: {
    // 判断当前哪个路由是访问状态
    isActive(route) {
      return route.path === this.$route.path
    },
    // 筛选固定标签的函数
    filterAffixTags(routes, basePath = '/') {
      let tags = []
      routes.forEach(route => {
        // meta中 affix标签 表示固定
        if (route.meta && route.meta.affix) {
          const tagPath = path.resolve(basePath, route.path)
          tags.push({
            fullPath: tagPath,
            path: tagPath,
            name: route.name,
            meta: { ...route.meta }
          })
        }
        if (route.children) {
          // 递归检出所有的固定标签
          const tempTags = this.filterAffixTags(route.children, route.path)
          if (tempTags.length >= 1) {
            tags = [...tags, ...tempTags]
          }
        }
      })
      return tags
    },
    // 初始化的时候检出全部固定的标签
    initTags() {
      this.affixTags = this.filterAffixTags(this.routes)
      const affixTags = this.affixTags
      for (const tag of affixTags) {
        if (tag.name) {
          this.addVisitedView(tag)
        }
      }
    },
    // 动态添加标签
    addTags() {
      const { name } = this.$route
      if (name) {
        this.addView(this.$route)
      }
    },
    // 移动到对应的标签位置
    moveToCurrentTag() {
      const tags = this.$refs.tag
      this.$nextTick(() => {
        for (const tag of tags) {
          if (tag.to.path === this.$route.path) {
            this.$refs.scrollPane.moveToTarget(tag)
            // when query is different then update
            if (tag.to.fullPath !== this.$route.fullPath) {
              this.updateVisitedView(this.$route)
            }
            break
          }
        }
      })
    },

    closeSelectedTag(view) {
      view = view || this.selectedTag
      this.deleteVisitedView(view)
      if (this.isActive(view)) {
        this.toLastView(this.visitedViews)
      }
    },

    toLastView(visitedViews) {
      const latestView = visitedViews.slice(-1)[0]
      if (latestView) {
        this.$router.push(latestView)
      } else {
        this.$router.push('/')
      }
    },
    // 添加标签
    addView(view) {
      this.addVisitedView(view)
    },
    // 添加标签到访问的标签列表中
    addVisitedView(view) {
      if (this.visitedViews.some(v => v.path === view.path)) return
      this.visitedViews.push(
        Object.assign({}, view, {
          title: view.meta.title || 'no-name'
        })
      )
    },
    // 更新标签到访问的标签列表中
    updateVisitedView(view) {
      for (let v of this.visitedViews) {
        if (v.path === view.path) {
          v = Object.assign(v, view)
          break
        }
      }
    },
    // 更新标签到访问的标签列表中
    deleteVisitedView(view) {
      for (const [i, v] of this.visitedViews.entries()) {
        if (v.path === view.path) {
          this.visitedViews.splice(i, 1)
          break
        }
      }
    },

    deleteOthersVisitedViews(view) {
      for (const [i, v] of this.visitedViews.entries()) {
        if (v.path === view.path) {
          this.visitedViews = this.visitedViews.slice(i, i + 1)
          break
        }
      }
    },

    openMenu(tag, e) {
      const menuMinWidth = 124
      const offsetWidth = this.$el.offsetWidth // container width
      const maxLeft = offsetWidth - menuMinWidth // left boundary
      const left = e.clientX // 15: margin right
      if (left > maxLeft) {
        this.left = maxLeft
      } else {
        this.left = left
      }
      this.top = e.clientY
      this.visible = true
      this.selectedTag = tag
    },

    closeMenu() {
      this.visible = false
    },

    refreshSelectedTag(view) {
      this.deleteVisitedView(view)
      const { fullPath } = view
      this.$nextTick(() => {
        this.$router.replace({
          path: '/redirect' + fullPath
        })
      })
    },

    closeOthersTags() {
      this.$router.push(this.selectedTag)
      this.deleteOthersVisitedViews(this.selectedTag)
      this.moveToCurrentTag()
    },

    closeAllTags(view) {
      this.visitedViews = []
      if (this.affixTags.some(tag => tag.path === view.path)) {
        return
      }
      this.toLastView(this.visitedViews, view)
    }
  }
}
</script>

<style lang="scss" scoped>
.tags-view-container {
  height: 44px;
  width: 100%;
  background: $white;
  border-bottom: 1px solid $border-color;
  .tags-view-wrapper {
    .tags-view-item {
      display: inline-block;
      transition: all 0.3s;
      position: relative;
      cursor: pointer;
      height: 32px;
      line-height: 32px;
      border: 1px solid $border-color;
      border-bottom: 0;
      color: $sub-font-color;
      background: $white;
      padding: 0 16px;
      font-size: 12px;
      margin-top: 11px;
      border-radius: 4px 4px 0px 0px;
      &:first-of-type {
        margin-left: 16px;
      }
      &:last-of-type {
        margin-right: 16px;
      }
      &.active {
        background-color: $mainBg;
        color: $base-font-color;
      }
    }
  }
  .tags-view-enter,
  .tags-view-leave-to {
    opacity: 0;
    transform: translateX(10px);
  }
  .contextmenu {
    margin: 0;
    background: #fff;
    z-index: 3000;
    position: absolute;
    list-style-type: none;
    padding: 5px 0;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 400;
    color: #333;
    box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);
    li {
      margin: 0;
      padding: 7px 16px;
      cursor: pointer;
      &:hover {
        background: $mainBg;
      }
    }
  }
}
</style>

<style lang="scss">
//reset element css of el-icon-close
.tags-view-wrapper {
  .tags-view-item {
    .el-icon-close {
      width: 16px;
      height: 16px;
      vertical-align: 2px;
      margin-left: 8px;
      border-radius: 50%;
      text-align: center;
      transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
      transform-origin: 100% 50%;
      &:before {
        transform: scale(1);
        display: inline-block;
        vertical-align: -3px;
      }
      &:hover {
        background-color: #b4bccc;
        color: #fff;
      }
    }
  }
}
</style>
