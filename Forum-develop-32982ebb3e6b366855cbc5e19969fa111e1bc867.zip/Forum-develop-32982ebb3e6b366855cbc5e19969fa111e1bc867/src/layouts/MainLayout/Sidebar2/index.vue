<template>
  <div class="wrapper zv-sider">
    <div class="header">
      <div class="image">
        <img
          class="logo"
          v-if="!!logoUrl"
          :src="logoUrl"
          :class="{ active: !sidebar.opened }"
          alt="logo"
        />
      </div>
      <hamburger
        class="hamburger-container"
        :class="{ active: !sidebar.opened }"
        :toggle-click="toggleSideBar"
        :is-active="sidebar.opened"
      />
    </div>
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <!--active-text-color：sidebar item 文字颜色-->
      <!--background-color: sidebar item 背景颜色-->
      <el-menu
        mode="vertical"
        :unique-opened="true"
        :show-timeout="200"
        :default-active="$route.path"
        :collapse="isCollapse"
        background-color="#2d2d34"
        text-color="#fff"
        active-text-color="#fff"
        @select="itemSelect"
        @open="goPage"
      >
        <sidebar-item
          v-for="route in permission"
          :key="route.id"
          :item="route"
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SidebarItem from './SidebarItem'
import Hamburger from './Hamburger'

export default {
  data() {
    return {
      defaultLogo: require('@/assets/img/company-logo.png')
    }
  },
  components: { SidebarItem, Hamburger },
  computed: {
    ...mapGetters(['sidebar']),
    permission() {
      return this.$store.getters.menuTree
      // return this.$router.options.routes.filter(item => item.meta)
    },
    isCollapse() {
      return !this.sidebar.opened
    },
    logoUrl() {
      return this.defaultLogo
    }
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    itemSelect(index) {
      if (index.indexOf('http') >= 0) {
        window.open(index)
      }
    },
    // 一级菜单点击跳转到对应配置的绝对路径
    // eslint-disable-next-line
    goPage(index) {
      const href = location.href
      if (href.indexOf(index) !== 0 && index.includes('http')) {
        location.href = index
      }
    }
  }
}
</script>

<style scoped lang="scss">
@keyframes round {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}
@keyframes scale {
  from {
    width: 60px;
    height: 60px;
  }
  to {
    width: 30px;
    height: 30px;
  }
}
@keyframes scaleOpen {
  from {
    width: 30px;
    height: 30px;
  }
  to {
    width: 60px;
    height: 60px;
  }
}
.wrapper {
  background-color: #383841;
  overflow: scroll;
  .header {
    height: 131px;
    display: flex;
    align-content: center;
    flex-direction: column;
    align-items: center;
    animation: round 0.28s linear;
    .image {
      height: 90px;
      display: flex;
      justify-content: center;
      align-items: center;
      .logo {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        animation: scaleOpen 0.28s linear;
        &.active {
          animation: scale 0.28s linear;
          width: 30px;
          height: 30px;
        }
      }
    }
    .hamburger-container {
      width: 100%;
      line-height: 41px;
      height: 41px;
      text-align: center;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #2d2d34;
    }
  }
}
</style>

<style lang="scss">
.zv-sider {
  .el-menu {
    border-right-width: 0;
  }
  .el-menu--popup {
    .el-menu-item {
      background-color: #2d2d34 !important;
    }
  }
}
</style>
