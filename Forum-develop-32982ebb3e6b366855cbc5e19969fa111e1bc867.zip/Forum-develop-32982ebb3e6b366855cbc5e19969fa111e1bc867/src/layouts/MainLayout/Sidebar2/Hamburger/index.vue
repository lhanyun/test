<template>
  <div @click="toggleClick">
    <zv-svg-icon
      @click="toggleClick"
      class="hamburger"
      :class="{ 'is-active': isActive }"
      icon-class="nav"
    />
  </div>
</template>

<script>
export default {
  name: 'Hamburger',
  props: {
    isActive: {
      type: Boolean,
      default: false
    },
    toggleClick: {
      type: Function,
      default: null
    }
  }
}
</script>

<style scoped>
.hamburger {
  display: inline-block;
  cursor: pointer;
  transform: rotate(90deg);
  transition: 0.38s;
  transform-origin: 50% 50%;
  width: 16px !important;
  height: 16px !important;
  fill: white !important;
}
.hamburger.is-active {
  transform: rotate(0deg);
}
</style>
