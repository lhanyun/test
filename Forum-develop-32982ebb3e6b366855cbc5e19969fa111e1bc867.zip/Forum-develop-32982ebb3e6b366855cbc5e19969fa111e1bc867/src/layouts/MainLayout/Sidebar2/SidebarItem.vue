<template>
  <div class="menu-wrapper">
    <template v-if="isFirstMenu(item)">
      <router-link v-if="item.eventType === '1'" :to="item.url">
        <el-menu-item
          :index="item.url"
          style="padding-left: 13px"
          :class="{ 'submenu-title-noDropdown': !isNest }"
        >
          <zv-svg-icon :icon-class="item.icon" />
          <span class="title" slot="title">{{ item.name }}</span>
        </el-menu-item>
      </router-link>
      <!--判断是不是跳转外部链接-->
      <el-menu-item
        v-else
        :index="item.url"
        style="padding-left: 13px"
        :class="{ 'submenu-title-noDropdown': !isNest }"
      >
        <zv-svg-icon :icon-class="item.icon" />
        <span class="title" slot="title">{{ item.name }}</span>
      </el-menu-item>
    </template>
    <template v-else>
      <el-submenu :index="item.url">
        <template slot="title">
          <zv-svg-icon :icon-class="item.icon" />
          <span class="title" slot="title">{{ item.name }}</span>
        </template>

        <template v-for="child in item.children">
          <!-- <el-menu-item
            v-if="child.eventType === '2'"
            :key="child.name"
            :index="child.url"
            class="submenu"
            style="padding-left: 13px;"
            :class="{ 'submenu-title-noDropdown': !isNest }"
          >
            <zv-svg-icon class="submenu-icon" :icon-class="child.icon" />
            <span class="title" slot="title">{{ child.name }}</span>
          </el-menu-item> -->
          <!-- <router-link
            v-else-if="
              child.url.indexOf('allTo-doList') > -1 ||
                child.url.indexOf('allTo-doneList') > -1
            "
            :to="'/' + child.url"
            :key="child.id"
          >
            <el-menu-item :index="child.url" class="submenu">
              <zv-svg-icon class="submenu-icon" :icon-class="child.icon" />
              <span class="title" slot="title">{{ child.name }}</span>
            </el-menu-item>
          </router-link> -->
          <el-menu-item
            v-if="child.eventType === '2'"
            :key="child.name"
            :index="child.url"
            class="submenu"
            style="padding-left: 13px;"
            :class="{ 'submenu-title-noDropdown': !isNest }"
          >
            <!-- <zv-svg-icon class="submenu-icon" :icon-class="child.icon" /> -->
            <span class="title" slot="title">{{ child.name }}</span>
          </el-menu-item>
          <router-link
            v-else-if="
              child.url.indexOf('allTo-doList') > -1 ||
                child.url.indexOf('allTo-doneList') > -1
            "
            :to="'/' + child.url"
            :key="child.id"
          >
            <el-menu-item :index="child.url" class="submenu">
              <!-- <zv-svg-icon class="submenu-icon" :icon-class="child.icon" /> -->
              <span class="title" slot="title">{{ child.name }}</span>
            </el-menu-item>
          </router-link>
          <router-link v-else :to="child.url" :key="child.id">
            <el-menu-item :index="child.url" class="submenu">
              <!-- <zv-svg-icon class="submenu-icon" :icon-class="child.icon" /> -->
              <span class="title" slot="title">{{ child.name }}</span>
            </el-menu-item>
          </router-link>
        </template>
      </el-submenu>
    </template>
  </div>
</template>

<script>
export default {
  name: 'SidebarItem',
  props: {
    // route配置json
    item: {
      type: Object,
      required: true
    },
    isNest: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    isFirstMenu(item) {
      if (item.children && item.children.length === 0) {
        return true
      }
      return false
    }
  }
}
</script>
<style lang="scss" scoped>
.svg-icon {
  width: 20px !important;
  height: 20px !important;
  vertical-align: middle !important;
  fill: #d3d5cf !important;
  margin-right: 10px;
}
.title {
  font-size: $fontSizeDefault;
}
/deep/ .submenu-title-noDropdown {
  padding-left: 13px !important;
}
.submenu-icon {
  width: 8px !important;
  height: 8px !important;
}
</style>
