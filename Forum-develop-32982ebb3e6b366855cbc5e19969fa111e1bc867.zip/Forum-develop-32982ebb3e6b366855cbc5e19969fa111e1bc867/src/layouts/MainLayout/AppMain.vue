<template>
  <section class="app-main">
    <zv-scroll class="app-main__bg" height="calc(100vh - 120px)">
      <transition name="fade-transform" mode="out-in">
        <keep-alive>
          <router-view :key="key" />
        </keep-alive>
      </transition>
    </zv-scroll>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    key() {
      return this.$route.fullPath
    }
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  min-height: calc(100vh - 88px);
  width: 100%;
  overflow: hidden;
  background-color: $mainBg;
  padding: 16px;
  @include flex($direction: column);
  .app-main__bg {
    background-color: $white;
    width: 100%;
    flex: 1;
    overflow: hidden;
    position: relative;
    display: flex;
  }
}
</style>

<style lang="scss">
.app-main__bg {
  .el-scrollbar__wrap {
    width: 100%;
  }
}
</style>
