<template>
  <div class="sidebar-logo" :class="{ collapse: collapse }">
    <transition name="sidebarLogoFade">
      <div v-if="collapse" key="collapse" class="sidebar-logo-container">
        <router-link class="sidebar-logo-link" to="/">
          <img :src="logo" class="sidebar-logo-img" />
        </router-link>
        <el-dropdown class="product-nav" trigger="click">
          <span class="el-dropdown-link">
            <zv-svg-icon icon-class="down" class-name="svg-class" />
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="changeExpaned">
              抽屉切换
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div v-else key="expand" class="sidebar-logo-container44">
        <router-link class="sidebar-logo-link" to="/">
          <img :src="logo" class="sidebar-logo-img" />
        </router-link>
        <el-dropdown class="product-nav" trigger="click">
          <span class="el-dropdown-link">
            <zv-svg-icon icon-class="down" class-name="svg-class" />
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="changeExpaned">
              抽屉切换
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'SidebarLogo',
  props: {
    collapse: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      logo:
        'https://wpimg.wallstcn.com/69a1c46c-eb1c-4b46-8bd4-e9e686ef5251.png'
    }
  },
  methods: {
    changeExpaned() {
      this.$store.dispatch('app/toggleSideBar')
    }
  }
}
</script>

<style lang="scss" scoped>
.sidebarLogoFade-enter-active {
  transition: all 0.15s;
}
.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}
.sidebar-logo {
  position: relative;
  width: 100%;
  @include containerH44();
  text-align: center;
  overflow: hidden;
  .sidebar-logo-container44 {
    @include containerH44();
    @include flex();
    padding: 0 16px;
    .sidebar-logo-link {
      width: 120px;
      height: 24px;
      .sidebar-logo-img {
        width: 120px;
        height: 24px;
      }
    }
    .product-nav {
      .svg-class {
        width: 14px;
        height: 12px;
        fill: $white;
      }
    }
  }
  &.collapse {
    height: 88px;
    .sidebar-logo-container {
      height: 88px;
      @include flex($direction: column);
      .sidebar-logo-link {
        margin-top: 10px;
        width: 24px;
        height: 24px;
        .sidebar-logo-img {
          width: 24px;
          height: 24px;
        }
      }
      .product-nav {
        .svg-class {
          width: 14px;
          height: 12px;
          fill: $white;
        }
      }
    }
  }
}
</style>
