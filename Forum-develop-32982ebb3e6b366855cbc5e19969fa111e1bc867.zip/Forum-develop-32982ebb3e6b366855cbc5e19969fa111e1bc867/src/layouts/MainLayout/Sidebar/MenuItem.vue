<script>
export default {
  name: 'MenuItem',
  functional: true,
  props: {
    icon: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    }
  },
  render(h, context) {
    const { icon, title } = context.props
    const vnodes = []
    if (icon) {
      vnodes.push(<zv-svg-icon icon-class={icon} class="item-svg" />)
    }
    if (title) {
      vnodes.push(<span slot="title">{title}</span>)
    }
    return vnodes
  }
}
</script>

<style lang="scss" scoped>
.item-svg {
  height: 16px !important;
  width: 16px !important;
  fill: $white !important;
  margin-right: 8px;
}
</style>
