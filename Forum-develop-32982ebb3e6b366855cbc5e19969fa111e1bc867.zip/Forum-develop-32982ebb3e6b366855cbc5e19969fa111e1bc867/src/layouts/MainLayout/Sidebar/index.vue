<template>
  <div class="hasLogo">
    <logo :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        background-color="#383841"
        text-color="#ffffff"
        :unique-opened="false"
        active-text-color="#ffffff"
        :collapse-transition="true"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in permission_routes"
          :key="route.url || route.path"
          :item="route"
          :base-path="route.url || route.path"
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Logo from './Logo'
import SidebarItem from './SidebarItem'
export default {
  components: { SidebarItem, Logo },
  computed: {
    ...mapGetters(['sidebar']),
    permission_routes() {
      return this.$store.getters.menuTree
      // return this.$router.options.routes.filter(item => item.meta)
    },
    activeMenu() {
      const route = this.$route
      const { path } = route
      return path
    },
    isCollapse() {
      return !this.sidebar.opened
    }
  },
  created() {
    console.log(this.$router.options.routes)
  }
}
</script>

<style lang="scss">
.hasLogo {
  .isCollapse {
    .scrollbar-wrapper {
      height: calc(100vh - 88px);
    }
  }
  .scrollbar-wrapper {
    height: calc(100vh - 44px);
  }
  .el-menu {
    background-color: $sideBg;
    border-width: 0;
  }
  .el-menu--inline {
    background-color: rgba(0, 0, 0, 0.2) !important;
    .el-menu-item {
      background-color: rgba(0, 0, 0, 0.2) !important;
    }
  }
  .el-menu-item:hover {
    background-color: #70b913 !important;
  }
  .el-submenu__title:hover,
  .el-submenu__title:focus,
  .el-submenu__title:active {
    background-color: #70b913 !important;
  }
  .el-menu--inline {
    .el-menu-item {
      height: 44px;
      line-height: 44px;
    }
    .el-menu-item:hover {
      background-color: #70b913 !important;
    }
  }
  .el-menu-item {
    height: 44px;
    line-height: 44px;
  }
  .el-submenu__title {
    height: 44px;
    line-height: 44px;
  }
  .el-menu-item.is-active {
    background-color: #70b913 !important;
  }
  .submenu-title-noDropdown,
  .el-submenu__title {
    padding-left: 16px !important;
  }
  .el-menu--collapse {
    width: 80px;
    .el-menu-item {
      height: 44px;
      line-height: 44px;
      .el-tooltip {
        text-align: center;
      }
    }
    .item-svg {
      margin-right: 0;
    }
    .el-submenu {
      overflow: hidden;
      & > .el-submenu__title {
        .el-submenu__icon-arrow {
          display: none;
        }
      }
    }
    .el-submenu {
      & > .el-submenu__title {
        text-align: center;
        & > span {
          font-size: 0;
          height: 0;
          width: 0;
          margin-left: 0;
          overflow: hidden;
          visibility: hidden;
          display: inline-block;
        }
      }
    }
    .el-submenu.is-active {
      .el-submenu__title {
        background-color: #70b913 !important;
        text-align: center;
        height: 44px;
        line-height: 44px;
      }
    }
  }
}
.el-menu--popup {
  .el-menu-item {
    background-color: rgba(0, 0, 0, 0.2) !important;
  }
  .el-menu-item:hover {
    background-color: #70b913 !important;
  }
  .el-menu-item.is-active {
    background-color: #70b913 !important;
  }
}
</style>
