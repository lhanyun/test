<!-- 
  /** @author 肖景
  *   @description: 架子的头部导航部分
  */  @date 2019-07-11
-->
<template>
  <nav class="navigate">
    <!-- 左边的下拉选择公司部分 -->
    <div class="nav-left">
      <el-dropdown
        class="company-container nav-left"
        placement="top-start"
        @command="handleCommand"
        trigger="click"
      >
        <div class="company-wrapper">
          <zv-svg-icon class="company-icon" icon-class="gongsi2" />
          <span class="company-name">{{ companyName }}</span>
          <zv-svg-icon class="company-dropdown" icon-class="dakai" />
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item
            v-for="(item, index) of this.orgList"
            :key="index"
            :command="item"
          >
            {{ item.name }}
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <!-- 右侧部分区域 -->
    <div class="nav-right">
      <!-- 自定义的插槽，方便用户进行一定的自定义 -->
      <div class="menu-title" @click="toNext('', home_url)">
        <div class="zv-icon">
          <zv-svg-icon class="icon" icon-class="zv-logo" />
        </div>
        <div class="title">门户</div>
      </div>
      <div class="menu-title">
        <el-dropdown
          class="company-container nav-left"
          placement="top-start"
          @command="toUrl"
          trigger="click"
        >
          <div class="company-wrapper">
            <zv-svg-icon class="company-icon" icon-class="daohang" />
            <span class="company-name">导航</span>
          </div>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item
              v-for="(item, index) in productLists"
              :key="index"
              :command="item"
            >
              <div class="zv-product__lists">
                <img :src="prvImg + item.pid" />
                <span>{{ item.name }}</span>
                <zv-svg-icon icon-class="jinru" />
              </div>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div
        class="menu-title"
        v-for="(item, index) in titles"
        :key="index"
        @click="toNext(item.name, item.url)"
      >
        <div
          class="zv-icon"
          :class="[item.haveActive && unreadMessageNumber ? 'active' : '']"
        >
          <zv-svg-icon class="icon" :icon-class="item.icon" />
        </div>

        <div class="title">{{ item.title }}</div>
      </div>
      <slot />
      <!-- 最右边地方，包含跳转个人设置，账号信息，退出等内容 -->
      <el-dropdown class="avatar-container" trigger="click">
        <div class="avatar-wrapper">
          <span class="username">
            {{ $t('home.welcome') }} {{ $store.getters.userInfo.name }}
          </span>
          <img class="avatar" :src="userImg" alt="头像" />
        </div>
        <el-dropdown-menu class="user-dropdown" slot="dropdown">
          <el-dropdown-item @click.native="toPersonSetting">
            个人设置
          </el-dropdown-item>
          <el-dropdown-item
            v-permissions="'updateLogo'"
            @click.native="toAccountInfo"
          >
            账号信息
          </el-dropdown-item>
          <el-dropdown-item divided>
            <span @click="logout" style="display:block;">
              退出
            </span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </nav>
</template>

<script>
import {
  getToken,
  removeRedirectUrl,
  getAppType,
  setAppType
} from '@/utils/auth'
import { mapGetters } from 'vuex'
import Cookies from 'js-cookie'
import { queryTenantProductList } from '@/api/login'

export default {
  name: 'Navigate',
  data() {
    return {
      companyName: '',
      defaultIcon: require('@/assets/img/defaultIcon.png'),
      unreadMessageNumber: 0,
      filterNumber: 0,
      productLists: [],
      home_url: process.env.VUE_APP_HOME_URL,
      titles: [
        {
          icon: 'xinfeng',
          title: '消息',
          name: 'message',
          haveActive: true
        },
        {
          icon: 'bangzhu',
          title: '帮助',
          url: process.env.VUE_APP_HELP_CENTER_URL
        }
      ],
      prvImg:
        this.$BASE_API +
        `/pocomponent/file/downloadFile/w/v1/?clientId=poweb&sessionId=${getToken()}&isAbbreviation=Y&id=`
    }
  },
  computed: {
    ...mapGetters(['orgList']),
    userImg() {
      // 数据库如果没有，就取默认头像
      if (this.$store.getters.userInfo.attachmentId) {
        return (
          this.$BASE_API +
          `/pocomponent/file/downloadFile/w/v1/?clientId=poweb&id=${
            this.$store.getters.userInfo.attachmentId
          }&sessionId=${getToken()}&isAbbreviation=Y`
        )
      } else {
        return this.defaultIcon
      }
    }
  },
  mounted() {
    // 获取被选中的公司名
    this.queryTenantProductList()
    this.orgList.forEach(item => {
      if (item.isSelected === 'Y') {
        this.companyName = item.name || ''
      }
    })
    if (this.companyName === '' && this.orgList.length !== 0) {
      this.companyName = this.orgList[0].name || ''
    }

    this.getCount()
    if (process.env.NODE_ENV !== 'development') {
      setInterval(() => {
        this.$store
          .dispatch('message_queryUnreadMessage', {
            messageStatus: 0,
            messageType: ''
          })
          .then(data => {
            if (data.code === '0') {
              if (data.filterNumber > this.filterNumber) {
                this.$notify({
                  title: '提示',
                  dangerouslyUseHTMLString: true,
                  message:
                    '<strong><a href="#/message">您有新的消息<a href="#/message">点击查看</a></strong>',
                  type: 'info'
                })
                this.$store.commit('SET_MESSAGE_COUNT', data.number)
                this.filterNumber = data.filterNumber
              }
            }
          })
      }, 1000 * 60)
    }
  },
  methods: {
    async logout() {
      try {
        await this.$store.dispatch('LogOut')
        removeRedirectUrl()
        if (process.env.VUE_APP_HAVE_LOGIN === '1') {
          this.$configParams.redirectHome(false)
        } else {
          this.$router.replace('/login')
        }
      } catch (error) {
        throw error
      }
    },
    async queryTenantProductList() {
      try {
        let { productDtos } = await queryTenantProductList()
        productDtos = productDtos.filter(item => item.status !== '2')
        this.productLists = productDtos
      } catch (error) {
        throw error
      }
    },
    handleCommand(item) {
      // 选择租户
      const id = item.id && item.id.length ? item.id : ''
      this.companyName = item.name
      this.$store
        .dispatch('ChooseCorp', { id })
        .then(data => {
          console.log(data)
          if (data.code === '0') {
            this.$store
              .dispatch('GetConfigRouter', this.$store.getters.appType)
              .then(() => {
                const { fullPath } = this.$route
                this.$nextTick(() => {
                  this.$router.replace({
                    path: '/redirect' + fullPath
                  })
                })
              })
              .catch(() => {
                this.$message.error('切换失败')
              })
          } else {
            this.$message.error('切换失败')
          }
        })
        .catch(() => {
          console.log('选择公司接口失败')
        })
    },
    getCount() {
      this.$store
        .dispatch('message_queryUnreadMessage', {
          messageStatus: 0,
          messageType: ''
        })
        .then(data => {
          this.$store.commit('SET_MESSAGE_COUNT', data.number)
          this.unreadMessageNumber = data.number
          this.filterNumber = data.filterNumber
        })
    },
    toNext(name, url) {
      if (name) {
        this.$router.push({ name: name })
      } else {
        if (getAppType()) {
          window.location.href = url + '?appType=' + getAppType()
        } else {
          window.location.href = url
        }
      }
    },
    /**
     * @author 肖景
     * @date 2019/07/18
     * @description 语言切换
     */
    languageSwitch() {
      if (Cookies.get('language') === 'zh_CN') {
        Cookies.set('language', 'en_US')
      } else {
        Cookies.set('language', 'zh_CN')
      }
      window.location.reload()
    },
    toUrl(item) {
      if (item.url) {
        setAppType(item.id)
        window.location.href = item.url + '?appType=' + item.id
      }
    },
    /**
     * @author 肖景
     * @date 2019/07/18
     * @description 跳转到用户设置
     */
    toPersonSetting() {
      window.location.href = this.$configParams.personSetting
    },
    /**
     * @author 肖景
     * @date 2019/07/18
     * @description 跳转到账号设置
     */
    toAccountInfo() {
      window.location.href = this.$configParams.accountInfo
    }
  }
}
</script>

<style lang="scss" scoped>
.navigate {
  @include containerH44();

  border-bottom: 1px solid $border-color;
  @include flex();
}

.zv-product__lists {
  @include flex();
  @include containerH44();
  width: 200px;
  img {
    width: 16px;
    height: 16px;
  }
  span {
    flex: 1;
    margin-left: 8px;
  }
}
</style>

<style lang="scss">
.navigate {
  padding: 0 16px;
  .el-dropdown {
    color: $base-font-color;
    font-size: $base-font-size;
  }
  .nav-left {
    cursor: pointer;
    line-height: 44px;
    height: 44px;
    // display: revert;
    align-items: center;
    .company-wrapper {
      // display: flex;
      align-items: center;
      .company-name {
        color: $base-font-color;
        font-size: $base-font-size;
        margin-left: 8px;
        vertical-align: middle;
      }
      .company-dropdown {
        transform: scale(0.8);
        display: inline-flex;
        width: 16px;
        height: 16px;
      }
    }
  }
  .menu-title {
    cursor: pointer;
    font-size: $base-font-size;
    width: 96px;
    display: flex;
    align-items: center;
    .title {
      color: $base-font-color;
      margin-left: 10px;
      vertical-align: middle;
    }
    .zv-icon {
      vertical-align: middle;
      display: inline-flex;
    }
    .icon {
      width: 16px;
      height: 16px;
      vertical-align: middle;
      position: relative;
    }
    .zv-icon.active {
      position: relative;
      display: block;
    }
    .zv-icon.active::after {
      content: '';
      width: 6px;
      height: 6px;
      background-color: #f44336;
      border-radius: 50%;
      position: absolute;
      top: 11px;
    }
  }
  .nav-right {
    @include flex();
    .avatar-wrapper {
      width: 160px;
      @include flex();
      .username {
        font-size: $sub-font-size;
        width: 124px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        text-align: right;
      }
      .avatar {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        object-fit: contain;
      }
    }
  }
}
</style>
