/** 2019/2/17
 * @Author: 刘宇琳
 * @Desc: 此文件用来管理缓存变量
 */
export const USER_NAME = 'userName'
export const TOKEN = 'token'

/**
 * @author: 肖景
 * @date: 2019-07-10
 * @description: 数据字典
 */
export const DATA_DIC = 'DATA_DIC'
