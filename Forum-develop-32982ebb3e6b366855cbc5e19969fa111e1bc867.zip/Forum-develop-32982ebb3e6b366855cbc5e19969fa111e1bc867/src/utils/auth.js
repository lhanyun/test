/*
 * @Author: your name
 * @Date: 2019-11-08 09:22:40
 * @LastEditTime: 2019-11-11 11:23:38
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \pc-bbs\src\utils\auth.js
 */
import Cookies from 'js-cookie'

const TokenKey = 'Admin-Token'

const USERINFOKEY = 'Admin-UserInfo'

const REDIRECTURL = 'Admin-RedirectUrl'

const APPTYPE = 'APPTYPE'

const COOKIES_CONFIG =
  process.env.NODE_ENV === 'production'
    ? {
        domain: process.env.VUE_APP_DOMAIN
      }
    : {}

export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token, COOKIES_CONFIG)
}

export function removeToken() {
  return Cookies.remove(TokenKey, COOKIES_CONFIG)
}

export function getUserInfoByKey() {
  return Cookies.get(USERINFOKEY)
}

export function setUserInfo(userInfo) {
  return Cookies.set(USERINFOKEY, JSON.stringify(userInfo), COOKIES_CONFIG)
}

export function removeUserInfo() {
  return Cookies.remove(USERINFOKEY, COOKIES_CONFIG)
}

export function getRedirectUrl() {
  return Cookies.get(REDIRECTURL)
}

export function setRedirectUrl(url) {
  return Cookies.set(REDIRECTURL, url, COOKIES_CONFIG)
}

export function removeRedirectUrl() {
  return Cookies.remove(REDIRECTURL, COOKIES_CONFIG)
}

export function setAppType(appType) {
  return Cookies.set(APPTYPE, appType, COOKIES_CONFIG)
}

export function getAppType() {
  return Cookies.get(APPTYPE) ? Cookies.get(APPTYPE) : '30599740131840'
}
