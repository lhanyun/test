/*
 * @Author: your name
 * @Date: 2019-11-25 17:09:25
 * @LastEditTime: 2019-11-26 09:11:56
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \pc-bbs\src\utils\permission.js
 */
import router from '../router'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import store from '@/store'
import { getToken, removeToken } from '@/utils/auth' // getToken from cookie
import { getAllDictionaryKeyValue } from '@/api/login'
import storage from 'good-storage'
import { DATA_DIC } from '@/utils/types'
import { Message } from 'element-ui'

NProgress.configure({
  showSpinner: false
}) // NProgress configuration

const whiteList = ['/login', '/401'] // 不重定向白名单
router.beforeEach(async (to, from, next) => {
  if (to.name === 'login' || to.path === '/login') {
    if (top) {
      top.postMessage(
        {
          type: 'relogin',
          data: {}
        },
        '*'
      )
    }
    window.parent.location.hash = 'login'
  }
  NProgress.start()
  if (getToken()) {
    try {
      if (
        Object.keys(store.getters.userInfo).length === 0 &&
        !whiteList.includes(to.path)
      ) {
        await Promise.all([onUserInfo(), getDataDictonary()])
        next({
          ...to,
          replace: true
        })
        return
      }
      next()
    } catch (error) {
      Message.error('获取权限失败, 请重新登录')
      setTimeout(() => {
        removeToken()
        next('/401')
      }, 1000)
      NProgress.done()
    }
  } else {
    if (whiteList.includes(to.path)) {
      next()
    } else {
      next('login') // 全部重定向到登录页
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  NProgress.done() // 结束Progress
})

// 获取用户信息
function onUserInfo() {
  return store.dispatch('GetUserInfo')
}

function getDataDictonary() {
  if (!storage.session.get(DATA_DIC, '')) {
    return getAllDictionaryKeyValue({
      classify: store.getters.appType || 0
    }).then(({ dictionaryMap }) => {
      storage.session.set(DATA_DIC, dictionaryMap)
      return dictionaryMap
    })
  }
}
