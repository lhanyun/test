import storage from 'good-storage'
import Vue from 'vue'
import { DATA_DIC } from '@/utils/types'
Vue.prototype.$getDataDic = key => {
  const dic = storage.session.get(DATA_DIC, '')
  let value
  // 如果key为空 则返回整个数据字典
  if (!key) {
    return dic
  }
  if (dic !== '') {
    value = dic[key]
  } else {
    console.error(`未在数据字典中找到${key}`)
    value = dic
  }

  return value
}
