import vue from 'vue'
import axios from 'axios'
import qs from 'qs'
import { getToken, getAppType } from '@/utils/auth'
import Cookies from 'js-cookie'
import { throwErr } from './throwError'
import md5 from 'js-md5'
const key = '/l/A/8/9/2/w/b/b/s/B/S/N/f/r/5/a/J/2/c/o/V/T/u/T/a/3/d/Q/t'

// 创建axios实例
vue.prototype.$BASE_API = process.env.VUE_APP_BASE_URL
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_URL, // api的base_url
  timeout: 20000, // 请求超时时间
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    Accept: 'application/json'
  }
})

// request拦截器
service.interceptors.request.use(
  config => {
    // multipleDomain(config)

    // 配置调试
    handleUrl(config)

    // 处理请求参数
    handleParams(config)

    // 是否要更改header内容 上传文件
    if (config.isFile) {
      config.headers['Content-Type'] = 'multipart/form-data'
    }

    // 删除多余的参数isHideLoading
    if (config.data.isHideLoading) {
      delete config.data.isHideLoading
    }

    // 删除多余的参数 (防止接口间的参数复用)
    delete config.data['sign']
    delete config.data['timestamp']

    // 签名
    config.data = signParams(config.data)

    if (config.method === 'post') {
      // 设置参数拼接方式
      if (
        config.data &&
        config.headers['Content-Type'] === 'application/x-www-form-urlencoded'
      ) {
        config.data = qs.stringify(config.data, {
          arrayFormat: 'indices',
          allowDots: true
        })
      }
    } else {
      if (config.data) {
        config.url = config.url + '?' + qs.stringify(config.data)
      }
    }

    return config
  },
  error => {
    Promise.reject(error)
  }
)

// respone拦截器
service.interceptors.response.use(
  response => {
    // code为非0是抛错 可结合自己业务进行修改
    if (response.status === 200) {
      const res = response.data
      if (res.code !== '0') {
        return throwErr(res)
      }
      return Promise.resolve(res)
    } else {
      // 隐藏loading
      return Promise.reject('networkRequestError')
    }
  },
  error => {
    // 断网 或者 请求超时 状态
    if (!error.response) {
      // 请求超时状态
      if (error.message.includes('timeout')) {
        // console.log('超时了')
        // Message.error('请求超时，请检查网络是否连接正常')
      } else {
        // 可以展示断网组件
        // console.log('断网了')
        // Message.error('请求失败，请检查网络是否已连接')
      }
      return
    }
    return Promise.reject(error)
  }
)

// 多域名
// function multipleDomain(config) {
//   // 这个地方写需要改域名的接口
//   const urls = []
//   if (urls.includes(config.url)) {
//     // 需要修改成的对应域名
//     config.baseURL = ''
//   }
// }

// 处理请求参数
function handleParams(config) {
  if (!config.data) {
    // 防止不传参数的情况下，config中没有data属性
    config['data'] = {}
  }

  // 登录不要sessionId
  if (!config.noLogin) {
    // 接口调试的时候，向后台索取sessionId，给 config.data['sessionId'] 赋值
    config.data['sessionId'] = getToken()
  }

  if (!config.data['appType']) {
    config.data['appType'] = getAppType() || '0'
  }

  // 配置相关的用户语言信息
  config.data['locale'] = Cookies.get('language') || 'zh_CN'

  config.data['clientId'] = 'poweb'

  // 合并请求参数
  if (config.params) {
    config.data = { ...config.data, ...config.params }
  }
}

// 处理调试模式下，端口问题
function handleUrl(config) {
  if (process.env.NODE_ENV !== 'debugger') {
    return
  }

  // debugger 模式，拼接端口号
  let portConfig = require('./debugger.port')
  const apiName = config.url.match(/([\w]+)/)[1]
  config.baseURL = config.baseURL + ':' + portConfig.port[apiName]
}

function signParams(data) {
  const timestamp = new Date().getTime()

  const params = qs.stringify(data, {
    encode: false,
    delimiter: '#%-&^#-W&',
    arrayFormat: 'indices',
    allowDots: true
  })

  const arr = params.split('#%-&^#-W&')

  const paramStr = key + arr.sort().join('&') + timestamp + key

  data['sign'] = md5(paramStr)
  data['timestamp'] = timestamp

  return data
}

export default service
