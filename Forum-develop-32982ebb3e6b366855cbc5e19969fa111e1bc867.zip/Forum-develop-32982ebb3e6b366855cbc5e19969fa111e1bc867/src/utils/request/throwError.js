//axios捕错
// import store from '@/store'
import { Message } from 'element-ui'
import { removeToken } from '@/utils/auth'

export const throwErr = res => {
  let message
  if (res.code === '20' || res.code === '21') {
    message =
      res.code === '20'
        ? '缺少sessionId，请重新登入'
        : '无效的sessionId，请重新登入'
    setTimeout(() => {
      removeToken()
      location.reload()
    }, 1000)
    // store.dispatch('LogOut').then(() => {
    //   setTimeout(() => {
    //     location.reload()
    //   }, 1000)
    // })
  } else {
    if (
      res.subErrors &&
      res.subErrors.length !== 0 &&
      res.subErrors[0].message &&
      res.subErrors[0].message.length !== 0 &&
      res.subErrors[0].code
    ) {
      message = res.subErrors[0].message
    } else {
      message = res.msg
    }
  }
  Message.error(message || '页面发生错误')
  return Promise.reject(message || '页面发生错误')
}
