├── errorPage
│   ├── 401.vue
│   └── 404.vue
├── examples
│   ├── Detail
│   │   └── index.vue
│   ├── Home
│   │   └── index.vue
│   ├── Login
│   │   ├── AccountPassword.vue
│   │   ├── CreateCompony.vue
│   │   ├── SelectCompony.vue
│   │   ├── ShortMessage.vue
│   │   ├── Sign.vue
│   │   ├── UserAgreement
│   │   │   ├── config.js
│   │   │   └── index.vue
│   │   ├── index.vue
│   │   └── login_utils.js
│   └── Message
│   ├── Detail.vue
│   ├── Setting.vue
│   └── index.vue
├── machinery-BBS
│   ├── index.vue<!-- 信息信息 导航栏 肖巧伦 -->
│   ├── machinery-information
│   │   ├── index.vue<!-- 农机信息文章列表 肖巧伦 -->
│   │   ├── post-details
│   │   │   └── index.vue<!-- 帖子详情 肖巧伦 -->
│   │   └── utils.js
│   ├── post-message
│   │   └── index.vue<!-- 论坛发帖 肖巧伦 -->
│   └── post-reply
│   └── index.vue<!-- 我的发表/回复 肖巧伦 -->
└── redirect
└── index.vue

13 directories, 23 files
